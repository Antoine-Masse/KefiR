.manova_analysis <- function(x=NULL,g=NULL,formula=NULL,data=NULL,
	paired = FALSE, id = NULL,alpha = 0.05,
	k=NULL,code=FALSE,debug=FALSE,verbose=FALSE,boot=TRUE, silent=TRUE, return=TRUE) {

	###################
	#	Un code à conserver ?
	###################
	if (!is.null(formula)) {
	  print("DEBUG: Début du traitement")

	  clean_formula <- function(expr) {
		if (is.call(expr)) {
		  func_name <- as.character(expr[[1]])
		  transform_funcs <- c("I", "log", "sqrt", "exp", "scale", "as.numeric", "as.factor")
		  preserve_funcs <- c("cbind", "interaction", "poly", "bs", "ns")

		  print(paste("DEBUG: Traitement fonction:", func_name))

		  if (func_name %in% transform_funcs) {
			return(clean_formula(expr[[2]]))
		  } else if (func_name %in% preserve_funcs) {
			return(expr)
		  } else if (func_name == ":") {
			return(expr)
		  }
		  return(as.call(lapply(expr, clean_formula)))
		}
		return(expr)
	  }

	  print("DEBUG: Nettoyage formule")
	  cleaned_formula <- clean_formula(formula)
	  vars_needed <- all.vars(cleaned_formula)
	  print(paste("DEBUG: Variables nécessaires:", paste(vars_needed, collapse=", ")))

	  response_expr <- formula[[2]]
	  original_response_expr <- response_expr
	  cleaned_response_expr <- clean_formula(response_expr)

	  print(paste("DEBUG: Expression réponse originale:", deparse(original_response_expr)))

	  response_vars <- if (is.call(response_expr)) {
		func_name <- as.character(response_expr[[1]])
		if (func_name == "cbind") {
		  unique(unlist(lapply(response_expr[-1], all.vars)))
		} else {
		  all.vars(cleaned_response_expr)
		}
	  } else {
		all.vars(cleaned_response_expr)
	  }

	  print(paste("DEBUG: Variables réponse:", paste(response_vars, collapse=", ")))

	  response <- if (all(response_vars %in% colnames(data))) {
		print("DEBUG: Réponse dans data")
		if (length(response_vars) == 1) {
		  if (is.call(original_response_expr)) {
			print("DEBUG: Évaluation transformation sur colonne data")
			eval(original_response_expr, envir = data, enclos = parent.frame())
		  } else {
			data[[response_vars]]
		  }
		} else {
		  if (is.call(original_response_expr) && as.character(original_response_expr[[1]]) == "cbind") {
			eval(original_response_expr, envir = data, enclos = parent.frame())
		  } else {
			data[, response_vars, drop = FALSE]
		  }
		}
	  } else {
		print("DEBUG: Réponse externe à data")
		tryCatch({
		  if (is.call(original_response_expr)) {
			print("DEBUG: Évaluation expression externe")
			eval(original_response_expr, envir = list2env(as.list(data), parent = parent.frame()))
		  } else {
			get(response_vars, envir = parent.frame())
		  }
		}, error = function(e) {
		  print(paste("DEBUG: Erreur lors de l'évaluation:", e$message))
		  stop(e)
		})
	  }

	  # Suite du code identique...
	  g_vars <- setdiff(vars_needed, response_vars)
	  print(paste("DEBUG: Variables explicatives:", paste(g_vars, collapse=", ")))

	  g_list <- lapply(g_vars, function(var) {
		if (var %in% colnames(data)) {
		  data[[var]]
		} else {
		  get(var, envir = parent.frame())
		}
	  })

	  g <- if (length(g_list) > 1) {
		as.data.frame(setNames(g_list, g_vars))
	  } else if (length(g_list) == 1) {
		g_list[[1]]
	  } else {
		NULL
	  }
	}

}
