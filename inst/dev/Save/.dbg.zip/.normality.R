# Fonction : .normality
# Description : Évalue la normalité d'une variable numérique `x` en fonction d'un regroupement facultatif `g`.
# Paramètres :
# - x : un vecteur numérique, les données pour lesquelles la normalité doit être testée.
# - g : un vecteur ou facteur optionnel de regroupement. Si NULL, toutes les données seront regroupées sous un seul niveau.
# Retour :
# - Un objet `by` contenant les p-values des tests de normalité (Shapiro-Wilk, Jarque-Bera ou valeur par défaut).
# Détails :
# - Si `length(vector) <= 100`, le test de Shapiro-Wilk est utilisé.
# - Si `100 < length(vector) <= 1000`, le test de Jarque-Bera est utilisé.
# - Si `length(vector) > 1000`, une valeur par défaut de 1 est retournée (hypothèse de normalité).
.normality <- function(x, g = NULL) {
  # Korkmaz, S., & Demir, Y. (2023). Investigation of some univariate normality tests
  # in terms of type-I errors and test power. Journal of Scientific Reports-A, (52), 376–395.
  # https://dergipark.org.tr/en/download/article-file/2847569

  if (is.null(g)) {
    g <- factor(rep("A", length(x)))
  }

  # Déterminer la taille du plus petit groupe pour uniformiser le choix du test
  group_sizes <- table(g)
  min_size <- min(group_sizes)

  subnormality <- function(vector) {
    n <- length(vector)  # ✅ Taille du groupe ACTUEL

    if (n <= 50) {
      return(shapiro.test(as.numeric(vector))$p.value)
    } else if (n <= 50) {
      # Ce groupe spécifique dépasse la limite de Shapiro
      # Il présente une bonne puissance au-delà de 300
      # Glinskiy, V. V., Zhukova, M. A., & Tsybatov, A. E. (2024). Modifications to the Jarque–Bera Test. Mathematics, 12(16), 2523. https://doi.org/10.3390/math12162523
      return(jb.norm.test(vector)$p.value)
    } else {
      return(1)
    }

  }

  pvals <- by(x, g, subnormality)
  return(pvals)
}
