	#' Automatic average/median/variance comparison function.
	#'
	#' @param data numerical vector
	#' @param cat category vector
	#' @param alpha p-value threshold value for all the tests.
	#' @param verbose to display the full reasoning of the analysis.
	#' @param return allows to return the results of pairwise analysis (p-values and groups).
	#' @param paired (under development) to allow the analysis of matched data.
	#' @param control name of the category that will eventually be used as a control.
	#' @param maxcat maximum number of categories allowed. When this number is high, some tests may return an error message.
	#' @param plot to display the distribution of the data.
	#' @param silent for displaying or not warnings.
	#' @param boot to activate the boostrap on 'mean' and 'median'.
	#' @param iter number f iterations (boot==TRUE).
	#' @param conf confidence level of bootstrap.
	#' @param code allows to display the simplified R source code to be able to do the same R study step by step.
	#' @param debug when m.test return error.
	#'
	#' @return m.test() runs a decision tree to choose the most appropriate test series for sample comparison.
	#' @return She chooses the tests, justifies her choices.
	#' @return It can output groups of means or a comparison to a control.
	#' @return Finally, it will measure the robustness of the results by bootstrap.
	#' @importFrom fda.usc fanova.hetero
	#' @importFrom agricolae kurtosis
	#' @importFrom agricolae skewness
	#' @importFrom agricolae SNK.test
	#' @importFrom lawstat levene.test
	#' @importFrom WRS2 med1way
	#' @importFrom WRS2 medpb
	#' @importFrom WRS2 t1way
	#' @importFrom WRS2 lincon
	#' @importFrom FSA dunnTest	
	#' @importFrom onewaytests bf.test
	#' @importFrom vioplot vioplot
	#' @importFrom DescTools DunnettTest
	#' @import methods
	#' @export
	#'
	#' @examples
	#' data(iris)
	#' m.test(iris[,1],iris[,5],verbose=TRUE, return=TRUE)
	#' m.test(iris[1:100,1],iris[1:100,5],verbose=TRUE, return=TRUE)
	#' m.test(iris[,2],iris[,5],verbose=TRUE, return=TRUE)
	#' m.test(iris[,3],iris[,5],verbose=TRUE, return=TRUE)
	#' m.test(iris[,4],iris[,5],verbose=TRUE, plot=FALSE, return=FALSE, boot=FALSE)
	#' m.test(iris[,1],iris[,5],verbose=TRUE, return=TRUE,control="setosa")
	#' m.test(iris[,2],iris[,5],verbose=TRUE, return=TRUE,control="virginica")
	#' m.test(iris[,3],iris[,5],verbose=TRUE, return=TRUE,control="setosa")
	#' m.test(iris[,4],iris[,5],verbose=TRUE, return=TRUE,control="setosa")
	m.test <- function (x = NULL, g = NULL, data = NULL, formula = NULL,
				 paired = FALSE, pair = NULL,
                   alpha = 0.05, control = NULL, verbose = TRUE, plot = TRUE,
                   return = TRUE, boot = TRUE, iter = 500, conf = 0.95,
				   maxcat=50,silent=TRUE,	
						code=FALSE,debug=FALSE){
	    if (code==TRUE) {verbose <- FALSE}
	    if (debug==TRUE) {verbose <- FALSE ; code=FALSE}
		exit <- function(ang=NULL,fr=NULL) {
			if ((is.null(ang)) | (length(ang)==1)) {ang <- fr}
			if ((return==TRUE) | (verbose==TRUE)) {
				stop(msg(ang,fr))
			} else if ((verbose==FALSE)&(return=FALSE)) {return(1)} # mode forçage en boucle d'automatisation
		}
		if (debug==TRUE) {cat(msg("\n","Contrôle de la variable d'appariement/répétitions.\n"))}
		
		########################
		# 	Si formula n'est pas fournie, mais que x semble être une formula
		########################
		if (is.null(formula)) {
		  if (inherits(x, "formula")) {
			if (debug) cat("\n`x` semble être une formule. Transfert vers `formula`.\n")
			formula <- x
			x <- NULL  # On supprime la valeur de `x` pour éviter des conflits
		  } else if (!is.numeric(x)) {
			exit("","Erreur : `x` doit être un vecteur numérique ou une formule.")
		  }
		}
		########################
		# 	Si data n'est pas fourni, mais que g semble être une data.frame
		########################
		if (is.null(data)) {
		  if (is.data.frame(g)) {
			# Vérifier si `g` contient au moins deux colonnes
			if (ncol(g) >= 2) {
			  # Vérifier si une colonne de `g` est identique à `x`
			  if (any(sapply(g, function(col) all(col == x)))) {
				if (debug) cat("\n`g` contient une colonne identique à `x`. `g` est attribué à `data` sans combinaison avec `x`.\n")
				data <- g
			  } else {
				if (debug) cat("\n`g` ne contient pas de colonne identique à `x`. `g` est combiné à `x` et attribué à `data`.\n")
				# Combiner `x` et `g` dans un nouveau data.frame
				data <- cbind(x = x, g)
			  }
			  g <- NULL  # `g` est attribué à `data`, donc on le met à NULL
			} else {
			  if (debug) cat("\n`g` est un data.frame avec moins de 2 colonnes. Conservé en tant que vecteur ou unique colonne.\n")
			  # Si `g` est un data.frame avec une seule colonne, on le traite comme un vecteur
			  g <- as.vector(g[[1]])
			}
		  } else if (is.vector(g) && !is.null(g)) {
			if (debug) cat("\n`g` est un vecteur. Conservé tel quel.\n")
			# Rien à faire, `g` reste inchangé
		  } else if (is.null(formula)) {
			# `g` n'est ni un vecteur ni un data.frame approprié
			exit("", "Erreur : `g` doit être un vecteur ou un data.frame si `data` est NULL.")
		  }
		}
		########################		
		# Sauvegarde du nom réel de `pair` dans `data` (ou extraction si nécessaire)
		########################
		pair_vector<-c()
		if (!is.null(data) && !is.null(pair)) {
			if (debug==TRUE) {cat(msg("","Tentative d'extraction de pair de data si data fourni."))}
		  if (is.character(pair) && pair %in% colnames(data)) {
			if (debug==TRUE) {cat(msg("\n","\tpair est bien le nom d'une colonne de data.\n"))}
			# `pair` est déjà le nom de la colonne
			#pair_name <- pair
		  } else if (is.numeric(pair) && pair <= ncol(data) && length(pair) == 1) {
			if (debug==TRUE) {cat(msg("\n","\tpair est à considérer comme l'index d'une colonne de data.\n"))}
			# `pair` est un index numérique, convertir en nom de colonne
			pair <- colnames(data)[pair]
		  } else if (length(pair) == nrow(data.frame(data))) {
			if (debug==TRUE) {cat(msg("\n","\tpair est un vecteur externe à data dont il faut extraire nom et contenu.\n"))}
			# `pair` est un vecteur externe, sauvegarder son contenu et son nom
			pair_vector <- pair
			pair_expr <- substitute(pair)  # Capturer l'expression originale
			pair <- tryCatch(
			  deparse(pair_expr),  # Récupérer le nom ou une expression
			  error = function(e) "pair"  # Utiliser un nom générique en cas d'erreur
			)
			if (is.null(pair) || pair == "") {
			  pair <- "pair"  # Défaut si aucun nom exploitable
			}
		  } else {
			if (verbose==TRUE) {
				warning(msg("Warning: pair is not corrected, and ignored.\n","Warning : 'pair' doit être un nom ou un index valide d'une colonne de 'data'.\npair est ignoré.\n"))
			} else {return(1)}		
		  }
		} else if (!is.null(pair)) {
			  if (debug==TRUE) {cat(msg("","Tentative d'extraction de pair alors que data non fourni.\n"))}	
			  # `pair` est un vecteur mais `data` est absent
			  pair_vector <- pair
			  pair_expr <- substitute(pair)
			  pair <- tryCatch(
				deparse(pair_expr),
				error = function(e) "pair"
			  )
			  if (is.null(pair) || pair == "") {
				pair <- "pair"
			  }
			  #print("pair");print(pair)
		}
		############################################
		# Mode formula ou mode classique
		############################################
		if (debug==TRUE) {cat(msg("\n","Extraction des données en fonction de la présence d'une formule\n"))}
		anova <- FALSE		
			########################
			# Si la formule est fournie
			#########################
		if (!is.null(formula) && inherits(formula, "formula")) {
			########################
			# Si data est fournie
			#########################
		    # Créer un environnement combinant le data.frame et l'environnement global
			if (!is.null(data) && is.data.frame(data)) {
			  env <- new.env(parent = parent.frame())
			  list2env(data, env)  # Ajouter les colonnes du data.frame à l'environnement
			  vars <- all.vars(formula) 
			  # Ajouter les variables globales référencées dans la formule
				# Ne pas utiliser 'var' comme nom de variable
				for (variable in vars) {
				  if (!exists(variable, envir = env, inherits = FALSE)) {
					assign(variable, get(variable, envir = parent.frame(), inherits = TRUE), envir = env)
				  }
				}
			  # Associer l'environnement fusionné à la formule
			  environment(formula) <- env
			########################
			# Si data est fournie et n'est pas au bon format
			#########################
			} else if(!is.null(data)&&!is.data.frame(data)) {
				exit("","Le paramètre 'data' doit être un data.frame valide ou NULL si la formule inclut les données.")
			}
			########################
			# Si pair est fournie
			#########################
			if (!is.null(pair)) {
					paired <- TRUE  # Si `pair` est spécifié, forcer `paired = TRUE`
					########################
					# Si pair est fourni, mais n'est ni un vecteur de l'environnement ni une colonne de data.
					#########################
					 if (!pair %in% colnames(data)&&length(pair_vector)==0) {
						stop("Erreur : la colonne `pair` spécifiée n'existe pas dans `data`.")
					 }
				    ########################
					# Si pair est fourni, mais a été omis de la formule
					#########################
					# Ajouter `pair` au `data` temporaire utilisé pour la formule si nécessaire
					if (!pair %in% all.vars(formula)) {
						formula_temp <- update(formula, paste0(". ~ . + ", pair))
					}
				} else {
					formula_temp <- formula
				}
			###################################
			# Extraire les données nécessaires à l'application de la formule	
			###################################
			# Tenter d'évaluer la formule avec l'environnement mis à jour
			mf <- tryCatch(
			  model.frame(formula_temp, data = data, na.action = na.omit, drop.unused.levels = TRUE),
			  error = function(e) {
					exit("","Erreur lors de l'évaluation de la formule. Vérifiez vos données et votre formule.")
				}
			)
			###################
			#
			# Trier les données en fonction des variables explicatives et de l'appariement (par catégories croisées)
			#
			####################
			if (debug == TRUE) {
			  cat(msg("\n", "Tri des données en fonction des variables explicatives et de l'appariement si fourni.\n"))
			}
			# Récupérer les noms des colonnes explicatives, en excluant la colonne quantitative
			explicatives <- colnames(mf)[-1]  # Supposons que la première colonne est quantitative
			# Vérification de la présence de la variable d'appariement
			if (!is.null(pair) && pair %in% explicatives) {
			  # Déplacer la colonne d'appariement à la fin de la liste pour tri final
			  explicatives <- c(setdiff(explicatives, pair), pair)
			}
			# Tri des données par toutes les colonnes explicatives
			mf <- mf[do.call(order, mf[explicatives]), ]
			if (debug == TRUE) {
			  cat(msg("\n", "Données triées :\n"))
			  print(head(mf))
			}

			# Mettre à jour les données triées dans `data` et `cat`
			#x <- mf_sorted[, 1]  # Colonne quantitative
			#cat <- mf_sorted[, -1]  # Autres colonnes explicatives
			# Gestion des formules avec plusieurs variables explicatives
			##########################
			#	n variables explicatives
			##########################
			if (ncol(mf) > 2) {
			  # On a data et formula, pas besoin de x et g
			  if (debug==TRUE) {cat(msg("","Plusieurs variables explicatives détectées.\n"))}
			  data <- mf
			  formula <- as.formula(formula)
			  #data <- cbind(data,cat)
			  if ((ncol(mf)==3)&(paired==TRUE)) {
				if (debug==TRUE) {cat(msg("","Mode ANOVA à 1 facteur sur données appariées.\n"))}
				x <- data[,1]
				g <- data[,2] 
			  
			  } else {
				if (debug==TRUE) {cat(msg("","Mode ANOVA à 2 facteurs ou plus activé.\n"))}
				anova <- TRUE # plus de 2 colonnes, plus d'une variable explicative ! ==> ANOVA à 2 facteurs ou +
			  }
			  
			  
			##########################
			#	1 variable explicative
			##########################
			} else {
				# Un raisonnement sur x et g suffit
				# En théorie, on pourrait effacer data et formula ou définir une formula simple ici.
				x <- mf[[1]]  # Variable dépendante (quantitative) 
				g <- mf[-1]    # Variable explicative (qualitatives)
				g <- as.vector(unlist(g))
			}	
			
		} else {
			########################
			#	Pas de formule fournie
			########################
			if (debug==TRUE) {cat(msg("\n","\tanalyse des données sans formule spécifiée.\n"))}
			
			# Si pas de formule, utiliser les arguments explicites 'data' et 'cat' sous la forme de simples  vecteurs
			if (is.null(x) || is.null(g)) {
				exit("","Si aucun 'formula' n'est fourni, les arguments 'x' et 'g' doivent être spécifiés.")
			}
			if (!is.numeric(x)) {
				exit("","'x' doit être un vecteur numérique représentant la variable quantitative.")
			}
			if (!is.factor(g)) {
			  g <- as.factor(g)  # Conversion en facteur si nécessaire
			}
			if (nrow(data.frame(x)) != nrow(data.frame(g))) {
				exit("","x et g ne présentent pas les mêmes dimensions\n")
			}
			
			
			
#
#		BORNE 206
#		Si pas de formule
#		paired est TRUE, il faut obligatoirement que pair soit fourni (sauf si cat ne contient que 2 catégories) - sinon message d'erreur.
# 		si pair est fourni, il faut forcer paired à être TRUE
#			il faut AUSSI que pair soit un vecteur effectif dans l'env
#			==> Et il faut donc aussi l'utiliser pour trier les données comme  à la borne 143 l'utiliser pour trier les données data et cat)
#		
#		Si 2 catégories dans cat, on conserve un vecteur numérique data et un vecteur de catégories cat.
# 		Sinon, il faut regrouper cat, data et pair dans un data.frame data (comme dans le cas où formula est fourni)
#		Et créer une formule formula <- Y~X+pair (en mettant les noms respectifs des vecteurs fournis en entrée data pour Y, cat pour X et pair...
#			
			if (paired == TRUE) {
				if (is.null(pair)) {
					# Aucun `pair` n'est spécifié
					if (length(unique(g)) == 2) {
						# Deux catégories : autoriser un test apparié direct
						if (verbose == TRUE) {cat("Mode apparié activé pour deux catégories.\n")}
						# Trier selon les catégories et maintenir la correspondance
						combined_data <- data.frame(x, g)
						combined_data <- combined_data[order(combined_data$g), ]
						x <- combined_data$x
						g <- combined_data$g
						data <- combined_data
						formula <- formula(x~g)
					} else {
						# Plus de deux catégories, `pair` obligatoire
						exit("","Erreur : `paired=TRUE` nécessite une variable `pair` si `cat` contient plus de deux catégories, sinon utiliser formula.")
					}
				} else {
					# `pair` est spécifié, il doit être ajouté à un tableau global si plus de 2 catégories.
					# ou sinon servir à trier data et cat si 2 catégories
					if (!is.null(data) && is.data.frame(data)) {
						# Vérifier si `pair` est valide
						if (is.character(pair) && pair %in% colnames(data)) {
							# Nom de colonne
							pair <- data[[pair]]
						} else if (is.numeric(pair) && pair <= ncol(data) && length(pair) == 1) {
							# Position de colonne
							pair <- data[[pair]]
						} else if (length(pair) == nrow(data.frame(data))) {
							# Vecteur externe valide
							pair <- pair
						} else {
							exit("","Erreur : `pair` doit être un nom, une position de colonne, ou un vecteur valide.")
						}
					} else {
						# `data` non spécifié, `pair` doit être un vecteur externe
						if (length(pair) != length(g)) {
							exit("","Erreur : `pair` doit avoir la même longueur que `g`.")
						}
					}

					# Trier les données selon `pair`
					
					########
					# A rectifier en indiquant si on a un jeu global (>2 catégories) ou si comme ici on reste à date et cat...
					########

					combined_data <- data.frame(x, g, pair)
					combined_data <- combined_data[order(combined_data$pair, combined_data$g), ]
					x <- combined_data$x
					g <- combined_data$g
					pair <- combined_data$pair
					data <- combined_data
					formula <- formula(x~g + Error(pair/g))
				}
			} else {
				# Pas d'appariements des données, la formule de base est
				formula <- formula(x~g)
			}
		}
		

	


		#	# Vérifier que chaque paire contient bien des observations pour chaque catégorie
		#	pair_check <- table(pair, cat)
		#	if (any(pair_check == 0)) {
		#		stop("Erreur : certaines paires ne contiennent pas de données pour toutes les catégories.")
		#	}
	  if (paired==TRUE) {if (debug) cat("Analyse appariée activée.\n")}
	  ###########################################
	  #	Fonctions internes
	  ###########################################
	  if (debug==TRUE) {cat(msg("\n","Compilation des fonctions de base.\n"))}
		###########
		#	Contrôler qu'une variable est discrète
		###########
	  discret.test <- function(vector) {
		return(length(unique(vector))/length(vector))
	  }
		###########
		#	Réaliser les tests post-hocs
		###########	  
	  posthoc <- function(x,g,alpha,normal=TRUE,number=length(unique(g)),var.equal=FALSE,
				control=c(),verbose=TRUE,code=FALSE,paired=paired) {
	  
	  #
	  #	paired ==TRUE, ==> Tout reste à faire... Il faut mettre un appariement dans les tests de base, croiser les catégories,
	  # # retravailler boots() et pairwise()
	  
			if (normal==TRUE) {
				if (number==2) {
					if (var.equal==TRUE) {
						if (code==TRUE){cat("t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=TRUE, paired=paired) #4)\n")}
						pvals <- t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=TRUE,paired=paired)$p.value
						which(unique(g)==control)-> ind_control
						if (length(ind_control)!=1) {
						  ########################
						  #	Pas de control
						  ########################
						  synth <- list()
						  synth$groups <- data.frame(categories=unique(g),groups=c("a","b"))
						  synth$p.value <- pvals
						  if (boot==TRUE) {
							synth$bootstrap <- boots(x,g,ctrl=FALSE,
													 type="mean",var.equal=TRUE,conf=conf,iter=iter,alpha=alpha, paired=paired)
						  }
						  if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
							cat("\tWarning! Bootstrap detects weaknesses in the significance of the results.\n")
						  }
						} else {
						  ########################
						  #	control
						  ########################
						  synth <- list()
						  starss <- c("","")
						  starss[-ind_control] <- ifelse(pvals <=0.001,"***",ifelse(pvals <=0.01,"**",ifelse(pvals <=0.05,"*","")))
						  synth$groups <- data.frame(categories=unique(g),group=starss)
						  synth$p.value <- pvals
						  if (boot==TRUE) {
							synth$bootstrap <- boots(x,g,ctrl=TRUE,type="mean",var.equal=TRUE,conf=conf,iter=iter,
								alpha=alpha, paired=paired)
						  }
						  if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
							cat("\tWarning! Bootstrap detects weaknesses in the significance of the results.\n")
						  }
						}

					} else if (var.equal==FALSE)  {
						if (code==TRUE){cat("t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=FALSE, paired=paired) #4)\n")}
						pvals <- t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=FALSE, paired=paired)$p.value
						which(unique(g)==control)-> ind_control
						if (length(ind_control)!=1) {
						  ########################
						  #	Pas de control
						  ########################
						  synth <- list()
						  synth$groups <- data.frame(categories=unique(g),groups=c("a","b"))
						  synth$p.value <- pvals
						  if (boot==TRUE) {
							synth$bootstrap <- boots(x,g,ctrl=FALSE,
													 type="mean",var.equal=FALSE,conf=conf,iter=iter,alpha=alpha, paired=paired)
						  }
						  if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
							cat("\tWarning! Bootstrap detects weaknesses in the significance of the results.\n")
						  }
						} else {
						  ########################
						  #	control
						  ########################
						  synth <- list()
						  starss <- c("","")
						  starss[-ind_control] <- ifelse(pvals <=0.001,"***",ifelse(pvals <=0.01,"**",ifelse(pvals <=0.05,"*","")))
						  synth$groups <- data.frame(categories=unique(g),group=starss)
						  synth$p.value <- pvals
						  if (boot==TRUE) {
							synth$bootstrap <- boots(x,g,ctrl=TRUE,
													 type="mean",var.equal=FALSE,conf=conf,iter=iter,alpha=alpha, paired=paired)
						  }
						  if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
							cat("\tWarning! Bootstrap detects weaknesses in the significance of the results.\n")
						  }
						}				
					
					}
				} else if (number > 2) {
					if (var.equal==TRUE) {
					
############
#	La partie code est à mettre à jour
############					
############
#	Ajouter Tuket et Waller-Ducan
############
					
						if (code==TRUE){cat("library(agricolae)#5a)\nSNK.test(mya,'g',alpha=",alpha,"))#5b)\n")}
						##########
						# Echantillons normaux - test de Newman-Keuls et pairwise sur test de Student
						##########
						formula <- formula(x~g)
						mya <- suppressWarnings(aov(data.frame(x,g), formula=formula))
						mynk <- SNK.test(mya,"g",alpha=alpha)
						if (verbose==TRUE) {cat("5) Post-hoc Student and Newman-Keuls tests (pairwise.t.test() & SNK.test() for Newman-Keuls) \n")}				
						if (paired == FALSE) {
							synth <- pairwise(x,g,type="mean",pool.sd=TRUE, alpha=alpha,control=control,boot=boot,conf=conf,iter=iter)
						} else if (paired==TRUE) {
							# l'équivalence de variance n'est plus prise en compte
							synth <- pairwise(x,g,type="mean", alpha=alpha,control=control,boot=boot,conf=conf,iter=iter,paired=paired)
						}
						match(synth$groups[,1],rownames(mynk$groups)) -> ind_temp
						synth$groups <- data.frame(synth$groups , "SNK"=mynk$groups$groups[ind_temp])
						cat1 <- unique(unlist(strsplit(synth$groups$groups,"")))
						cat2 <- unique(unlist(strsplit(mynk$groups$groups,"")))
						rownames(synth$groups) <- rep(c(),nrow(synth$groups))
						which(unique(g)==control)-> ind_control
						# if control == TRUE
						if (length(control)>0) {
							synth$Dunnett <- DunnettTest(x,g, control = control)
							if (verbose==TRUE) {cat("6) See also post-hoc Dunnett test for the control (DunnettTest() from {DescTools}).\n")}
							if (code==TRUE){cat("library(DescTools)#6a)\nDunnettTest(x,g,control=",control,")#6b)\n")}
						}
						if ((verbose==TRUE) & (length(cat1)!=length(cat2)) & (length(ind_control)!=1)) {warning("Warning! pairwise.t.test() and SNK.test() don't return the same number of groups.")}
						if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
							cat("\tWarning! Bootstrap detects weaknesses in the significance of the results.")
						}
					} else if (var.equal==FALSE) {				
						if (code==TRUE){cat("result <- pairwise.t.test(x,g,pool.sd=FALSE)#5a)\nlibrary(KefiR)#5b)\ncatego(result)#5c)\n")}
						synth <- pairwise(x,g,type="mean",pool.sd=FALSE,alpha=alpha,control=control,boot=boot,
						conf=conf,iter=iter,paired=paired)
						if (verbose==TRUE) {
							if (paired==TRUE) {
								cat("5) Post-hoc Student test (pairwise.t.test(pool.sd=FALSE,paired=TRUE))\n")
							} else {
								cat("5) Post-hoc Student test (pairwise.t.test(pool.sd=FALSE))\n")
							}
						}
						if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
						  cat("\tWarning! Bootstrap detects weaknesses in the significance of the results.\n")
						}								
					}
				}
			} else if (normal==FALSE) {
				##########
				# Echantillons non-normaux - 
				##########
				if (number==2) {		
					if (code==TRUE){cat("wilcox.test(x[g==unique(g)[1]],x[g==unique(g)[2]])  #2)\n")}
					pvals <- suppressWarnings(wilcox.test(x[g==unique(g)[1]],x[g==unique(g)[2]],paired=paired))$p.value
					which(unique(g)==control)-> ind_control
					if (length(ind_control)!=1) {
					  synth <- list()
					  synth$groups <- data.frame(categories=unique(g),groups=c("a","b"))
					  synth$p.value <- pvals
					  if (boot==TRUE) {
						synth$bootstrap <- boots(x,g,ctrl=FALSE,
												 type="median",conf=conf,iter=iter,alpha=alpha,paired=paired)
					  }
					  if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
						cat("\tWarning! Bootstrap detects weaknesses in the significance of the results.\n")
					  }
					} else {
					  synth <- list()
					  starss <- c("","")
					  starss[-ind_control] <- ifelse(pvals <=0.001,"***",ifelse(pvals <=0.01,"**",
																				ifelse(pvals <=0.05,"*","")))
					  synth$groups <- data.frame(categories=unique(cat),group=starss)
					  synth$p.value <- pvals
					  if (boot==TRUE) {
						synth$bootstrap <- boots(x,g,ctrl=TRUE,
												 type="median",var.equal=FALSE,conf=conf,iter=iter,alpha=alpha,paired=paired)
					  }
					  if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
						cat("\tWarning! Bootstrap detects weaknesses in the significance of the results.\n")
					  }
					}
				
				} else if (number > 2) {
					  #########################
					  #		Plus de 2 groupes non normaux
					  #########################
					  # Prévoir un Wilcoxon pour TOUS apparié ou Non
					  # Suivi de Dunn si non apparié
					  # trimm ou medpb en plus selon si non apparié.
					  # nemenyi si apparié.
# si paired PMCMRplus::frdAllPairsNemenyiTest(a~b|c, data=dt)
				
					  ###########
					  #		TEST DE DUNN
					  ###########
					  if (code==TRUE){cat("library(FSA) #7a)\nFSA::dunnTest(x ~ g, method = 'holm' #7b)\n")}
					  synth2 <- pairwise(x,g,type="dunn",alpha=alpha,control=control,boot=boot,conf=conf,iter=iter)				  
					if (var.equal==TRUE) {	
#######
#	BORNE 554- introduire la fonction getoutiler de rstatix pour identifier le trimage optimal.
###########
						#################
						#	var.equal=T ==> trimm
						#################
						if (code==TRUE){cat("library(WRS2) #8a)\nlincon(x~g) #8b)\n")}
						synth <- pairwise(x,g,type="lincon",alpha=alpha,control=control)
						match(synth2$groups[,1],synth$groups[,1]) -> ind_temp				
						synth$groups <- data.frame(categories= synth2$groups[,1],"Dunn"=synth2$groups[,2], "Lincon"=synth$groups[ind_temp,2])

					} else if (var.equal==FALSE) {
						#################
						#	var.equal=F ==> median
						#################			
					  if (code==TRUE){cat("pairwise.wilcox.test(x,g,p.adjust.method='BH') #8)\n")}

					  if (verbose==TRUE) {cat("9) Wilcoxon-Mann-Whitney test (pairwise.wilcox.test()) \n")}
					  synth <- pairwise(x,g,type="median",alpha=alpha,control=control,boot=boot,conf=conf,iter=iter,paired=paired)
					  match(synth2$groups[,1],rownames(synth$groups)) -> ind_temp			  
					  synth$groups <- data.frame(categories= synth2$groups[,1],"Dunn"=synth2$groups[,2], "Wilcoxon_holm"=synth$groups[ind_temp,2])
					  if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
						cat("\tWarning! Bootstrap detects weaknesses in the significance of the results.\n")
					  }

					}		
				}
			}
			return(synth)
		}
		
		
	###################
# paired doit être développé dans cette fonction : mis en argument mais tout à faire.	
		
	  boots <- function(x,g,ctrl=FALSE,type="mean",var.equal=FALSE,conf=0.95,iter=500,alpha=alpha,paired=paired) {
		pvals <- c()
		for (i in 1:iter) {
		  if (type=="mean") {
			temp <- t.test(sample(x[g==unique(g)[1]],replace=TRUE),sample(x[g==unique(g)[2]],replace=TRUE),var.equal=var.equal,paired=paired)$p.value
		  } else if (type=="median") {
			#temp <- wilcox.test(sample(data[cat==unique(cat)[1]],replace=TRUE),sample(data[cat==unique(cat)[2]],replace=TRUE))$p.value
			temp <- wilcox.test(sample(x[g==unique(g)[1]],replace=TRUE),sample(x[g==unique(g)[2]],replace=TRUE),exact=FALSE,paired=paired)$p.value
		  } else if (type=="ks") {
			ech1 <- sample(x[g==unique(g)[1]],replace=TRUE)
			ech2 <- sample(x[g==unique(g)[2]],replace=TRUE)
			ech1 <- (ech1 - median(ech1))/sd(ech1)
			ech2 <- (ech2 - median(ech2))/sd(ech2)
			temp <- ks.test(ech1,ech2)$p.value
		  }
		  pvals <- c(pvals,temp)
		}
		pvals <- quantile(pvals,probs=conf,na.rm=T)
		if (ctrl == TRUE) {
		  if (pvals <= alpha) {
			synth <- list()
			starss <- c("","")
			starss[-ind_control] <- ifelse(pvals <=0.001,"***",ifelse(pvals <=0.01,"**",
																	  ifelse(pvals <=0.05,"*","")))
			synth$groups <- data.frame(categories=unique(g),group=starss)
			synth$p.value <- pvals
		  } else {
			synth <- list()
			synth$groups <- data.frame(categories=unique(g),group=c("",""))
			synth$p.value <- pvals
		  }
		} else if (ctrl==FALSE) {
		  synth <- list()
		  if (pvals <= alpha) {
			synth$groups <- data.frame(categories=unique(g),groups=c("a","b"))
			synth$p.value <- pvals
		  } else {
			synth$groups <- data.frame(categories=unique(g),groups=c("a","a"))
			synth$p.value <- pvals
		  }
		}
		return(synth)
	  }
	  normality <- function(x,g) {
		subnormality <- function(vector) {
			if (length(vector)<=100) {
				return(shapiro.test(as.numeric(vector))$p.value)
			} else if (length(vector)<=1000) {
				return(jb.norm.test(vector)$p.value)
			} else {
				return(1)
			}
		}
		pvals <- by(x,g,subnormality)
		return(pvals)
	  }
	  skew <- function(vector) {return(abs(skewness(vector)))}
	  skew2 <- function(vector) {return(skewness.norm.test(vector)$p.value)}
	  kurto <- function(vector) {if (is.na(abs(kurtosis(vector)))){return(10)} ; return(abs(kurtosis(vector)))}
	  kurto2 <- function(vector) {return(kurtosis.norm.test(vector)$p.value)}
	  if (any((is.na(x)))|(any((is.na(g))))){
		if (verbose==TRUE) {cat("Warning! Missing values.\n")}
		temp <- data.frame(x,g)
		temp <- na.omit(temp)
		x <- temp[,1]
		g <- temp[,-1]
	  }
	  
	  
	  if (debug==TRUE) {cat(msg('Analysis of the presence of infinite values.\n','Analyse de la présence de valeurs infinies.\n'))}
	  if(any(!is.finite(x))) {
		exit("","Error! Infinite values in data. Analysis impossible.\n")
	  }	  

	  if (debug==TRUE) {cat(msg('Control of repetitions, number of values per category.\n','Contrôle des répétitions, du nombre de valeurs par catégories.\n'))}
	  
#	  print("x") ; print(x[1:5])#
#	  print("g") ; print(g[1:5])
#	  print("data") ; print(head(data))
#	  print("formula") ; print(formula)
	  
	  ###################
	  # Si les variables explicatives ne sont pas numériques et qu'il y a qu'une seule valeur par variables explicatives croisées,
	  # alors, l'on va autoriser paired=TRUE et dans ce cas :
		# pair reçoit le nom de la dernière colonne de data
		# message d'alerte pour prévenir que les catégories croisées donnent toute 1 valeur
		# et que la variable x est désignée automatiquement comme variable d'appariement.
		# invitation de l'utilisateur à utiliser les arguments paired et pair pour paramétrer selon son goût
		# si il ne reste qu'une variable explicative en plus de pair (soit 3 colonnes en tout dans data), ANOVA<-FALSE
		# message if(debug==TRUE)&ANOVA==FALSE {cat(msg("","Retour vers un scénario d'ANOVA à 1 facteur sur données appariées."))}
		# message if(debug==TRUE)&ANOVA==FALSE {cat(msg("","Retour vers un scénario d'ANOVA à 2 facteurs sur données appariées."))}
	  ###################
	  
if (debug == TRUE) {cat(msg("\n", "Analyse des variables explicatives pour déterminer si paired=TRUE peut être activé automatiquement.\n"))}

# Vérifier si les variables explicatives sont non numériques
if (!all(sapply(data[, -1], is.numeric))) { 
    # Calcul des combinaisons croisées des variables explicatives
    combinaisons <- table(data[, -1]) 
    
    if (all(combinaisons == 1)) { # Vérifier si toutes les combinaisons donnent une seule valeur
        # Activer `paired=TRUE`
        paired <- TRUE
        
        # Attribuer la dernière colonne comme variable d'appariement
        pair <- colnames(data)[ncol(data)]
        
        # Messages d'alerte
        cat(msg("","Attention : Les catégories croisées des variables explicatives donnent toutes une seule valeur.\n"))
        cat(msg("","La variable", pair, "est désignée automatiquement comme variable d'appariement.\n"))
        cat(msg("","Veuillez utiliser les arguments `paired` et `pair` pour ajuster les paramètres selon votre goût.\n"))
        
        # Vérifier le nombre de colonnes restantes dans `data`
        if (ncol(data) == 3) { 
            # Une seule variable explicative restante
            ANOVA <- FALSE
            if (debug == TRUE && !ANOVA) {
                cat(msg("", "Retour vers un scénario d'ANOVA à 1 facteur sur données appariées.\n"))
            }
        } else if (ncol(data) > 3) { 
            # Plus d'une variable explicative restante
            #ANOVA <- TRUE
            if (debug == TRUE && ANOVA) {
                cat(msg("", "Retour vers un scénario d'ANOVA à 2 facteurs sur données appariées.\n"))
            }
        }
    }
}
	  
	  
	  if(anova==FALSE) {
	  	  if(max(by(x,g,length),na.rm=T)<3) {
				if(return==FALSE) {
					if (verbose==TRUE) {cat("Error! No enough values in the samples.\n")}
					return(1)
			    } else {if (verbose==TRUE) {warning("Warning! No enough values in the samples.\n")}}
		  }
		  if (any(is.na(by(x,g,length)))) {
			warning("Warning! Some levels do not have corresponding data.")
			g <- factor(g)
			if (length(unique(g))<2) {stop("Not enough levels presenting g.")}
		  }
		  if (debug==TRUE) {cat(msg("Ignore categories with insufficient values.\n","Ignorer les catégories ne présentant pas assez de valeurs.\n"))}
		  
		  
		  
		  if(min(by(x,g,length),na.rm=T)<3) {
		  
	  
		  
			if (verbose==TRUE) {warning("Warning! No enough values for some samples. The categories concerned are ignored.")}
			which(by(x,g,length)<3)-> ind_temp
			'%notin%' <- Negate('%in%')
			x <- x[g%notin%names(ind_temp)]
			g <- g[g%notin%names(ind_temp)]
			g <- as.factor(g)
			droplevels(g)->g
		  }
		  
		  if (debug==TRUE) {cat(msg(".\n","Stopper le programme si variabilité nulle.\n"))}
 
		  if(max(by(x,g,var,na.rm=T),na.rm=T)==0) {
			if (verbose==TRUE) {stop("Error! No variability in samples.")}
			return(1)
		  }
		  if (debug==TRUE) {cat(msg("Check for the presence of the control category in the categorical variable.\n","Contrôler la présence de la catégorie de contrôle dans la variable catégorielle.\n"))}
		  if ((length(control)>0)&&(!control %in% g)) {
			exit("","Erreur : 'control' n'est pas une catégorie présente dans 'g'.")
		  }
		  if (debug==TRUE) {cat(msg("\n","Ignorer les catégories qui ne varient pas.\n"))}	  
		  if(min(by(x,g,var,na.rm=T),na.rm=T)==0) {
			if (verbose==TRUE) {warning("Warning! Some samples do not vary. Non-variable categories are ignored.")}
			which(by(x,g,var,na.rm=T)==0)-> ind_temp
			'%notin%' <- Negate('%in%')
			x <- x[g%notin%names(ind_temp)]
			g <- g[g%notin%names(ind_temp)]
			g <- as.factor(g)
			droplevels(g)->g
		  }
		  if (debug==TRUE) {cat(msg("\n","Contrôler le nombre de catégories.\n"))}
		  if (length(unique(g))<=1) {
			exit("","Error! Only one category.")
		  }
		  if (length(unique(g))>maxcat) {
			exit("","Error! Too much categories.")
		  }
		  if (plot==TRUE) {
			if (debug==TRUE) {msg("","Plot.")}
			boxplot(x~g,col="cyan")
			vioplot(x~g,col="#00AA0077",add=TRUE)
			stripchart(x~g,col="#FF000088",pch=16,vertical=TRUE,add=T,method="jitter",jitter=1/(length(unique(g))+2))
		  }
	  } else if (anova==TRUE) {
	    # Construire la table des combinaisons des catégories
		# Extraire les données de la formule
		data_model <- model.frame(formula)

		# Identifier les variables explicatives (sans la réponse)
		variables_explicatives <- attr(terms(formula), "term.labels")
		
		# Vérifier si toutes les variables explicatives sont numériques
		non_numeriques <- variables_explicatives[!sapply(variables_explicatives, function(var) is.numeric(data_model[[var]]))]

		if (length(non_numeriques) > 0) {
		  # Ne traiter que les variables non numériques comme catégoriques
		  variables_categoriques <- non_numeriques
		  
		  # Construire la table des combinaisons pour les variables catégoriques uniquement
		  combinaisons <- table(data_model[variables_categoriques])
		  
		  # Vérification des combinaisons croisées
		  if (min(combinaisons) == 0) {
			warning("Certaines catégories croisées des variables catégoriques ne sont pas renseignées. Vérifiez vos données.")
		  } else {
			if (debug==TRUE){msg("","Les catégories croisées des variables catégoriques sont bien renseignées.")}
		  }
		} else {
		  if (debug==TRUE){msg("","Toutes les variables explicatives sont numériques. Aucun contrôle de croisements n'est nécessaire.")}
		}	
		# paired est par défaut en 'auto'
		# si paired == TRUE, un contrôle est effectué pour vérifier qu'il y a autant de valeurs pour chaque catégories de cat.
		# Analyser tous types de formules Conditions ~ Conditions | Individus ou Conditions + Error (Individus/Conditions) ... etc.
		# Analyser dès qu'il y a des croisements des facteurs avec table() toutes à 1 (tout croisement renseigné) dans un Individus que appariés (signaler message). Dans ce cas on passe à paired = TRUE
		# ==> un message averti qu'on passe en apparié, et le nom du vecteur d'individus (ex : "Individus") est attribué à pair.
		# Enfin pour chaque catégorie de cat, data est trié dans le même ordre des individus (afin de pouvoir comparar pair par pair en post-hoc).
		# 2 catégories ! Autoriser le paired en Wilcoxon et Student
		# >2 catégories : => Passer au test de friedman ou une aov sinon de ce type aov(Conditions + Error (Individus/Conditions))
		# envisager selon le test une mise en forme appropriée de la formule donnée en entrée, ou de l'intégration de la variable en pair.
		# Remarque : que faire quand variances non égales ? aov(), friadman, autres ?
		# Prévoir aussi le contrôle des assomptions 1)  Normalité des résidus, 2) Homogénéité des variances et des co-variances (puisque les observations ne sont plus indépendantes puisqu'on mesure plusieurs fois les individus).
		# Nemiyi en post-hoc à prévoir si friedman à ajouter à la fonction posthoc
	  
	  }



	  discret <- discret.test(x)
	  pvals <- normality(x,g)
	  check_normality <- c()
	  check_number <- c()
	  check_variance_equal <-  c()
	  ##########################
	  # Correction de Sidak
	  ##########################
	  if (debug==TRUE) {msg("","Sidak's correction . Bonferroni would be more secure.")}
	  pval <- 1-(1-alpha)^(1/length(unique(g)))
	  #	
	  if (code==TRUE){
		cat(paste0("alpha1 <- 1-(1-",alpha,")^(1/length(unique(g))) # Sidak correction of alpha for test repetitions (like Shapiro, Skewness...)\n"))
		if (min(by(x,g,length))<=100) {
			cat("by(x,g,shapiro.test)#1) Control of the normality of small samples (<100)\n")
		}
		if (any((by(x,g,length)<=1000)&(by(x,g,length)>100))) {
			cat("#1A)\nby(x,g,jb.norm.test)#1B) Control of the normality of big samples (<1000)\n")
		}
		if (max(by(x,g,length))>1000) {
			cat("#1) Central limit theory: enough values for some samples to not have to check normality.\n")
		}
	  }
	  ################################################################
	  #
	  #
	  #		NON-NORMAL
	  #
	  #
	  ################################################################
	  if (min(pvals) <= pval) { # NON-NORMAL
		check_normality <- FALSE
		if (verbose==TRUE) {cat("1) Control of normality - Shapiro-Wilk test (<=100), Jarque-Bera (<=1000) or nothing (>1000).\n\tAnalyse of values by sample (shapiro.test() & jb.norm.test()) -\t\nOne or more non-normal samples. min(p-value) : ",min(pvals),"with Sidak correction of alpha to ",pval,"\n")}
		sd_cr <- by(x,g,sd,na.rm=T) ; median_cr <- by(x,g,median,na.rm=T)
		data_cr <- x
		for (i in names(median_cr)) {
			data_cr[g==i] <- (data_cr[g==i]-median_cr[which(names(median_cr)==i)])/sd_cr[which(names(sd_cr)==i)]
		}
		temp <- pairwise(data_cr,g,type="ks",silent=silent,boot=FALSE)
		ks_result <- min(unlist(temp$p.value),na.rm=T)
		if (code==TRUE){cat("length(unique(g))#2)\n")}
		###################################################
		#			NON-NORMAL		2 categories
		###################################################
		if (length(unique(g))==2) { 							# 2 categories
		  check_number <- 2
		  if (verbose==TRUE) {cat("2) Two categories.\n")}
		  sk <- max(by(x,g,skew))
		  sk2 <- min(by(x,g,skew2))
		  ku <- max(by(x,g,kurto))
		  ku2 <- min(by(x,g,kurto2))
		  #jb <- min(by(x,g,jarquebare))
		  tt <- min(by(x,g,length))
		  if (code==TRUE){cat("library(agricolae)\nby(x,g,skewness)\nby(x,g,skewness.norm.test)\nby(x,g,kurtosis)\nby(x,g,kurtosis.norm.test)\nby(x,g,length)#3)\n")}
		  ###################################################
		  #			NON-NORMAL		2 categories		Acceptable for t.test()
		  ###################################################
		  if ((sk2>pval)&(ku2>pval)&(tt>100)&(discret>0.05)) { #(jb>alpha)
			check_normality <- TRUE # Retour à une forme de normalité
			check_variance_equal <-  FALSE	  
			if (verbose==TRUE) {cat("3) Jarque–Bera test & Skweness & Kurtosis limits and Length of sample (jb.norm.test() & swkeness() & skewness.norm.test() & kurtosis() & kurtosis.norm.test() & length()) - Distribution and length of samples acceptable.\n")
			  #cat("\tJarque-Bera test - normality acceptable (min(p.value)) :",jb,"\n")
			  cat("\tSkweness limite (max and absolute):",sk,"\n")
			  cat("\tSkweness bootstrapped (min(p.value)):",sk2,"\n")
			  cat("\tKurtosis limite (max and absolute):",ku,"\n")
			  cat("\tKurtosis bootstrapped (min(p.value)):",ku2,"\n")
			  cat("\tSample length (minimal):",tt,"\n")
			}
			if (code==TRUE){cat("t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=FALSE)   #4)\n")}
			pvals <- t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=FALSE)$p.value
			
			if (verbose==TRUE) {
				if (pvals <= alpha) {
					cat("4) Student Test (t.test())- Significant differences between samples.\n")
				} else {cat("4) Student test (t.test()) - Non-significant differences between samples.\n")
				}
			}	
			###################################################
			#			NON-NORMAL		2 categories		Non acceptable for t.test()
			###################################################
		  } else {
			###################################################
			#			NON-NORMAL		2 categories		Non acceptable for t.test()		Discret
			###################################################
			check_variance_equal <-  FALSE
			if (verbose==TRUE) {
			  if (discret <= 0.05) {
				cat("3) The number of unique values suggests the presence of discrete data : ",discret*100,"%\n")
				pvals <- mood.test(x[g==unique(g)[1]],x[g==unique(g)[2]])$p.value
				if (pvals <= alpha) {
				  cat("3) Brown and Mood test (mood.test()) - The medianes are different and data need to be centered on the mediane for ansari.test(). p-value : ",pvals,"\n")
				  by(x,g,function(x){return(x-median(x))})->cent_med
				  pvals <- ansari.test(unlist(cent_med[1]),unlist(cent_med[2]))$p.value
				} else {
				  cat("3) Brown and Mood test (mood.test()) - The medianes are the same. p-value : ",pvals,"\n")
				  pvals <- ansari.test(x[g==unique(g)[1]],x[g==unique(g)[2]])$p.value
				}
				if (pvals < alpha) {
				  cat("4) Ansari-Bradley test (ansari.test()) - Data do not have the same variance. p-value: ",pvals,"\n")
				} else {
				  cat("4) Ansari-Bradley test (ansari.test()) - Data have the same variance. p-value: ",pvals,"\n")
				}
				###################################################
				#			NON-NORMAL		2 categories		Non acceptable for t.test()		Wilcox comparison
				###################################################
			  } else {
				if ((sk2<pval)|(ku2<pval)|(tt<100)) { # (jb<alpha)
				  cat("3) Skweness & Kurtosis limits and Length of sample (swkeness() & skewness.norm.test() & kurtosis() & kurtosis.norm.test() & length()) - Bad distribution of data (asymmetry, spread) or insufficient length.\n")
				  #cat("\tJarque-Bera test - normality acceptable (min(p.value)) :",jb,"\n")
				  cat("\tSkweness limite (max and absolute):",sk,"\n")
				  cat("\tSkweness bootstrapped (min(p.value)):",sk2,"to compare to Sidak's corrected alpha ",pval,"\n")
				  cat("\tKurtosis limite (max and absolute):",ku,"\n")
				  cat("\tKurtosis bootstrapped (min(p.value)):",ku2,"to compare to Sidak's corrected alpha ",pval,"\n")
				  cat("\tSample length (minimal):",tt,"\n")
				}
				if (ks_result < pval) {
				  cat("4) Kolmogorov-Smirnov test (ks.test()) on median-centered and reduced data -\n\tWarning! the data do not have the same distribution. p-value: ",ks_result,"\n\tby comparing with Sidak corrected alpha ",pval,"\n\tThe Mann-Whitney-Wilcoxon test will be less reliable.\n\tWarning! For wilcox.test() : Please, check graphically that the samples have the same distribution.\n")
				} else {
				  cat("4) Kolmogorov-Smirnov test (ks.test()) on median-centered and reduced data -\n\tThe samples have the same distribution. p-value: ",ks_result,"\n\tby comparing with Sidak corrected alpha ",pval,"\n\tThe Mann-Whitney-Wilcoxon test will be reliable.\n")
				}
			  }
			}
			pvals <- suppressWarnings(wilcox.test(x[g==unique(g)[1]],x[g==unique(g)[2]]))$p.value
			if (verbose==TRUE) {
				if (pvals <= alpha) {
					cat("5) Wilcoxon-Mann-Whitney test (wilcox.test()) - Significant differences between samples. p-value: ",pvals,"\n")
				} else {
					cat("5) Wilcoxon-Mann-Whitney test (wilcox.test()) - Non-significant differences between samples. p-value : ",pvals,"\n")
				}
			}
		  }
		  ###################################################
		  #			NON-NORMAL		>2 categories
		  ###################################################
		} else { 											# > 2 categories
		  check_number <- 3

		  if (verbose==TRUE) {cat("2) More than two categories.\n")}
		  sk <- max(by(x,g,skew))
		  sk2 <- min(by(x,g,skew2))
		  ku <- max(by(x,g,kurto))
		  ku2 <- min(by(x,g,kurto2))
		  #jb <- min(by(x,g,jarquebare))
		  if (code==TRUE){
			#cat("#3a)\nby(x,g,jb.norm.test)#3b)\nlibrary(agricolae)#3c)\nby(x,g,skewness)#3d)\nby(x,g,skewness.norm.test)#3e)\nby(x,g,kurtosis)#3f)\nby(x,g,kurtosis.norm.test)#3g)\nby(x,g,length)#3h)\n")
			cat("#library(agricolae)#3a)\nby(x,g,skewness)#3b)\nby(x,g,skewness.norm.test)#3c)\nby(x,g,kurtosis)#3d)\nby(x,g,kurtosis.norm.test)#3e)\nby(x,g,length)#3f)\n")
			cat("library(lawstat)#4a)\nlevene.test(x,g)#4b)\n")
			cat("library(onewaytests)#5a)\nbf.test(x~g,data=data.frame(x,'g'=factor(g)))#5b)\n")
		  }
		  pvals2 <- suppressWarnings(bf.test(x~g,data=data.frame(x,"g"=factor(g)),verbose=FALSE))$p.value
		  pvals <- suppressWarnings(levene.test(x,g))$p.value
		  if (verbose==TRUE) {
			
			if (((pvals <= alpha)&(pvals2 <= alpha))|((pvals > alpha)&(pvals2 > alpha))) {
				cat("3) Consistency in testing of Levene and Brown-Forsyth results.\n")
				cat("\tLevene p-value : ",pvals," - Brown-Forsyth p-value : ",pvals2,"\n")
			} else {
				cat("3) Inconsistent testing of Levene and Brown-Forsyth.\n")
				cat("\tLevene p-value : ",pvals," - Brown-Forsyth p-value : ",pvals2,"\n")
				#cat("3') Only Jarque-Bera is taking in account.\n")
				#cat("\tJarque-Bera test - normality acceptable (min(p.value)) :",jb,"\n")
			}
		  }
			if (code==TRUE){cat("kruskal.test(x,g) #6)\n")}
			# Si verbose : blabla
			#print("pval") ; print(pval)
			if ((sk2<pval)|(ku2<pval)) {
				if (verbose==TRUE) {
					  cat("4) Skweness & Kurtosis limits (swkeness() & kurtosis()) Bad distribution of data (asymmetry, spread).\n")
					  cat("\tSkweness limite (max and absolute):",sk,"\n")
					  cat("\tSkweness bootstrapped (min(p.value)):",sk2," to compare to Sidak's corrected alpha ",pval,"\n")
					  cat("\tKurtosis limite (max and absolute):",ku,"\n")
					  cat("\tKurtosis bootstrapped (min(p.value)):",ku2," to compare to Sidak's corrected alpha ",pval,"\n")
				} 
			} else {
				if (verbose==TRUE) {
				  cat("4) Skweness or Kurtosis limits & Brown-Forsyth test (swkeness() & kurtosis() & bf.test()) - The distribution of values and sample variances are acceptable.\n")
				  cat("\tSkweness limite (max and absolute):",sk,"\n")
				  cat("\tSkweness bootstrapped (min(p.value)):",sk2," to compare to Sidak's corrected alpha ",pval,"\n")
				  cat("\tKurtosis limite (max and absolute):",ku,"\n")
				  cat("\tKurtosis bootstrapped (min(p.value)):",ku2," to compare to Sidak's corrected alpha ",pval,"\n")
				}
				if ((pvals > alpha)&(pvals2 > alpha)) {
					check_variance_equal <-  TRUE
					check_normality <-  TRUE
				}
			}
			if (check_normality == TRUE) {
				###################
				#		Passerelle de retour vers la normalité
				###################
				#retour vers SNK
				if (verbose==TRUE) {cat("==> Retour vers une forme de normalité.\n")}
				formula <- formula(x~g)
				mya <- suppressWarnings(aov(data.frame(x,g), formula=formula))
				if (code==TRUE){cat("mya <- aov(data.frame(x,g), formula=x~g) #7)\n")}
				pvals <- summary(mya)[[1]][["Pr(>F)"]][1]
				if (verbose==TRUE) {
					if (pvals<=alpha) {										# Significant AOV
					  cat("5) One-way analysis of variance (aov()) - Significant differences between samples. p-value:",pvals,"\n")
					} else {											#	 Non-significant AOV
					  cat("5) One-way analysis of variance (aov()) - Non-significant differences between samples. p-value:",pvals,"\n")
					}
				}
			} else {
				##################
				#	Test de Fligner
				##################
				pvals3 <- fligner.test(x,g)$p.value
				if (is.na(pvals)) {
				  if (verbose==TRUE) {cat("5) Fligner-Killeen test (fligner.test()) - Error, return NA.\n")}
				  return(pvals)# FALSE
				}
				##################
				#	Test de Kruskal
				##################
				pvals <- kruskal.test(x,g)$p.value
				if (verbose==TRUE) {
				  if (pvals3<=alpha) {
					cat("5) Fligner-Killeen test (fligner.test())Significant differences of variance between samples. p-value:",pvals3,"\n")
				  } else {
					cat("5) Fligner-Killeen test (fligner.test())Non-significant differences of variance between samples. p-value",pvals3,"\n")
				  }
				  temp <- pairwise(x,g,type="ks",silent=silent,boot=boot)$p.value
				  ks_result <- min(unlist(temp),na.rm=TRUE)
				  if (ks_result <= pval) {
					cat("6) Kolmogorov-Smirnov test (ks.test()) on median-centered and reduced data -\n\tWarning! the samples do not have the same distribution. min(p-value) : ",ks_result,"\n\tby comparing with Sidak corrected alpha ",pval,"\n\tThe Kruskal-Wallis test and Mann-Whitney-Wilcoxon test will be less reliable.\n\tPlease, check graphically the samples distributions.\n")
				  } else {
					cat("6) Kolmogorov-Smirnov test (ks.test()) on median-centered and reduced data -\n\tThe samples have the same distribution. min(p-value) : ",ks_result,"\n\tby comparing with Sidak corrected alpha ",pval,"\n\tGood accuracy expected on the tests of Kruskal-Wallis and Mann-Whitney-Wilcoxon\n")
				  }
				  
				  if (pvals <= alpha) {
					cat("7) Kruskal-Wallis test (kruskal.test()) - At least one sample appears to show a difference. p-value:",pvals,"\n")
				  } else {
					cat("7) Kruskal-Wallis test (kruskal.test()) - No different sample a priori. p-value:",pvals,"\n")
				  }
				}
				if ((return==TRUE) | (verbose==TRUE)) {
				  ############
				  # 	Allons jusqu'au bout du raisonnement
				  ############
				
				
				  if (pvals3<=alpha) {
					#################
					#	var.equal=F ==> median
					#################
					check_variance_equal <-  FALSE
					pvals3 <- med1way(x~g)$p.value
					if (is.na(pvals3)) {
					  if (verbose==TRUE) {cat("8) Oneway ANOVA of medians (med1way()) - Failed, return NA. The Kruskal-Wallis test should be used for interpretation.\n")}
					} else {
					  if (pvals3 <= alpha) {
						if (verbose==TRUE) {cat("8) Oneway ANOVA of medians (med1way()) - Significant differences between the median of samples. p-value:",pvals3,"\n")
						  if (pvals > alpha) {
							cat("\tWarning! The Kruskal-Wallis test and anova on medians give contradictory results.\n")
						  }
						}
					  } else if (pvals3 > alpha) {
						if (verbose==TRUE) {cat("8) Oneway ANOVA of medians (med1way()) - Non-significant differences between the median of samples. p-value:",pvals3,"\n")
						  if (pvals <= alpha) {
							cat("\tWarning! The Kruskal-Wallis test and anova on medians give contradictory results.\n")
						  }
						}
					  }
					}
				  } else {
					#################
					#	var.equal=T ==> trimm
					#################
					check_variance_equal <-  TRUE
					pvals3 <- t1way(x~g)$p.value
					if (is.na(pvals3)) {
					  if (verbose==TRUE) {cat("8) Oneway ANOVA on trimmed means (t1way()) - Failed, return NA. The Kruskal-Wallis test should be used for interpretation.\n")}
					} else {
					  if (pvals3 <= alpha) {
						if (verbose==TRUE) {cat("8) Oneway ANOVA on trimmed means (t1way()) - Significant differences between the trimmed samples. p-value:",pvals3,"\n")
						  if (pvals > alpha) {
							cat("\tWarning! The Kruskal-Wallis test and anova on trimmed means give contradictory results.\n")
						  }
						}
					  } else if (pvals3 > alpha) {
						if (verbose==TRUE) {cat("8) One-way ANOVA on trimmed means (t1way()) - Non-significant differences between the trimmed samples. p-value:",pvals3,"\n")
						  if (pvals <= alpha) {
							cat("\tWarning! The Kruskal-Wallis test and anova on trimmed means give contradictory results.\n")
						  }
						}
					  }
					}
				  }
				}
			
			}
			
		}
	  } else {
		################################################################
		#
		#
		#		NORMAL
		#
		#
		################################################################
		check_normality <- TRUE
		###################################################
		#			NORMAL
		###################################################
		if (verbose==TRUE) {cat(msg("1) Control of normality - Shapiro-Wilk test (<=100), Jarque-Bera (<=1000) or nothing (>1000).\n\tAnalyse of values by sample (shapiro.test() & jb.norm.test()) - \n\tThe samples follow the normal law. min(p-value):","Contrôle de la normalité - Test de Shapiro-Wilk (<=100), Jarque-Bera (<=1000) ou aucun test (>1000).\n\tAnalyse des valeurs par échantillon (shapiro.test() & jb.norm.test()) - \n\tLes échantillons suivent la loi normale. min(p-value) :"),min(pvals),msg("with Sidak correction of alpha to ","avec correction de Sidak conduisant à un alpha de "),pval,"\n")}
		if (length(unique(g))==2) { # 2 categories
		  check_number <- 2
		  if (code==TRUE){cat("length(unique(g)) #2)\n")}
		  if (verbose==TRUE) {cat("2) Two categories.\n")}
		  formula <- formula(x~g)
		  pvals <- var.test(formula)$p.value
		  if (code==TRUE){cat("var.test(x~g) #3)\n")}
		  if (pvals>alpha) {
			###################################################
			#			NORMAL		2 categories	homogene variance
			###################################################
			check_variance_equal <-  TRUE
			if (verbose==TRUE) {cat(msg("3) Fisher-Snedecor test (var.test()) - Identical sample variances. p-value:","3) Test de Fisher-Snedecor (var.test()) - Variances des échantillons identiques. p-value :"),pvals,"\n")}
			pvals <- t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=TRUE)$p.value
			if (verbose==TRUE) {
				if (pvals <= alpha) {
				  ##################################
				  #        NORMAL, Student significant (var.equal=T)
				  ##################################
				  cat(msg("4) Student test (t.test()) - Significant differences between samples. p-value:","4) Test de Student (t.test()) - Différences significatives entre les échantillons. p-value :"),pvals,"\n")
				} else {
				  ##################################
				  #        NORMAL, Student unsignificant (var.equal=T)
				  ##################################
				  cat("4) Student test (t.test()) - Non-significant differences between samples. p-value:",pvals,"\n")
				}					
			}
		  } else {
			###################################################
			#			NORMAL		2 categories	non-homogene variance
			###################################################
			check_variance_equal <-  FALSE
			if (verbose==TRUE) {cat("3) Fisher-Snedecor test (var.test()) - Non-identical sample variances. p-value:",pvals,"\n")}
			pvals <- t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],,var.equal=FALSE)$p.value
			if (code==TRUE){cat("t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=TRUE) #4)\n")}
			if (verbose==TRUE) {
				if (pvals <= alpha) {
				  ##################################
				  #        NORMAL, Student significant (var.equal=F)
				  ##################################
				  cat("4) Student test (t.test()) - Significant differences between samples. p-value:",pvals,"\n")
				  
				} else {  
				  ##################################
				  #        NORMAL, Student unsignificant (var.equal=F)
				  ##################################
				   cat("4) Student test (t.test()) - Non-significant differences between samples. p-value:",pvals,"\n")
				}
			}

		  }
		} else { 													# > 2 categories
		  check_number <- 3
		  ###################################################
		  #			NORMAL		>2 categories
		  ###################################################
		  if (code==TRUE){cat("length(unique(g))#2)\n")}
		  if (verbose==TRUE) {cat("2) More than two categories.\n")}
		  pvals <- bartlett.test(x,g)$p.value
		  if (code==TRUE){cat("bartlett.test(x,g) #3)\n")}
		  if (pvals > alpha) {											# Identical variances
			  ##################################
			  #        NORMAL, >2 categories var.equal=T => AOV
			  ##################################
			check_variance_equal <-  TRUE  
			if (verbose==TRUE) {cat("3) Bartlett test (bartlett.test()) - Identical sample variances. p-value:",pvals,"\n")}
			formula <- formula(x~g)
			mya <- suppressWarnings(aov(data.frame(x,g), formula=formula))
			if (code==TRUE){cat("mya <- aov(data.frame(x,g), formula=x~g) #4)\n")}
			pvals <- summary(mya)[[1]][["Pr(>F)"]][1]
			if (verbose==TRUE) {
				if (pvals<=alpha) {										# Significant AOV
				  cat("4) One-way analysis of variance (aov()) - Significant differences between samples. p-value:",pvals,"\n")
				} else {											#	 Non-significant AOV
				  cat("4) One-way analysis of variance (aov()) - Non-significant differences between samples. p-value:",pvals,"\n")
				}
			}
		  } else {												# Non-identical variances
			  ##################################
			  #        NORMAL, >2 categories var.equal=F => FANOVA.HETERO
			  ##################################
			check_variance_equal <-  FALSE  
			if (verbose==TRUE) {cat("3) Bartlett test (bartlett.test()) - Non-identical sample variances. p-value:",pvals,"\n")}
			pvals <- oneway.test(x~g,var.equal=FALSE)$p.value
			if (code==TRUE){cat("oneway.test(x~g,var.equal=FALSE) #4)\n")}
			myf <- try(fanova.hetero(data.frame(x,g = as.factor(g)),x~g),silent=silent)
			if (is(myf)=="try-error") {
			  #if (verbose==TRUE) {cat("Error on fanova.hetero()\n")}
			  pvals2 <- alpha
			} else {pvals2 <- myf$ans[4]}
			if (verbose==TRUE) {
				if (pvals<=alpha) {
					cat("4) Welch’s heteroscedastic F test (oneway.test(var.equal=FALSE)) Significant differences between samples p-value:",pvals,"\n")
					if (pvals2 > alpha) {
						if (verbose==TRUE) {cat("Warning! fanova.hetero() does not give the same result as oneway.test. p-value:",pvals2,"\n")}
					}
				} else {
					cat("4) Welch’s heteroscedastic F test (oneway.test(var.equal=FALSE)) Non-significant differences between samples. p-value:",pvals,"\n")
					if (pvals2 <= alpha) {
						cat("Warning! fanova.hetero() does not give the same result as oneway.test. p-value:",pvals,"\n")
					}
				}
			}  
			  
		
		  }
		}
	  }
		#################
		# post-hoc and bootstrap
		#################
		#print("norm") ; print(check_normality)
		#print("var") ; print(check_variance_equal)
		if (debug==TRUE) {cat(msg("","Tests posts-hocs.\n"))}
		if (return==TRUE) {
			synth <- posthoc(x,g,alpha=alpha,normal=check_normality,var.equal=check_variance_equal,
			control=control, code=code,verbose=verbose, paired=paired)
			return(synth)
		} else {return(pvals)}
	}
