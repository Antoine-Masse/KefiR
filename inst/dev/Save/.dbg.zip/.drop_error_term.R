.drop_error_term <- function(form) {
  f <- deparse(form)
  f <- gsub("\\s*\\+\\s*Error\\s*\\([^)]*\\)", "", f)
  stats::as.formula(f)
}