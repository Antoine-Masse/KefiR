#' Réaliser différents tests post-hoc en fonction du contexte statistique
#'
#' Cette fonction \code{posthoc} réalise un ensemble de tests post-hoc
#' (tests de Student, Wilcoxon, SNK, Dunn, etc.) en fonction :
#' \itemize{
#'   \item du nombre de groupes à comparer (\code{number}) ;
#'   \item de la normalité présumée des données (\code{normal}) ;
#'   \item de l'égalité présumée des variances (\code{var.equal}) ;
#'   \item du caractère apparié (\code{paired}) ;
#'   \item de la présence éventuelle d'un groupe de contrôle (\code{control}).
#' }
#'
#' Lorsque plusieurs groupes sont comparés, la fonction applique les procédures
#' post-hoc adaptées (par exemple, \code{\link[agricolae]{SNK.test}} pour SNK,
#' \code{\link[FSA]{dunnTest}} pour Dunn, \code{\link[DescTools]{DunnettTest}} pour Dunnett, etc.).
#' En cas d'options supplémentaires (\code{boot}, \code{conf}, \code{iter}),
#' la fonction peut également réaliser des tests bootstrap via \code{boots()}
#' et des analyses de paires via \code{pairwise()} (fonctionnalités internes
#' ou fournies par des paquets tiers).
#'
#' @param x Numérique. Le vecteur de données à analyser.
#' @param g Facteur ou vecteur catégoriel. Indique à quel groupe chaque valeur de \code{x} est associée.
#' @param alpha Numérique. Seuil de signification (\emph{p-value}) pour tous les tests (par défaut \code{0.05}).
#' @param normal Logique. \code{TRUE} si les données sont supposées normales, \code{FALSE} sinon.
#' @param number Entier. Nombre de groupes (défaut : \code{length(unique(g))}).
#' @param var.equal Logique. \code{TRUE} si la variance est supposée homogène, \code{FALSE} sinon.
#' @param control Chaîne de caractères ou vecteur. Nom(s) du(des) groupe(s) utilisé(s) comme contrôle(s).
#'   Si un contrôle est spécifié, la fonction réalise également un test de Dunnett (\code{\link[DescTools]{DunnettTest}}).
#' @param verbose Logique. \code{TRUE} pour afficher des messages de suivi, \code{FALSE} sinon.
#' @param code Logique. \code{TRUE} pour afficher des exemples de codes R équivalents, \code{FALSE} sinon.
#' @param paired Logique. \code{TRUE} pour des données appariées, \code{FALSE} sinon.
#'   Certains tests (p. ex. Wilcoxon ou \code{t.test}) tiennent alors compte de cette information.
#'
#' @details
#' \enumerate{
#'   \item \strong{Deux groupes seulement} (\code{number = 2}):
#'   \itemize{
#'     \item Si \code{normal = TRUE}, on applique un \code{t.test} (avec ou sans variances égales selon \code{var.equal}).
#'     \item Si \code{normal = FALSE}, on applique un \code{wilcox.test}.
#'   }
#'   \item \strong{Plus de deux groupes} (\code{number > 2}):
#'   \itemize{
#'     \item Si \code{normal = TRUE} et \code{var.equal = TRUE}, on utilise le test de Newman-Keuls (\code{SNK.test})
#'       via \pkg{agricolae} et un \code{pairwise.t.test} (pool.sd = TRUE).
#'     \item Si \code{normal = TRUE} et \code{var.equal = FALSE}, on utilise \code{pairwise.t.test} (pool.sd = FALSE).
#'     \item Si \code{normal = FALSE}, on opte pour des tests non paramétriques
#'       (par ex. \code{dunnTest} via \pkg{FSA}, \code{wilcox.test} pairwise, etc.).
#'   }
#' }
#'
#' Dans tous les cas, si un contrôle est spécifié (\code{control}), la fonction
#' effectue également un test de Dunnett (\code{\link[DescTools]{DunnettTest}})
#' afin de comparer ce contrôle à chacun des autres groupes.
#'
#' Par ailleurs, si l'option \code{boot = TRUE} (utilisée en interne ou issue d'un
#' paramétrage externe), la fonction exécute des comparaisons par bootstrap via
#' \code{boots()}, et peut ainsi vérifier la robustesse des tests classiques
#' (en affichant des warnings si le bootstrap détecte des incohérences).
#'
#' @return
#' \code{posthoc} renvoie une liste (nommée \code{synth}) contenant généralement :
#' \itemize{
#'   \item \code{groups} : un data.frame indiquant la catégorisation de chaque groupe
#'     selon la comparaison (lettres pour les groupes équivalents, etc.) ;
#'   \item \code{p.value} : la ou les p-values associées aux tests effectués ;
#'   \item \code{bootstrap} : (optionnel) les résultats des comparaisons par bootstrap,
#'     si \code{boot = TRUE}.
#' }
#' Des éléments supplémentaires peuvent être ajoutés selon le test post-hoc réalisé
#' (p. ex. \code{Dunnett}, \code{SNK}, \code{Wilcoxon_holm}, etc.).
#'
#' @importFrom DescTools DunnettTest
#' @importFrom agricolae SNK.test
#' @importFrom FSA dunnTest
#' @importFrom WRS2 lincon
#' @importFrom stringr str_split_fixed
#' @importFrom rstatix games_howell_test
#' @importFrom PMCMRplus dunnettT3Test
#'
#' @seealso
#' \itemize{
#'   \item \code{\link{t.test}}, \code{\link{wilcox.test}} pour les tests de base,
#'   \item \code{\link[agricolae]{SNK.test}} pour le test de Newman-Keuls,
#'   \item \code{\link[FSA]{dunnTest}} pour le test de Dunn,
#'   \item \code{\link[DescTools]{DunnettTest}} pour le test de Dunnett,
#'   \item \code{\link[WRS2]{lincon}} pour les méthodes robustes (linéaires),
#'   \item \code{boots()}, \code{pairwise()} (fonctions internes ou d'autres paquets)
#'     pour la gestion du bootstrap et des comparaisons multiples.
#' }
#'
#' @examples
#' \dontrun{
#' # Exemple minimal (2 groupes, données normales, variances égales)
#' x <- rnorm(30)
#' g <- factor(rep(c("GroupeA","GroupeB"), each = 15))
#' res <- posthoc(x, g, alpha = 0.05, normal = TRUE, var.equal = TRUE)
#' print(res)
#'
#' # Exemple avec plus de 2 groupes et données non normales
#' set.seed(123)
#' x2 <- runif(40)
#' g2 <- factor(rep(c("G1","G2","G3","G4"), each = 10))
#' res2 <- posthoc(x2, g2, alpha = 0.01, normal = FALSE, var.equal = FALSE)
#' print(res2)
#' }
#'
#' @export


# Mettre à jour code



.posthoc <- function(
    x, g,
    alpha = 0.05,
    normal = TRUE,
    number = NULL,            # <-- au lieu de length(unique(g))
    var.equal = FALSE,
    control = NULL,
    verbose = TRUE, debug = FALSE, code = FALSE,
    paired = FALSE, boot = TRUE, iter = 1/alpha*10, conf = 0.95, k = NULL
) {

  # -- VOS COERCITIONS (gardez-les) --
  if (is.data.frame(x)) x <- x[[1]]
  if (is.matrix(x))     x <- x[, 1, drop = TRUE]
  if (is.list(x))       x <- unlist(x, use.names = FALSE)
  x <- as.vector(x)
  if (!is.numeric(x)) stop(".posthoc() attend un vecteur numérique 'x'.")

  if (is.data.frame(g)) g <- g[[1]]
  if (is.matrix(g))     g <- g[, 1, drop = TRUE]
  if (is.list(g))       g <- unlist(g, use.names = FALSE)
  g <- droplevels(factor(g))
  lev <- levels(g)
  ng  <- length(lev)

  if (is.null(number)) number <- ng

  if (length(x) != length(g)) stop("Longueurs incompatibles entre x et g.")

  if (ng < 2L || number < 2L) {
    synth <- list(
      groups = data.frame(categories = lev),
      note   = "Pas assez de catégories (number < 2) pour réaliser des post-hoc."
    )
    class(synth) <- "posthoc"
    .dbg(NULL, "Fin de posthoc() - moins de 2 groupes.", debug = debug)
    return(synth)
  }
  g1 <- lev[1L]; g2 <- lev[2L]
                   #"Comparaison post-hoc des 2 niveaux appariés par un test de Wilcoxon [wilcox.test(paired==TRUE)]",

		if (normal==TRUE) {
			.dbg(".posthoc() - Post-hoc on normal data.",
				".posthoc() - Post-hoc sur données normales.",debug=debug)
			if (number==2) {
			  if (var.equal == TRUE) {
			    ########################
			    #  STUDENT (var.equal = TRUE)
			    ########################
			    if (code == TRUE) {
			      cat("# Test de Student\n",
			          "t.test(x[g==g1], x[g==g2], var.equal = TRUE, paired = ", paired, ")\n", sep = "")
			    }
			    pvals <- t.test(x[g == g1], x[g == g2], var.equal = TRUE, paired = paired)$p.value
			    control_chr <- if (is.null(control)) NULL else as.character(control)[1]
			    ind_control  <- if (is.null(control_chr)) integer(0L) else match(control_chr, lev)
			    if (isTRUE(paired)) {
			      # --- CAS APPARIÉ : PAS de bootstrap "indice moyenne"
			      k <- .vbse(
			        "Post-hoc comparison of the two paired levels using a paired Student’s t-test [t.test(paired = TRUE)].",
			        "Comparaison post-hoc des 2 niveaux appariés par un test de Student [t.test(paired == TRUE)].",
			        verbose = verbose, k = k, cpt = "on"
			      )
			      # Résultat (significatif / non significatif)
			      if (pvals <= alpha) {
			        k <- .vbse(
			          paste0("Significant difference between the paired levels (p = ", .format_pval(pvals), ")."),
			          paste0("Différence significative entre les niveaux appariés (p = ", .format_pval(pvals), ")."),
			          verbose = verbose, k = k, cpt = "off"
			        )
			      } else {
			        k <- .vbse(
			          paste0("No significant difference between the paired levels (p = ", .format_pval(pvals), ")."),
			          paste0("Aucune différence significative entre les niveaux appariés (p = ", .format_pval(pvals), ")."),
			          verbose = verbose, k = k, cpt = "off"
			        )
			      }



			      synth <- list()
			      if (length(ind_control) != 1L) {
			        # Sans témoin : lettres a/b selon la significativité
			        synth$groups <- data.frame(
			          categories = lev,
			          Student_Holm = if (pvals <= alpha) c("a","b") else c("a","a")
			        )
			      } else {
			        # Avec témoin : étoiles sur la catégorie non témoin
			        stars <- c("","")
			        stars[-ind_control] <- ifelse(pvals <= 0.001, "***",
			                                      ifelse(pvals <= 0.01,  "**",
			                                             ifelse(pvals <= 0.05,   "*", "")))
			        synth$groups <- data.frame(
			          categories  = lev,
			          Student_Holm = stars
			        )
			      }
			      synth$p.value <- pvals

			      # On peut garder le bootstrap "robustesse du Student" (optionnel) :
			      if (isTRUE(boot)) {
			        synth$bootstrap <- .boots(
			          x, g,
			          ctrl = (length(ind_control) == 1L),
			          type = "mean",        # <-- pas un “indice de moyenne” séparé ; c’est la même API interne
			          var.equal = TRUE,
			          conf = conf, iter = iter, alpha = alpha,
			          paired = TRUE, control = control
			        )
			        colnames(synth$bootstrap$groups)[2] <- "Student_bootstrapped"
			      }

			    } else {
  					  k <- .vbse("a) Posthoc - Analysis of mean differences by bootstrap [pairwise.boot() from {KefiR}].",
					           "a) Posthoc - Analyse des différences de moyennes par bootstrap [pairwise.boot() de {KefiR}]",
							verbose=verbose, k=k, cpt="off")
					    synth2 <- pairwise(x,g,type="boot",alpha=alpha,control=control,boot=FALSE,
							          boot_type="mean",conf=conf,iter=iter,debug=debug)

    					if (length(ind_control)!=1) {
    					    ########################
    					    #	Pas de control
    					    ########################
    						# b) Student
    						k <- .vbse("b) Posthoc - Student test [t.test()].",
    							"b) Posthoc - Test de Student [t.test()]",
    								verbose=verbose, k=k, cpt="off")
    					    synth <- list()
    					    if (pvals <= alpha) {
    							synth$groups <- data.frame(categories=lev,Student=c("a","b"))
    					    } else {
    							synth$groups <- data.frame(categories=lev,Student=c("a","a"))
    					    }
    						synth$p.value <- pvals
    						# Plus bootstrap intégré
    						#if (boot==TRUE) {
    						#	synth$bootstrap <- .boots(x,g,ctrl=FALSE,
    						#							 type="mean",var.equal=TRUE,conf=conf,iter=iter,alpha=alpha, paired=paired)
    						#	colnames(synth$bootstrap$groups)[2] <- "Student_bootstrapped"
    						#}
    						#if ((boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
    						#	k <- .vbse("Warning! Bootstrap detects weaknesses in the significance of the results.",
    						#	  "Attention ! Le bootstrap détecte des faiblesses dans la signification des résultats.",
    						#	  verbose = verbose, k = k, cpt = "off")
    						#}
    					} else {
    						#######################
    						#	control
    						########################
    						# a) Bootstrap sur l'indice moyen
    				#		k <- .vbse("a) Posthoc - Analysis of mean differences by bootstrap [pairwise.boot() from {KefiR}].",
    					#		"a) Posthoc - Analyse des différences de moyennes par bootstrap [pairwise.boot() de {KefiR}]",
    					#			verbose=verbose, k=k, cpt="off")
    					#	synth2 <- pairwise(x,g,type="boot",alpha=alpha,control=control,boot=FALSE,
    					#			boot_type="mean",conf=conf,iter=iter,debug=debug)
    						.dbg(".posthoc() - Student with control.",".posthoc() - Student avec présence d'un Témoin.",debug=debug)
    					  k <- .vbse("b) Posthoc - Student test [t.test()] with control.",
    					             "b) Posthoc - Test de Student [t.test()] avec témoin.",
    					             verbose=verbose, k=k, cpt="off")
    						synth <- list()
    						starss <- c("","")
    						starss[-ind_control] <- ifelse(pvals <=0.001,"***",ifelse(pvals <=0.01,"**",ifelse(pvals <=0.05,"*","")))
    						synth$groups <- data.frame(categories=lev,Student=starss)
    						synth$p.value <- pvals
    					}
					# Bootstrap sur le test de Student
					if (boot==TRUE) {
						synth$bootstrap <- .boots(x,g,ctrl=(length(ind_control)==1),type="mean",var.equal=TRUE,
							conf=conf,iter=iter,
							alpha=alpha, paired=paired, control=control)
						colnames(synth$bootstrap$groups)[2] <- "Student_bootstrapped"
					}
					if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
						ang <- paste0("Warning! Bootstrap detects weaknesses in the significance of the results.")
						fr <- paste0("Attention ! Le bootstrap détecte des faiblesses dans la signification des résultats.")
						k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
					}
					# Ajout du bootstrap sur la moyenne
					match(synth$groups[,1],synth2$groups[,1]) -> ind_temp
					synth$groups <- data.frame("categories"=synth$groups[,1],"Bootstrap_Mean"=synth2$groups[ind_temp,2],"Student_Holm"=synth$groups[,2])
				  ########################
				  #	STUDENT var.equal=FALSE
				  ########################
			    }
				} else if (var.equal==FALSE)  {
					if (code==TRUE){cat("# Test de Student\nt.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=FALSE, paired=",paired,")\n")}
					pvals <- t.test(x[g==g1],x[g==g2],var.equal=FALSE, paired=paired)$p.value
					control_chr <- if (is.null(control)) NULL else as.character(control)[1]
					ind_control <- if (is.null(control_chr)) integer(0L) else match(control_chr, lev)
					# a) Bootstrap sur l'indice moyen
					k <- .vbse("a) Posthoc - Analysis of mean differences by bootstrap [pairwise.boot(mu='mean') from {KefiR}].",
						        "a) Posthoc - Analyse des différences de moyennes par bootstrap [pairwise.boot(mu='mean') de {KefiR}]",
							verbose=verbose, k=k, cpt="off")
					synth2 <- pairwise(x,g,type="boot",alpha=alpha,control=control,boot=FALSE,
							boot_type="mean",conf=conf,iter=iter,debug=debug) # ctrl=(length(ind_control)==1)
					if (length(ind_control)!=1) {
					    ########################
					    #	Pas de control
					    ########################
						# b) Student
						k <- .vbse("b) Posthoc - Student test [t.test(var.equal=FALSE)].",
							"b) Posthoc - Test de Student à variances inégales [t.test(var.equal=FALSE)]",
								verbose=verbose, k=k, cpt="off")
					    synth <- list()
					    if (pvals <= alpha) {
							synth$groups <- data.frame(categories=lev,Student=c("a","b"))
					    } else {
							synth$groups <- data.frame(categories=lev,Student=c("a","a"))
						}
					    synth$p.value <- pvals
					    if (boot==TRUE) {
							synth$bootstrap <- .boots(x,g,ctrl=FALSE,
													 type="mean",var.equal=FALSE,conf=conf,iter=iter,alpha=alpha,
													 paired=paired, control=control)
							colnames(synth$bootstrap$groups)[2] <- "Student_bootstrapped"
					    }
						if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
							ang <- paste0("Warning! Bootstrap detects weaknesses in the significance of the results.")
							fr <- paste0("Attention ! Le bootstrap détecte des faiblesses dans la signification des résultats.")
							k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
						}
						# Ajout du bootstrap sur la moyenne
						match(synth$groups[,1],synth2$groups[,1]) -> ind_temp
						synth$groups <- data.frame("categories"=synth$groups[,1],"Bootstrap_Mean"=synth2$groups[ind_temp,2],"Student_Holm"=synth$groups[,2])
					} else {
					  ########################
					  #	control
					  ########################
					  k <- .vbse("b) Posthoc - Student test [t.test(var.equal=FALSE)] with control.",
					             "b) Posthoc - Test de Student à variances inégales [t.test(var.equal=FALSE)] avec témoin.",
					             verbose=verbose, k=k, cpt="off")
					  synth <- list()
					  starss <- c("","")
					  starss[-ind_control] <- ifelse(pvals <=0.001,"***",ifelse(pvals <=0.01,"**",ifelse(pvals <=0.05,"*","")))
					  synth$groups <- data.frame(categories=lev,Student=starss)
					  synth$p.value <- pvals
					  match(synth$groups[,1],synth2$groups[,1]) -> ind_temp
					  synth$groups <- data.frame("categories"=synth$groups[,1],"Bootstrap_Mean"=synth2$groups[ind_temp,2],"Student_Holm"=synth$groups[,2])
					  if (boot==TRUE) {
						synth$bootstrap <- .boots(x,g,ctrl=TRUE,
												 type="mean",var.equal=FALSE,conf=conf,iter=iter,alpha=alpha,
												 paired=paired, control=control)
						colnames(synth$bootstrap$groups)[2] <- "Student_bootstrapped"
					  }
					  if ((verbose==TRUE) & (boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
						ang <- paste0("Warning! Bootstrap detects weaknesses in the significance of the results.")
						fr <- paste0("Attention ! Le bootstrap détecte des faiblesses dans la signification des résultats.")
						k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
					  }
					}

				}
			} else if (number > 2) {
				.dbg(NULL,".posthoc() - '>2 catégories'.",debug=debug)
				if (paired) {
					k <- .vbse("Posthoc - Post-hoc tests on paired normal groups.",
						"Posthoc - Tests post-hoc sur groupes normaux appariés.",
							verbose=verbose, k=k)
				} else {
					k <- .vbse("Posthoc - Post-hoc tests on normal groups.",
						"Posthoc - Tests post-hoc sur groupes normaux.",
							verbose=verbose, k=k)
				}
				################
				# a) Bootstrap sur l'indice moyen
				k <- .vbse("a) Posthoc - Analysis of mean differences by bootstrap [pairwise.boot() from {KefiR}].",
					"a) Posthoc - Analyse des différences de moyennes par bootstrap [pairwise.boot() de {KefiR}].",
						verbose=verbose, k=k, cpt="off")
				synth2 <- pairwise(x,g,type="boot",alpha=alpha,control=control,boot=FALSE,
						boot_type="mean",conf=conf,iter=iter,debug=debug)

				################
				# b) Réaliser un test de Student en pairwise en tenant compte du sd.pool.
				if (paired==TRUE) {
					if (code==TRUE){message("# Tests t appariés\nresult <- pairwise.t.test(x,g,paired=TRUE)\n# Identification des groupes\nlibrary(KefiR)\ncatego(result)\n")}
					k <- .vbse("b) Posthoc - Student test [pairwise.t.test(paired=TRUE)].",
							"b) Posthoc - Test de Student [pairwise.t.test(paired=TRUE)].",
							verbose=verbose, k=k,cpt="off")
					synth <- pairwise(x,g,type="mean",pool.sd=FALSE,alpha=alpha,control=control,boot=boot,
						conf=conf,iter=iter,paired=paired)
				} else if (paired==FALSE) {
					if (var.equal==FALSE) {
						if (code==TRUE){message("# Tests t appariés\nresult <- pairwise.t.test(x,g,pool.sd=FALSE)\n# Identification des groupes\nlibrary(KefiR)\ncatego(result)\n")}
						k <- .vbse("b) Posthoc - Student test [pairwise.t.test(pool.sd=FALSE)].",
								"b) Posthoc - Test de Student [pairwise.t.test(pool.sd=FALSE)].",
								verbose=verbose, k=k,cpt="off")
						synth <- pairwise(x,g,type="mean",pool.sd=FALSE,alpha=alpha,control=control,boot=boot,
						conf=conf,iter=iter,paired=paired)
					} else if (var.equal==TRUE) {
						if (code==TRUE){message("# Tests t appariés\nresult <- pairwise.t.test(x,g,pool.sd=TRUE)\n# Identification des groupes\nlibrary(KefiR)\ncatego(result)\n")}
						ang <- paste0("b) Posthoc - Student test [pairwise.t.test(pool.sd=TRUE)].")
						fr <- paste0("b) Posthoc - Test de Student [pairwise.t.test(pool.sd=TRUE)].")
						k <- .vbse(ang, fr, verbose = verbose, k = k, cpt="off")
						synth <- pairwise(x,g,type="mean",pool.sd=TRUE,alpha=alpha,control=control,boot=boot,
						conf=conf,iter=iter,paired=paired)

					}
				}
				colnames(synth$groups)[2] <- "Student_Holm"
				# Agglomérat du bootstrap median bootstrap sur colonne 2, ...
				match(synth$groups[,1],synth2$groups[,1]) -> ind_temp
				synth$groups <- data.frame("categories"=synth$groups[,1],"Bootstrap_Mean"=synth2$groups[ind_temp,2],"Student_Holm"=synth$groups[,2])
				# Plus bootstrap intégré
				if (boot==TRUE) {
					if (any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
						k <- .vbse("\tWarning! Bootstrap detects weaknesses in the significance of the results.",
								"\tAttention ! Le bootstrap détecte des faiblesses dans la signification des résultats.",
								verbose=verbose, k=k, cpt="off")
					}
					colnames(synth$bootstrap$groups)[2] <- "Student_Holm_bootstrapped"
				}
				if ((var.equal==TRUE & length(control)==0 & paired==FALSE)) {
					################
					# c) Test de Scheffé
					if (code==TRUE){message("# ANOVA à 1 facteur\nmya <- aov(x~g, data=data)\n\n#package nécessaire aux tests post-hocs\nlibrary(agricolae)\n\n#Test de Scheffé\nscheffe.test(mya,'g',alpha=",alpha,")")}
					k <- .vbse("c) Posthoc - Conservative Scheffé test [scheffe.test() of {agricolae}].",
								"c) Posthoc - Test conservateur de Scheffé [scheffe.test() of {agricolae}].",
								verbose=verbose, k=k, cpt="off")
					formula <- formula(x~g)
					data.frame(x,g)->data ; data$g <- factor(data$g)
					#data <- subset(data, g %in% unique(data$g))
					mya <- suppressWarnings(aov(formula=formula,data=data))
					myscheffe <- scheffe.test(mya,"g",alpha=alpha)
					match(synth$groups[,1],rownames(myscheffe$groups)) -> ind_temp
					synth$groups <- data.frame(synth$groups , "Scheffe"=myscheffe$groups$groups[ind_temp])
					# Détection de différence entre 2 tests post-hocs, non fait sur scheffé.
					#cat1 <- unique(unlist(strsplit(synth$groups$groups,"")))
					#cat2 <- unique(unlist(strsplit(myscheffe$groups$groups,"")))
					#rownames(synth$groups) <- rep(c(),nrow(synth$groups))
					#which(unique(g)==control)-> ind_control

					################
					# d) Test de Tukey
					if (code==TRUE){message("#Test de Tukey\nHSD.test(mya,'g',alpha=",alpha,")")}
					k <- .vbse("d) Posthoc - Conservative Tukey test [HSD.test() of {agricolae}].",
								"d) Posthoc - Test conservateur de Tukey [HSD.test() of {agricolae}].",
								verbose=verbose, k=k, cpt="off")
					#formula <- formula(x~g)
					#mya <- suppressWarnings(aov(data.frame(x,g), formula=formula))
					mytukey <- HSD.test(mya,"g",alpha=alpha)
					match(synth$groups[,1],rownames(mytukey$groups)) -> ind_temp
					synth$groups <- data.frame(synth$groups , "Tukey"=mytukey$groups$groups[ind_temp])
					################
					# e) Test de Newman-Keuls
					if (code==TRUE){message("#Test de Newman-Keuls\nSNK.test(mya,'g',alpha=",alpha,")")}
					k <- .vbse("e) Posthoc - Powerful Newman-Keuls test [SNK.test() of {agricolae}].",
								"e) Posthoc - Test puissant de Newman-Keuls [SNK.test() of {agricolae}].",
								verbose=verbose, k=k, cpt="off")
					mynk <- SNK.test(mya,"g",alpha=alpha)
					match(synth$groups[,1],rownames(mynk$groups)) -> ind_temp
					synth$groups <- data.frame(synth$groups , "SNK"=mynk$groups$groups[ind_temp])
					cat1 <- unique(unlist(strsplit(synth$groups[,3],"")))
					cat2 <- unique(unlist(strsplit(mynk$groups$groups,"")))
					rownames(synth$groups) <- rep(c(),nrow(synth$groups))
					control_chr <- if (is.null(control)) NULL else as.character(control)[1]
					ind_control <- if (is.null(control_chr)) integer(0L) else match(control_chr, lev)
					if ((length(cat1)!=length(cat2)) & (length(ind_control)!=1)) {
						k <- .vbse("Warning! pairwise.t.test() and SNK.test() don't return the same number of groups.",
							"Attention ! pairwise.t.test() et SNK.test() ne renvoient pas le même nombre de groupes.",k=k, cpt="off")
					}
					################
					# f) Test de Waller-Duncan
          mywd <- tryCatch(waller.test(mya, "g"), error = function(e) NULL)
          if (!is.null(mywd)) {
            if (code==TRUE){message("#Test de Waller-Duncan\nwaller.test(mya,'g')\n")}
            k <- .vbse("f) Posthoc - Powerful Waller-Duncan test [waller.test() of {agricolae}].",
                       "f) Posthoc - Test puissant de Waller-Duncan [waller.test() of {agricolae}].",
                       verbose=verbose, k=k, cpt="off")
					  match(synth$groups[,1],rownames(mywd$groups)) -> ind_temp
					  synth$groups <- data.frame(synth$groups , "Waller-Duncan"=mywd$groups$groups[ind_temp])
          }
				} else if ((var.equal==TRUE)& (length(control)>0)&(paired==FALSE)) {
					if (code==TRUE){message("# Test de Dunnett car présence de Témoin\nlibrary(DescTools)\nDunnettTest(x,g,control='",control,"')\n")}
					k <- .vbse("c) Posthoc - See also post-hoc Dunnett test for the control [DunnettTest() from {DescTools}].",
								"c) Posthoc - Voir aussi le test post-hoc de Dunnett pour le contrôle [DunnettTest() de {DescTools}].",
								verbose=verbose, k=k, cpt="off")
					p_value_to_symbol <- function(p_value) {
					  if (p_value < 0.001) {
						return("***")
					  } else if (p_value < 0.01) {
						return("**")
					  } else if (p_value < 0.05) {
						return("*")
					  } else {
						return("")
					  }
					}
					dunnett_results<- DunnettTest(x,g, control = control)
					dunnett_results$Significance <- sapply(dunnett_results[[1]][,4], p_value_to_symbol)
					decoupage <-str_split_fixed(names(dunnett_results$Significance), "-",2)
					if (length(unique(decoupage[,2]))==1) {
					  categories <- c(decoupage[,1],unique(decoupage[,2]))
					  lettre <- c(dunnett_results$Significance,"")
					} else {
					  .exit("Le traitement de la sortie DunnettTest() renvoie une erreur. SVP, lancez m.test() avec l'argument debug==TRUE et envoyez le bilan à antoine.masse@u-bordeaux.fr.",
							verbose=verbose, return =return)
					}
					lettre <- lettre[match(synth$groups$categories, categories)]
					synth$groups <- cbind(synth$groups,"Dunnett"=lettre)
					rownames(synth$groups) <- NULL
					#categories <- categories[match(synth$groups$categories, categories)]
				} else if ((var.equal==FALSE)&(paired==FALSE)) {
					################
					# c) Test de Games-Howell
					if (code==TRUE){message("#Test de Games-Howell\nlibrary(rstatix)\ngames_howell_test(x~g, data=data)\n")}
					k <- .vbse("c) Posthoc - Games-Howell test on normally distributed data with non-homogeneous variances [games_howell_test() of {rstatix}].",
								"c) Posthoc - Test de Games-Howell sur donnnées normales à variance non-homogènes [games_howell_test() of {rstatix}].",
								verbose=verbose, k=k, cpt="off")
					#Test de Games-Howell : {rstatix} - games_howell_test(A~G, data=data)
					dt <- data.frame("x"=x,"g"=g)
					resultGH <- games_howell_test(x~g, data=dt)
					# Extraire les noms des classes uniques
					group_names <- unique(c(resultGH$group1, resultGH$group2))
					# Initialiser une matrice de NA avec les noms des groupes comme lignes et colonnes
					p_value_matrix <- matrix(NA, nrow = length(group_names), ncol = length(group_names),
											 dimnames = list(group_names, group_names))
					# Remplir la matrice avec les p-values
					for (i in seq_len(nrow(resultGH))) {
					  group1 <- resultGH$group1[i]
					  group2 <- resultGH$group2[i]
					  p_value <- resultGH$p.adj[i]
					  p_value_matrix[group1, group2] <- p_value
					  p_value_matrix[group2, group1] <- p_value  # La matrice est symétrique
					}
					p_value_matrix <- p_value_matrix[-1,  -ncol(p_value_matrix)]
					# Afficher la matrice de p-values
					a <- list()
					a$p.value <- p_value_matrix
					synthGamesHowell <- catego(a)
					lettre <- synthGamesHowell$groups[,2]
					lettre <- lettre[match(synth$groups$categories, synthGamesHowell$groups[,1])]
					synth$groups <- cbind(synth$groups,"Games-Howell"=lettre)
					rownames(synth$groups) <- NULL
					################
					# d) Test de Dunnett T3
					# Test de Dunnett T3 : {PMCMRplus} dunnettT3Test(mya)
					if (code==TRUE){message("#Test de Dunnett T3\nlibrary(PMCMRplus)\nresult <-dunnettT3Test(mya)\nKefiR\ncatego(result)\n")}
					k <- .vbse("d) Posthoc - Dunnett T3 test on normally distributed data with non-homogeneous variances [dunnettT3Test() of {PMCMRplus}].",
								"d) Posthoc - Test de Dunnett T3 sur donnnées normales à variance non-homogènes [dunnettT3Test() of {PMCMRplus}].",
								verbose=verbose, k=k, cpt="off")
					formula <- formula(x~g)
					data.frame(x,g)->data ; data$g <- factor(data$g)
					mya <- suppressWarnings(aov(formula=formula,data=data))
					DunnettT3 <- catego(dunnettT3Test(mya))
					lettre <- DunnettT3$groups[,2]
					lettre <- lettre[match(synth$groups$categories, DunnettT3$groups[,1])]
					synth$groups <- cbind(synth$groups,"Dunnett T3"=lettre)
					rownames(synth$groups) <- NULL
				}
			}
		} else if (normal==FALSE) {
			.dbg(NULL,"post-hoc sur données non normales.",debug=debug)
			##########
			# Echantillons non-normaux - WILCOXON
			##########
			if (number==2) {
				.dbg(NULL,"2 catégories.",debug=debug)
				if (code==TRUE){message("# Test de Wilcoxon-Mann-Witney\nwilcox.test(x[g==unique(g)[1]],x[g==unique(g)[2]],paired=",paired,")")}
				pvals <- suppressWarnings(wilcox.test(x[g==g1],x[g==g2],paired=paired))$p.value
				control_chr <- if (is.null(control)) NULL else as.character(control)[1]
				ind_control <- if (is.null(control_chr)) integer(0L) else match(control_chr, lev)
				##########
				# Echantillons appariés à 2 niveaux
				##########
				if (isTRUE(paired)) {
				  # --- CAS APPARIÉ : PAS de bootstrap "indice moyenne"
				  k <- .vbse(
				    "Post-hoc: paired Wilcoxon signed-rank test [wilcox.test(paired = TRUE)].",
				    "Post-hoc : test de Wilcoxon apparié [wilcox.test(paired = TRUE)].",
				    verbose = verbose, k = k, cpt = "on"
				  )
				  if (pvals <= alpha) {
				    k <- .vbse(
				      paste0("Significant difference between the paired levels (p = ", .format_pval(pvals), ")."),
				      paste0("Différence significative entre les niveaux appariés (p = ", .format_pval(pvals), ")."),
				      verbose = verbose, k = k, cpt = "off"
				    )
				  } else {
				    k <- .vbse(
				      paste0("No significant difference between the paired levels (p = ", .format_pval(pvals), ")."),
				      paste0("Aucune différence significative entre les niveaux appariés (p = ", .format_pval(pvals), ")."),
				      verbose = verbose, k = k, cpt = "off"
				    )
				  }
          # Attribution des lettres et des étoiles
				  synth <- list()
				  if (length(ind_control) != 1L) {
				    # Sans témoin : lettres a/b
				    synth$groups <- data.frame(
				      categories    = lev,
				      Wilcoxon_Holm = if (pvals <= alpha) c("a", "b") else c("a", "a")
				    )
				  } else {
				    # Avec témoin : étoiles sur la catégorie non témoin
				    stars <- c("", "")
				    stars[-ind_control] <- ifelse(pvals <= 0.001, "***",
				                                  ifelse(pvals <= 0.01,  "**",
				                                         ifelse(pvals <= 0.05,   "*", "")))
				    synth$groups <- data.frame(
				      categories    = lev,
				      Wilcoxon_Holm = stars
				    )
				  }
				  synth$p.value <- pvals

				  # (optionnel) robustesse bootstrap sur la médiane
				  if (isTRUE(boot)) {
				    synth$bootstrap <- .boots(
				      x, g,
				      ctrl = (length(ind_control) == 1L),
				      type = "median",
				      conf = conf, iter = iter, alpha = alpha,
				      paired = TRUE, control = control
				    )
				    colnames(synth$bootstrap$groups)[2] <- "Wilcoxon_bootstrapped"
				    if ((verbose == TRUE) && any(synth$bootstrap$groups[, 2] != synth$groups[, 2])) {
				      k <- .vbse(
				        "Warning! Bootstrap detects weaknesses in the significance of the results.",
				        "Attention ! Le bootstrap détecte des faiblesses dans la signification des résultats.",
				        verbose = verbose, k = k, cpt = "off"
				      )
				    }
				  }
				} else { # Si non apparié

  				# a) Bootstrap sur l'indice moyen
  				k <- .vbse("a) Posthoc - Analysis of median differences by bootstrap [pairwise.boot(mu='median') from {KefiR}].",
  					"a) Posthoc - Analyse des différences de médianes par bootstrap [pairwise.boot(mu='median') de {KefiR}]",
  						verbose=verbose, k=k, cpt="off")
  				synth2 <- pairwise(x,g,type="boot",alpha=alpha,control=control,boot=FALSE,
  						boot_type="median",conf=conf,iter=iter,debug=debug)
  				# b) Test de Wilcoxon
  				k <- .vbse("b) Post-hoc - Test de Wilcoxon-Mann-Whitney [wilcox.test()].",
  					"b) Posthoc - Test de Wilcoxon-Mann-Witney [wilcox.test()].",
  						verbose=verbose, k=k, cpt="off")
  				if (length(ind_control)!=1) {
  					##########
  					#	Pas de contrôle
  					##########
  				    synth <- list()
  				    if (pvals <= alpha) {
  				  	synth$groups <- data.frame(categories=lev,Wilcoxon=c("a","b"))
  				    } else {
  				  	synth$groups <- data.frame(categories=lev,Wilcoxon=c("a","a"))
  				    }
  				    synth$p.value <- pvals
  				} else {
  					##########
  					#	Contrôle
  					##########
  				    synth <- list()
  				    starss <- c("","")
  				    starss[-ind_control] <- ifelse(pvals <=0.001,"***",ifelse(pvals <=0.01,"**",
  																			ifelse(pvals <=0.05,"*","")))
  				    synth$groups <- data.frame(categories = lev,   Wilcoxon = starss)
  				    synth$p.value <- pvals
  				}
  				if (boot==TRUE) {
  					synth$bootstrap <- .boots(x,g,ctrl=(length(ind_control)==1),
  											 type="median",conf=conf,iter=iter,alpha=alpha,
  											paired=paired, control=control)
  					colnames(synth$bootstrap$groups)[2] <- "Wilcoxon_bootstrapped"
  				}
  				if ((boot==TRUE) & any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
  					k = .vbse("Warning! Bootstrap detects weaknesses in the significance of the results.",
  						"Attention ! Le bootstrap détecte des faiblesses dans la signification des résultats.", k=k, cpt="off")
  				}
  				# Ajout du bootstrap sur la moyenne
  				match(synth$groups[,1],synth2$groups[,1]) -> ind_temp
  				synth$groups <- data.frame("categories"=synth$groups[,1],"Bootstrap_Median"=synth2$groups[ind_temp,2],"Wilcoxon_Holm"=synth$groups[,2])

				} # Fin du paired==FALSE

				} else if (number > 2) {
				.dbg(NULL,".posthoc() - '>2 catégories'.",debug=debug)
				k <- .vbse("Posthoc - Post-hoc tests on non-normal groups.","Posthoc - Tests post-hoc sur groupes non normaux.",
						verbose=verbose, k=k)
				# Détection des outliers
				outlier <- function(z) {
					tablo_outlier <- identify_outliers(data.frame(z))
					if (nrow(tablo_outlier)>0) {
						small_outliers <-  tablo_outlier[tablo_outlier[,1]<median(z),1]
						big_outliers <-  tablo_outlier[tablo_outlier[,1]>median(z),1]
						small_outliers <- length(small_outliers)/length(z)
						big_outliers <- length(big_outliers)/length(z)
						return(max(c(small_outliers,big_outliers)))
					} else {return(0)}
				}
				# 0) Identifier les outliers
				trimmage <- max(by(x,g,outlier))
				if (trimmage>0) {
					k <- .vbse("Posthoc - Warning! Groups with extreme values:\n\t\trisk of leverage (identify_outliers() of {rstatix}).",
							"Posthoc - Attention ! Groupes avec des valeurs extrêmes :\n\t\trisque d'effet de levier (identify_outliers() de {rstatix}).",
							verbose=verbose, k=k,cpt="off")
				}
				# 0) Croisements
				croisement <- ng*(ng-1)/2
				if (croisement>28) {
					k <- .vbse(
					  paste0("Posthoc - Warning! Many cross-tests to perform.\n\t\t", ng, " categories for ", croisement, " pairwise comparisons."),
					  paste0("Posthoc - Attention ! Beaucoup de tests croisés à réaliser.\n\t\t", ng, " catégories pour ", croisement, " croisements"),
					  verbose = verbose, k = k, cpt = "off"
					)
				}
				# 0) Bootstrap sur l'indice median
				if (code==TRUE){message("#Analyse des différences de médianes par bootstrap\nlibrary(KefiR)pairwise(x,g,type='boot')")}
				k <- .vbse("Posthoc - a) Analysis of median differences using bootstrap [pairwise.boot() from {KefiR}].",
					"Posthoc - a) Analyse des différences de médianes par bootstrap [pairwise.boot() de {KefiR}].",
						verbose=verbose, k=k, cpt="off")
				synth2 <- pairwise(x,g,type="boot",alpha=alpha,control=control,boot=FALSE,
						boot_type="median",conf=conf,iter=iter,debug=debug)
				# 1) Faire un Wilcoxon (position 1) en pairwise avec Holm
				if (code==TRUE){message("# Wilcoxon par paires#pairwise.wilcox.test(x,g,p.adjust.method='BH')\n")}
				k <- .vbse("Posthoc - b) Wilcoxon-Mann-Whitney test [pairwise.wilcox.test()].","Posthoc - b) Test de Wilcoxon-Mann-Whitney [pairwise.wilcox.test()].",
						verbose=verbose, k=k,cpt="off")
				synth <- pairwise(x,g,type="median",alpha=alpha,control=control,boot=boot,conf=conf,iter=iter,paired=paired,debug=debug)
				colnames(synth$groups)[2] <- "Wilcoxon_Holm"
				# Aggloméra du bootstrap median bootstrap sur colonne 2, Wilcoxon sur colonne 3
				match(synth$groups[,1],synth2$groups[,1]) -> ind_temp
				synth$groups <- data.frame("categories"=synth$groups[,1],"Bootstrap_Median"=synth2$groups[ind_temp,2],"Wilcoxon_Holm"=synth$groups[,2])
				# Plus bootstrap intégré
				if (boot==TRUE) {
					if (any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
						k <- .vbse("\tWarning! Bootstrap detects weaknesses in the significance of the results.",
								"\tAttention ! Le bootstrap détecte des faiblesses dans la signification des résultats.",
								verbose=verbose, k=k, cpt="off")
					}
					colnames(synth$bootstrap$groups)[2] <- "Wilcoxon_Holm_bootstrapped"
				}
				if (paired==TRUE) {
					if (code==TRUE){message("# Nemenyi - post-hoc sur données appariées\nlibrary(PMCMRplus)\nfrdAllPairsNemenyiTest(x~g)\n")}
					k <- .vbse("Posthoc - c) Paired groups [frdAllPairsNemenyiTest() of {PMCMRplus}].",
								"c) Posthoc - Test post-hoc sur groupes non normaux appariés [frdAllPairsNemenyiTest() of {PMCMRplus}].",
								verbose=verbose, k=k, cpt="off")
					# Données appariées, faire un Neminye
					synth2 <- pairwise(x,g,type="neminye",alpha=alpha,control=control,boot=boot,conf=conf,iter=iter,paired=paired,debug=debug)
					match(synth$groups[,1],synth2$groups[,1]) -> ind_temp
					colnames(synth2$groups)[2] <- "Neminye"
					synth$groups <- cbind(synth$groups,"Neminye"=synth2$groups[ind_temp,2])
					if (boot==TRUE) {
						if (any(synth2$bootstrap$groups[,2]!=synth2$groups[,2])) {
							k <- .vbse("\tWarning! Bootstrap on Neminye- weaknesses.",
									"\tAttention ! Bootstrap sur Neminye - faiblesses.",
									verbose=verbose, k=k, cpt="off")
						}
						colnames(synth2$bootstrap$groups)[2] <- "Neminye_bootstrapped"
						synth$bootstrap$groups <- cbind(synth$bootstrap$groups,"Neminye_bootstrapped"=synth2$bootstrap$groups[ind_temp,2])
					}
				} else if ((trimmage > 0)&(croisement<28)) {
					# Si détection d'outliers avec rstatix::identify_outliers()
					if (code==TRUE){message("# Lincon\nlibrary(WRS2)\nlincon(x~g,tr)\n")}
					k <- .vbse(paste0("Posthoc - c) Post-hoc on trimmed data [lincon() from {WRS2}].\n\t\tLower and upper trimming level of ", round(trimmage*100, 1), "%."),
							paste0("Posthoc - c) Post-hoc sur données tronquées [lincon() de {WRS2}].\n\t\tNiveau de troncature inférieure et supérieure de ", round(trimmage*100, 1), "%."),
							verbose=verbose, k=k,cpt="off")
					# Faire un lincon() sur données trimmées
					synth2 <- pairwise(x,g,type="lincon",tr=trimmage,
						alpha=alpha,control=control,boot=boot,
						conf=conf,iter=iter,debug=debug)
					match(synth$groups[,1],synth2$groups[,1]) -> ind_temp
					colnames(synth2$groups)[2] <- "Lincon"
					synth$groups <- cbind(synth$groups,"Lincon"=synth2$groups[ind_temp,2])
					if (boot==TRUE){
						if (any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
							k <- .vbse("\tWarning! Bootstrap on Lincon - weaknesses.",
									"\tAttention ! Bootstrap sur Lincon - faiblesses.",
									verbose=verbose, k=k, cpt="off")
						}
						colnames(synth2$bootstrap$groups)[2] <- "Lincon_bootstrapped"
						synth$bootstrap$groups <- cbind(synth$bootstrap$groups,synth2$bootstrap$groups[ind_temp,2])
					}
				} else {
					# Test de Dunn avec correction de Holm
					if (code==TRUE){message("# Test de Dunn\nlibrary(FSA)\ndunnTest(x ~ g, method = 'holm')\n")}
					k <- .vbse("Posthoc - c) Dunn test [dunnTest() of {FSA}].",
								"Posthoc - c) Test de Dunn [dunnTest() de {FSA}].",
							verbose=verbose, k=k, cpt="off")
					if (trimmage > 0) {
						k <- .vbse(paste0("\tLower and upper trimming level of ", round(trimmage*100, 1), "%."),
								paste0("\tAvec troncature inférieure et supérieure de ", round(trimmage*100, 1), "%."),
							verbose=verbose, k=k, cpt="off")
						x_temp <- c() ; g_temp <- c()
						for (categor in lev) {
							x_categor <- x[g==categor]
							x_categor <- x_categor[x_categor>quantile(x_categor,p=trimmage)&x_categor<quantile(x_categor,p=(1-trimmage))]
							g_categor <- rep(categor,length(x_categor))
							x_temp <- c(x_temp,x_categor)
							g_temp <- c(g_temp,g_categor)
						}
					} else {
						x_temp <- x ; g_temp <- g
					}
					synth2 <- pairwise(x_temp,g_temp,type="dunn",alpha=alpha,control=control,boot=boot,
						conf=conf,iter=iter,debug=debug)
					match(synth$groups[,1],synth2$groups[,1]) -> ind_temp
					synth$groups <- data.frame(synth$groups,"Dunn_Holm"=synth2$groups[ind_temp,2])
					if (boot==TRUE){
						if (any(synth$bootstrap$groups[,2]!=synth$groups[,2])) {
							k <- .vbse("\tWarning! Bootstrap on Dunn - weaknesses.",
									"\tAttention ! Bootstrap sur Dunn - faiblesses.",
									verbose=TRUE, k=k, cpt="off")
						}
						synth$bootstrap$groups <- data.frame(synth$bootstrap$groups,"Dunn_Holm_bootstrapped"=synth2$bootstrap$groups[ind_temp,2])
					}
				}
			}
		}
		synth <- structure(
		  synth,
		  class = "posthoc"
		)
		.dbg(NULL,"Fin de posthoc().",debug=debug)
		return(synth)
	}
