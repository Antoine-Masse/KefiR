#' Analyse multi-facteurs pour ANOVA et ANCOVA
#'
#' Cette fonction effectue des analyses multi-facteurs pour des modèles ANOVA ou ANCOVA.
#' Elle détecte automatiquement le type de modèle (ANOVA ou ANCOVA), vérifie les assomptions de base
#' (normalité, homogénéité des variances, etc.), et effectue les ajustements nécessaires pour des analyses robustes si besoin.
#' Elle est conçue pour des analyses à deux facteurs ou plus.
#'
#' @param data Un data.frame contenant les données d'entrée.
#' @param formula Une formule spécifiant le modèle à analyser.
#' @param pair Nom d'une colonne utilisée pour l'appariement des données, si applicable.
#' @param debug Un booléen activant des messages détaillés pour le débogage.
#' @return Un modèle ajusté, une liste de résultats, ou des informations sur les tests effectués.
#'
#' @importFrom car Anova
#' @importFrom lawstat levene.test
#' @importFrom stats aov bartlett.test fligner.test
#' @importFrom lme4 lmer
#' @importFrom lmerTest lmer
#' @importFrom ez ezANOVA
#' @importFrom dae residuals.aovlist
#' @export
#'
#' @examples
#' # Exemple avec des données factices
#' data <- data.frame(
#'   y = rnorm(100),
#'   factor1 = rep(LETTERS[1:4], each = 25),
#'   factor2 = rep(c("M", "F"), times = 50)
#' )
#' formula <- y ~ factor1 * factor2
#' result <- multi_factor_analysis(data, formula, debug = TRUE)
.multi_factor_analysis <- function(x=NULL,g=NULL,formula=NULL,data=NULL,
	paired = FALSE, id = NULL,alpha = 0.05,
	k=NULL,code=FALSE,debug=FALSE,verbose=FALSE) {
	#
	#-------------------------------------
	#	Fonctions internes
	#-------------------------------------
	# Fonction pour extraire automatiquement les résidus
	get_residuals <- function(model) {
	  if (inherits(model, "aov")) {
		# Si le modèle est une aov classique
		return(residuals(model))
	  } else if (inherits(model, "aovlist")) {
		# Si le modèle est une aov avec Error()
		return(residuals(model))
	  } else {
		exit("The provided model is neither an 'aov' object nor an 'aovlist' object.",
		     "Le modèle fourni n'est ni un objet 'aov' ni 'aovlist'.")
	  }
	}
	#-------------------------------------
	#	Initier les traitements de base
	#-------------------------------------
	robuste <- FALSE
	check_ancova <- FALSE
	alea <- FALSE
	alea_plus <- FALSE  # Indique si la formule est trop complexe pour aov()
	check_manova <- FALSE # Détecte si l'on doit faire une manova.
	#-------------------------------------
	#	Contrôler les entrées
	#-------------------------------------
	if(is.null(g)) {
		g <- data[,-1]
	} else {# RAS
	}
	if(is.null(x)) {
		x <- data[,1]
	} else {# RAS
	}
	# Factoriser les colonnes binaires et texte dans g
	g <- data.frame(lapply(g, function(col) {
	  if (is.character(col)) {
		# Convertir les colonnes de type texte en facteur
		return(as.factor(col))
	  } else if (is.numeric(col) && length(unique(na.omit(col))) == 2 &&
				 all(sort(unique(na.omit(col))) %in% c(0, 1))) {
		# Convertir les colonnes numériques binaires (0/1) en facteur
		return(as.factor(col))
	  } else {
		# Garder les autres colonnes inchangées
		return(col)
	  }
	}))
	data <- data.frame(x,g)
	# A faire, afficher le débugage de base	print(formula)
	if (debug==TRUE) {
		cat("head(data)\n")
		print(head(data))
		cat("print(formula)\n")
		print(formula)
	}

	##################
	# Contrôler que x n'est pas discrète, sinon anova robuste.
	##################
	discret <- discret.test(x)
	##################
	#	ANOVA ou MANOVA ? Détecter le type de traitement à faire ?
	##################

	# A FAIRE : contrôler x et si multivarié check_manova <- TRUE


	##################
	#	ANOVA ou ANCOVA ? Détecter le type de traitement à faire ?
	##################
	check_ancova <- .detect_model_type(formula, data, debug=debug)
	if (check_ancova == FALSE) {
		k <- .vbse("No non-binary numeric variables (is.numeric()) found among the explanatory variables => using an ANOVA.",
		"L'absence de variables numériques non binaires (is.numeric()) dans les variables explicatives dirige le traitement vers une ANOVA.",
		verbose=verbose,k=k)
	} else {
		k <- .vbse("A continuous numeric variable (or more) was found among the explanatory variables => using an ANCOVA.",
		"La présence d'une variable numérique (ou plus) continue dans les variables explicatives dirige le traitement vers une ANCOVA.",
		verbose=verbose,k=k)
	}
	#-------------------------------------
	# Contrôler la présence d'un effet aléatoire
	#-------------------------------------
	# Effet aléatoire ? Error dans la formule. Error(établissement/Lycée) ax+b ou Error(établissement) b
	# Il faut ici détecter la présence de Error dans la formule ou si paired==TRUE.
	# Vérifier la présence du mot "Error" dans la formule ou si paired est TRUE
	# Détection d'effets aléatoires ou de données appariées
	if (grepl("Error", deparse(formula)) || (exists("paired") && paired == TRUE)) {
	  alea <- TRUE
	  k <- .vbse("The model formula or settings indicate the presence of random effects or paired data. Adjusting analysis accordingly.",
		  "La formule du modèle ou les paramètres indiquent la présence d'effets aléatoires ou de données appariées. Le traitement tiendra compte de ces effets.",
		  verbose = verbose, k = k)

	  # Détection d'une complexité accrue dans la formule
	  formula_text <- deparse(formula)
	  # Vérifier la présence de structures complexes comme des termes avec des slopes aléatoires ou plusieurs niveaux d'effets aléatoires
	  if (grepl("\\(.*\\|.*\\)", formula_text) && length(regmatches(formula_text, gregexpr("\\|", formula_text))[[1]]) > 1) {
		# Exemples de motifs complexes : plusieurs "|" indiquant des effets multiples ou croisés
		alea_plus <- TRUE
		k <- .vbse("The formula appears too complex for aov() and suggests a mixed model is needed.",
		  "La formule semble trop complexe pour aov() et suggère l'utilisation d'un modèle mixte.",
		  verbose = verbose, k = k)
	  }
	}
	##################
	# Préparer les interactions de facteurs dans g_cat
	##################
###
# Ici, je cogite.
# A faire - Que faire si on ajoute un paramètre within (wt) à m.test() pour gérer un future (terme exact à définir) terme changeant entre chaque mesure répété.
###

	if (!is.null(id)) {
		# 1) Vérifier que 'id' est dans les noms de colonnes
		col_to_exclude <- intersect(id, names(g))  # au cas où id = "NomCol" (ou plusieurs)
		if (length(col_to_exclude) == 0) {
			warning("La variable d’appariement indiquée n’existe pas dans g. Aucune exclusion faite.")
			g_temp <- g
		} else {
			# 2) Exclure la/les colonne(s) 'id'
			g_temp <- g[ , setdiff(names(g), col_to_exclude), drop = FALSE]
		}
	} else {
		g_temp <- g
	}
	if (check_ancova == FALSE) {
	  # Pas d'ANCOVA => interaction() sur TOUTES les colonnes de g
	  g_cat <- interaction(g_temp, drop = TRUE)
	} else if (check_ancova==TRUE) {
	  #------------------------------------------------------------------
	  #
	  #     ANCOVA
	  #
	  #------------------------------------------------------------------




		#######################
		#	Binner les variables numériques, si possible et par ordre de corrélation à x décroissante
		#######################
		g_binned <- .auto_preprocess_g(x,g_temp, debug=TRUE)
		########
		#	Afficher un message faisant le bilan du niveau de binnage atteint... (nb de var, nb de niveaux)
		########
		# Identifier les colonnes numériques restantes (non binaires)
		numeric_cols <- sapply(g_binned, is.numeric)
		# Construire l'interaction sans les colonnes numériques strictes
		g_cat <- interaction(g_binned[!numeric_cols], drop = TRUE)
		# si TOUTES les colonnes sont numériques, g_cat sera un facteur à 1 niveau
		if (ncol(g[!numeric_cols]) == 0) {
			.exit("No categorical variable: g_cat will have only one level (an empty interaction).","Aucune variable catégorique : g_cat aura un seul niveau (une interaction vide).")
		}
	}
	# Alpha avec correction de Sidak
	pval <- 1-(1-alpha)^(1/length(unique(g_cat)))
	# Contrôle de la normalité des groupes croisés pour paramétrage du post-hoc
	pvals_normal <- .normality(x,g_cat)
	if (min(pvals_normal)<=pval) {
		check_normality <- FALSE
		check_variance_equal <-  FALSE
	} else {
		check_normality <- TRUE
		pvals_bartlett <- bartlett.test(x,g_cat)$p.value
		if (pvals_bartlett <= alpha) {
			check_variance_equal <-  FALSE
		} else {check_variance_equal <-  TRUE}
	}
	# Contrôle de la variance des groupes croisés pour paramétrage du post-hoc


	##################
	# Données appariées - RM-ANOVA - Repeat Measures
	##################

	########
	#           Implanter les contrôles de l'id et les alignements comme à .one_factor_analysis
	########

	# Analyser ce que l'on fait selon 1) 1 facteur, 2) n facteurs et 3) ANCOVA

	# 1) Normalité des différences intra-sujets - normalité des contrastes intra-sujets.
	# 1') Supplétion d'une approche solide Tester la normalité des contrastes (Contrastes orthogonaux) - Helmert

	# 2) Homogénéité des variances et des co-variances (sphéricité) : test de Mauchly ; corrections Greenhouse-Geisser ou Huynh-Feldt si violée.

	# 3) Echelle d'intervalle ou de ratio, contrôler à minima que x à 5 niveaux.

	if (paired == TRUE) {
	  #########################
	  #    ginteract
	  #########################

	  # On image un g ici à un seul facteur - mais il faudra se documenter sur le cas ou g à n facteurs...
	  # Mais il faudra certainement faire une interaction de tous les facteurs de g en ginteract
	  # Il faudra aussi creuser l'inclusion ou l'exclusion des covariables si ANCOVA.
	  if (!exists("ginteract") || is.null(ginteract)) {
	    ginteract <- droplevels(interaction(as.data.frame(g), drop = TRUE))
	  }
	  #########################
	  if (nlevels(ginteract) >= 3L) {
  	  # --- 1) Vérification de l'échelle d'intervalle ou ratio ---
	    if (length(unique(x)) < 5) {
	      k <- .vbse(
	        "Interval or ratio scale check: ensure the dependent variable has at least 5 distinct values.\n\tVerify that the measurement scale is appropriate (interval or ratio).",
	        "Contrôle de l’échelle d’intervalle ou de rapport : la variable dépendante doit présenter au moins 5 valeurs distinctes.\n\tVérifiez que l’échelle de mesure est bien de type intervalle ou rapport.",
	        verbose = verbose, k = k, cpt = "on")
	      k <- .vbse(
	        "Switching to a robust repeated-measures route (e.g., Friedman) for later steps.",
	        "Orientation vers une voie robuste en mesures répétées (p. ex. Friedman) pour la suite.",
	        verbose = verbose, k = k, cpt = "off"
	      )
	      robuste <- TRUE
	    } else { # Si x est OK, on continue
	      # 2) Normalité des différences intra-sujets - normalité des contrastes intra-sujets.

	      k <- .vbse(
	        "XXXXX",
	        "Contrôle de la normalité des différences intra-sujets.",
	        verbose = verbose, k = k, cpt = "on")
	      # 2') Ajout d'une approche solide Tester la normalité des contrastes (Contrastes orthogonaux) - Helmert
	      base_long <- data.frame(
	        id   = factor(data[[id]]),
	        cond = droplevels(ginteract),
	        x    = as.numeric(x)
	      )

	      # Long -> Wide (1 ligne = 1 sujet ; colonnes = niveaux de ginteract)
	      wide <- reshape(
	        data.frame(id = factor(data[[id]]), cond = droplevels(ginteract), x = as.numeric(x)),
	        timevar   = "cond", idvar = "id", v.names = "x", direction = "wide"
	      )

	      ## IMPORTANT : définir ces deux objets pour la suite
	      meas_cols <- grep("^x\\.", names(wide), value = TRUE)
	      score_mat <- as.matrix(wide[, meas_cols, drop = FALSE])

	      ## 2) Normalité des différences intra-sujets (toutes paires)
	      pairs_idx <- combn(seq_len(ncol(score_mat)), 2)
	      diff_mat  <- apply(pairs_idx, 2, function(j) score_mat[, j[1]] - score_mat[, j[2]])
	      colnames(diff_mat) <- apply(pairs_idx, 2, function(j) {
	        paste0(sub("^x\\.", "", meas_cols[j[1]]), " - ", sub("^x\\.", "", meas_cols[j[2]]))
	      })

	      pvals_diffs <- apply(diff_mat, 2, function(v) if (length(v) <= 5000L) shapiro.test(v)$p.value else 1)

	      if (any(pvals_diffs < alpha, na.rm = TRUE)) {
	        k <- .vbse(
	          paste0("Within-subject differences not normal (min p = ", .format_pval(min(pvals_diffs, na.rm = TRUE)), ")."),
	          paste0("Différences intra-sujets non normales (p min = ", .format_pval(min(pvals_diffs, na.rm = TRUE)), ")."),
	          verbose = verbose, k = k, cpt = "on"
	        )
	      } else {
	        k <- .vbse(
	          paste0("Within-subject differences normal (min p = ", .format_pval(min(pvals_diffs, na.rm = TRUE)), ")."),
	          paste0("Différences intra-sujets normales (p min = ", .format_pval(min(pvals_diffs, na.rm = TRUE)), ")."),
	          verbose = verbose, k = k, cpt = "on"
	        )
	      }


	      ## 2') Normalité des contrastes orthogonaux (Helmert)
	      k <- .vbse(
	        "XXXXX",
	        "Contrôle de la normalité des contrastes orthogonaux (Helmert).",
	        verbose = verbose, k = k, cpt = "on")
	      H  <- contr.helmert(ncol(score_mat))
	      HC <- score_mat %*% H

	      pvals_helm <- apply(HC, 2, function(v) if (length(v) <= 5000L) shapiro.test(v)$p.value else 1)

	      if (any(pvals_helm < alpha, na.rm = TRUE)) {
	        k <- .vbse(
	          paste0("Helmert contrast normality violated (min p = ", .format_pval(min(pvals_helm, na.rm = TRUE)), ")."),
	          paste0("Normalité des contrastes Helmert violée (p min = ", .format_pval(min(pvals_helm, na.rm = TRUE)), ")."),
	          verbose = verbose, k = k, cpt = "on"
	        )
	      } else {
	        k <- .vbse(
	          paste0("Helmert contrast normality satisfied (min p = ", .format_pval(min(pvals_helm, na.rm = TRUE)), ")."),
	          paste0("Normalité des contrastes Helmert respectée (p min = ", .format_pval(min(pvals_helm, na.rm = TRUE)), ")."),
	          verbose = verbose, k = k, cpt = "on"
	        )
	      }

	      ## 2) Normalité des différences intra-sujets (toutes paires)
	      pairs_idx <- combn(seq_len(ncol(score_mat)), 2)
	      diff_mat  <- apply(pairs_idx, 2, function(j) score_mat[, j[1]] - score_mat[, j[2]])
	      colnames(diff_mat) <- apply(pairs_idx, 2, function(j) {
	        paste0(sub("^x\\.", "", meas_cols[j[1]]), " - ", sub("^x\\.", "", meas_cols[j[2]]))
	      })

	      pvals_diffs <- apply(diff_mat, 2, function(v) {
	        if (length(v) <= 5000L) shapiro.test(v)$p.value else 1
	      })

	      if (any(pvals_diffs < alpha, na.rm = TRUE)) {
	        k <- .vbse(
	          paste0("Within-subject differences not normal (min p = ",
	                 .format_pval(min(pvals_diffs, na.rm = TRUE)), ")."),
	          paste0("Différences intra-sujets non normales (p min = ",
	                 .format_pval(min(pvals_diffs, na.rm = TRUE)), ")."),
	          verbose = verbose, k = k, cpt = "on"
	        )
	      } else {
	        k <- .vbse(
	          paste0("Within-subject differences normal (min p = ",
	                 .format_pval(min(pvals_diffs, na.rm = TRUE)), ")."),
	          paste0("Différences intra-sujets normales (p min = ",
	                 .format_pval(min(pvals_diffs, na.rm = TRUE)), ")."),
	          verbose = verbose, k = k, cpt = "on"
	        )
	      }

	      ## 2') Approche contrastes orthogonaux (Helmert)
	      H  <- contr.helmert(ncol(score_mat))
	      HC <- score_mat %*% H

	      pvals_helm <- apply(HC, 2, function(v) {
	        if (length(v) <= 5000L) shapiro.test(v)$p.value else 1
	      })

	      if (any(pvals_helm < alpha, na.rm = TRUE)) {
	        k <- .vbse(
	          paste0("Helmert contrast normality violated (min p = ",
	                 .format_pval(min(pvals_helm, na.rm = TRUE)), ")."),
	          paste0("Normalité des contrastes Helmert violée (p min = ",
	                 .format_pval(min(pvals_helm, na.rm = TRUE)), ")."),
	          verbose = verbose, k = k, cpt = "on"
	        )
	      } else {
	        k <- .vbse(
	          paste0("Helmert contrast normality satisfied (min p = ",
	                 .format_pval(min(pvals_helm, na.rm = TRUE)), ")."),
	          paste0("Normalité des contrastes Helmert respectée (p min = ",
	                 .format_pval(min(pvals_helm, na.rm = TRUE)), ")."),
	          verbose = verbose, k = k, cpt = "on"
	        )
	      }



	      } else {
	        # 3) Homogénéité des variances et des co-variances (sphéricité) : test de Mauchly ; corrections Greenhouse-Geisser ou Huynh-Feldt si violée.
	        k <- .vbse(
	          "Testing homogeneity of variances and covariances (sphericity) using Mauchly’s test.\n\tIf the sphericity assumption is violated, Greenhouse-Geisser or Huynh-Feldt corrections will be applied.",
	          "Contrôle de l’homogénéité des variances et des covariances (sphéricité) via le test de Mauchly.\n\tEn cas de violation de la sphéricité, les corrections de Greenhouse-Geisser ou Huynh-Feldt seront appliquées.",
	          verbose = verbose, k = k, cpt = "on")

	        df_ez <- data.frame(
	          dv   = as.numeric(x),
	          wid  = factor(data[[id]]),
	          cond = ginteract
	        )

	        k <- .vbse(
	          "Testing sphericity with Mauchly’s test (ezANOVA). If violated, Greenhouse–Geisser / Huynh–Feldt corrections are considered.",
	          "Contrôle de la sphéricité avec le test de Mauchly (ezANOVA). En cas de violation, corrections de Greenhouse–Geisser / Huynh–Feldt envisagées.",
	          verbose = verbose, k = k, cpt = "on"
	        )

	        suppressMessages({
	          ez_res <- ez::ezANOVA(
	            data       = df_ez,
	            dv         = .(dv),
	            wid        = .(wid),
	            within     = .(cond),
	            type       = 3,
	            detailed   = TRUE,
	            return_aov = TRUE
	          )
	        })

	        p_mauchly <- ez_res$Mauchly$p[1]

	        if (p_mauchly < alpha) {
	          gg_eps <- ez_res$`Sphericity Corrections`$GGe[1]
	          hf_eps <- ez_res$`Sphericity Corrections`$HFe[1]
	          p_gg   <- ez_res$`Sphericity Corrections$`p[GG][1]
	          p_hf   <- ez_res$`Sphericity Corrections$`p[HF][1]

	          k <- .vbse(
	            paste0(
	              "Mauchly’s test indicates sphericity is violated (p = ", .format_pval(p_mauchly), "). ",
	              "Greenhouse–Geisser ε ≈ ", round(gg_eps, 3),
	              " (p[GG] = ", .format_pval(p_gg), "); ",
	              "Huynh–Feldt ε ≈ ", round(hf_eps, 3),
	              " (p[HF] = ", .format_pval(p_hf), ")."
	            ),
	            paste0(
	              "Le test de Mauchly indique une violation de la sphéricité (p = ", .format_pval(p_mauchly), "). ",
	              "Greenhouse–Geisser ε ≈ ", round(gg_eps, 3),
	              " (p[GG] = ", .format_pval(p_gg), "); ",
	              "Huynh–Feldt ε ≈ ", round(hf_eps, 3),
	              " (p[HF] = ", .format_pval(p_hf), ")."
	            ),
	            verbose = verbose, k = k, cpt = "off"
	          )
	        } else {
	          k <- .vbse(
	            paste0("Mauchly’s test suggests sphericity holds (p = ", .format_pval(p_mauchly), ")."),
	            paste0("Le test de Mauchly suggère que la sphéricité est respectée (p = ", .format_pval(p_mauchly), ")."),
	            verbose = verbose, k = k, cpt = "off"
	          )
	        }


	      }





	    }
	    # Faire un embranchement de message pour annoncer le passage vers une situation paramétrique ou non.


  	  # Selon que g présente 1 ou n facteur, partir vers un message dirigeant vers un test robuste de Friedman ou autre.
  	  # voir ce que l'on annonce selon que l'ancova se profile...

}







	# 4) Attention : vérifier que vos sujets sont indépendants (on ne peut vérifier cela avec R)

	# 4. Échelle d’intervalle ou de ratio pour Y	Oui	Bon sens/statut de la variable
	# 5. Covariable mesurée sans erreur (fiable)	Oui	Validation préalable de la covariable
	# 6. Covariable indépendante du facteur	Oui	Tester absence’interaction ou de corrélation forte entre facteur et covariable
	# 7. Homogénéité des pentes (interaction covariable × facteur)	Oui	Tester l'interaction covariable × facteur : si significative, l’ANCOVA n’est pas appropriée

	##################
	# Contrôler l'équilibrage des données
	##################
	#table(g)
	table_data <- table(g)
	if (length(unique(table_data)) == 1) {

		# Données équilibrées
		.dbg("","Les données sont équilibrées, vers une tentative d'ANOVA.",debug=debug)
		k <- .vbse( "The data are balanced (table(g)), attempting an ANOVA.",
		  "Les données sont équilibrées (table(g)), vers une tentative d'ANOVA.",
		  verbose = verbose, k = k)
		model <- aov(formula, data=data)
	} else {
		min_sample <- min(table_data)
		max_sample <- max(table_data)
# REVOIR TOUS LES dbg()
		if(max_sample/min_sample > 2) {
			.dbg("","Les données sont trop déséquilibrées, vers une ANOVA robuste.",debug=debug)
			k <- .vbse("The data are too unbalanced (table(g)), moving towards a robust ANOVA.\n\tSome groups are more than twice as large as others.",
			  "Les données sont trop déséquilibrées (table(g)), vers une ANOVA robuste.\n\tCertains groupes sont plus de 2 fois plus nombreux que d'autres.",
			  verbose = verbose, k = k)



			robuste <- TRUE
		} else {
			.dbg("","Les données sont légèrement dééquilibrées ((table(g)), vers une ANOVA de type 3.\n",debug=debug)
			k <- .vbse("The data are slightly unbalanced (table(g)), moving towards a type 3 ANOVA.",
			  "Les données sont légèrement déséquilibrées (table(g)), vers une ANOVA de type 3.",
			  verbose = verbose, k = k)
			###############
			#	Indépendance des facteurs si déséquilibre et formule en +
			###############
			# Faire une boucle avec GTest() de {DescTools} qui contrôle d'éventuels dépendance entre les facteurs de g
			# Répétition de tests avec dépendance, faire une correction de Holm.
			# Si dépendance (1 p-value < 0.05) et présence de + dans formula, Remplacer les + par des * si dépendance.
			# Créer une sortie de control independence qui permette d'annoncer que des changements ont eu lieu
			k <- k+1
			updated_formula <- .control_independence(formula, g, alpha=alpha,debug = debug)
			# Conserver aussi formula tt de même
			# puis faire une comparaison avec anova()
			options(contrasts = c("contr.sum", "contr.poly"))
			# Pour un modèle linéaire :
			model <- lm(formula, data = data)
			Anova(model, type = "III")
			#Anova(model,type=3) # Attention ! Anova avec majuscule !
			if (updated_formula != formula) {
#####-----------------------
#		A TESTER
#####-----------------------
				options(contrasts = c("contr.sum", "contr.poly"))
				# Pour un modèle linéaire :
				model2 <- lm(formula, data = data)
				Anova(model, type = "III")
				#Anova(model,type=3) # Attention ! Anova avec majuscule !
				# Comparaison des modèles
				comparison <- anova(model, model2)
				# Vérifie si le modèle avec interactions est significativement meilleur
				# Ici, on utilise la p-value du test F comparant les deux modèles
				if (!is.null(comparison$`Pr(>F)`[2]) && comparison$`Pr(>F)`[2] < 0.05) {
					k <- .vbse("The model with added interactions appears more appropriate. It is recommended to rerun m.test() including these interactions.",
					  "Le modèle avec interactions ajoutées semble plus pertinent. Il est recommandé de relancer m.test() en intégrant ces interactions.",
					  verbose = verbose, k = k)
					k <- .vbse(paste0("Updated formula: ", deparse(updated_formula)),
					  paste0("Formule actualisée : ", deparse(updated_formula)),
					  verbose = verbose, k = k, cpt = "off")
				}
			}
		}
	}
	##################
	#	Check des conditions de bases.
	##################
	# Données répétées ? paired==TRUE ; => partir vers library(ez) et # ANOVA avec test de sphéricité ez_result <- ezANOVA() -
	# 				==> m.test() doit-t elle intégrer un within ? et un message pour dire de l'utiliser ?
	# Effet aléatoire ? Error dans la formule. Error(établissement/Lycée) ax+b ou Error(établissement) b

	# Que faire si répété et effet aléatoire ?

# Un bout de code à exploiter en cas d'effet aléatorie ? à considérer comme robuste ou Non
# Quelles assomptions contrôler ?
		#	library(lme4)
		#model <- lmer(Note~Lycée+(1|établissement), data=data) # Construction d'un modèle mixte difficile à lire
		#summary(model )
		#library(lmerTest)
		#model  <- lmerTest::lmer(Note~Lycée+(1|établissement), data=data) # Mise en forme du modèle pour avoir des p-values
		#ranova(model) # Pour avoir un anova avec effet aléatoire et confirmer que l'établissement n'a pas d'effet. On obtient la même chose en faisant rand(model)
		#summary(mod_rep)
		#library(car)
		#Anova(mod_rep)  # Conversion du modèle pour avoir une anova classique et voir l'effet du lycée.

		# outliers ?


	if (robuste==FALSE) {
		###############################
		#	Contrôle d'assomptions
		###############################
		#-----------------------------------
		# Contrôle de la normalité
		#-----------------------------------
		.dbg("","Contrôle de la normalité des résidus.")
		residus <- get_residuals(model)
		pvals <- .normality(residus)


#		if (alea==FALSE) {
#			pvals <- .normality(model$residuals)
	#	} else {
			# library(dae)
			#residuals.aovlist(model) # Pour récupérer les résidus d'un modèle à effet aléatoire.
			#fitted(model) # Pour récupérer les données prédites (fitted) d'un modèle à effet  al#éatoire.
#		}

		if (min(pvals) > alpha) {
##
#			Afficher un message
##
			k <- .vbse(paste0("Control of normality of residuals - Shapiro-Wilk test (<=100), Jarque-Bera (<=1000), or none (>1000).\n\t",
				"Analysis of values by sample (shapiro.test() & jb.norm.test())\t\n",
				"\tNormal residuals. p-value: ", .format_pval(pvals)),
				paste0("Contrôle de la normalité des résidus - Test de Shapiro-Wilk (<=100), Jarque-Bera (<=1000), ou aucun (>1000).\n\t",
				"Analyse des résidus (shapiro.test() & jb.norm.test())\t\n",
				"\tRésidus normaux. p-value : ", .format_pval(pvals)),k = k, verbose = verbose)
			# Contrôle de la variance
			# Vérifier que les échantillons sont normaux



			#####
			#	A tester, comment se comporte cette étape dans une ANCOVA.
			#####


			if (min(pvals_normal) > pval) {
				#-----------------------------------
				# Homogénéité de la variance
				#-----------------------------------
				k <- .vbse(paste0("Control of normality for crossed subgroups - Shapiro-Wilk test (<=100), Jarque-Bera (<=1000) or nothing (>1000).\n\tAnalysis of values for each crossed subgroup by (shapiro.test() & jb.norm.test())\n\tNormal crossed subgroups suggest to use Bartlett test. min(p-value): ", .format_pval(min(pvals_normal)), "...\n\t\twith Sidak correction of alpha to ", .format_pval(pval)),
				  paste0("Contrôle de la normalité des sous-groupes croisés - Test de Shapiro-Wilk (≤100), Jarque-Bera (≤1000) ou aucun (>1000).\n\tAnalyse des valeurs de chaque sous-groupe croisé par (shapiro.test() & jb.norm.test())\n\tSous-groupes croisés normaux suggérant de faire usage du test de Bartlett. min(p-value) : ", .format_pval(min(pvals_normal)), "...\n\t\tavec correction de Sidak de alpha à ", .format_pval(pval)),
				  k = k, verbose = verbose)

				if (pvals_bartlett < alpha) {
					robuste <- TRUE
					k <- .vbse(paste0("Bartlett test (bartlett.test()) - Non-identical sample variances. p-value: ", .format_pval(pvals_bartlett)),
							   paste0("Test de Bartlett (bartlett.test()) - Variances des échantillons homogènes. p-value : ", .format_pval(pvals_bartlett)),
							   k = k, verbose = verbose)

				} else {
					k <- .vbse(paste0("Bartlett test (bartlett.test()) - Identical sample variances. p-value: ", .format_pval(pvals_bartlett)),
						   paste0("Test de Bartlett (bartlett.test()) - Variance homogène des échantillons. p-value : ", .format_pval(pvals_bartlett)),
						   k = k, verbose = verbose)
				}
			} else {
				k <- .vbse(paste0("Control of normality - Shapiro-Wilk test (<=100), Jarque-Bera (<=1000) or nothing (>1000).\n\tAnalyse of values of sample by (shapiro.test() & jb.norm.test())\n\tNormal samples suggest to use Levene test. min(p-value): ", .format_pval(min(pvals)), "...\n\t\twith Sidak correction of alpha to ", .format_pval(pval)),
					paste0("Contrôle de la normalité - Test de Shapiro-Wilk (≤100), Jarque-Bera (≤1000) ou aucun test (>1000).\n\tAnalyse des valeurs des échantillons par (shapiro.test() & jb.norm.test())\n\tÉchantillons normaux suggérant de faire usage du test de Levene. min(p-value) : ", .format_pval(min(pvals)), "...\n\t\tavec correction de Sidak de alpha à ", .format_pval(pval)),
					k = k, verbose = verbose)
				# Effectuer le test de Levene qui bascule automatiqueet sur Brown-Forsyth si nécessaire
				pvals <- levene.test(x,interaction(g_cat))$p.value
					if (pvals < alpha) {
# Le commentaire ici doit être reformaté à Levenue et BF
						k <- vbse(paste0(k, "Bartlett test (bartlett.test()) - Non-identical sample variances. p-value: ", pvals),
								  paste0(k, "Test de Bartlett (bartlett.test()) - Variances hétérogène des échantillons homogènes. p-value : ", pvals),
								  k = k, verbose = verbose)
# Fligner-Killeen (sur les rangs)
						pvals <- fligner.test(Note ~ paste(Sexe,Lycée))$p.value # pval>0.05, variances équivalentes
						if (pvals < alpha) {
							robuste <- TRUE
						} else {
						}

					} else {
						k <- vbse(paste0(k, ") Levene test (levene.test() of {lawstat}) - Identical sample variances. p-value: ", pvals),
								  paste0(k, ") Test de Levene (levene.test() de {lawstat}) - Variances des échantillons identiques. p-value : ", pvals),
								  k = k, verbose = verbose)
					}
			}
			if ((check_ancova==FALSE) & (robuste==FALSE)) {
				if (paired==FALSE) {

					# A mettre en importation
					#residus <- residuals.aovlist(model)
					residus_std <- residus/sd(residus)
					pvals <- as.vector(unlist(by(residus_std,g_cat,function(x) {t.test(x,mu=0)$p.value})))
					if (min(pvals)<pval) {
print("problème de moyenne")


					} else {
print("moyennes équivalentes à 0")
					}

			#########
			# Indépendance des mesures
			# Contrôler l'indépendance des mesures
			# Moyennes des catégories croisées à 0 par un t.test() répété avec correction de Holm.
			# Normalité des résidus des catégories-croisées.
			# Homogénéité de variances des résidus...
			#==> Cela doit inviter à la prudence, même en aovp.
				} else if (id==TRUE) {
			#####
			# Si id = TRUE ==> ezANOVA()
			# Il faut avoir contrôler la normalité et la variance avant de faire cet anova
			# et basculer sur un scénario robuste si pas possible autrement, lequel ?

				}
			} else if ((check_ancova==TRUE)& (robuste==FALSE)) {

				if (id==FALSE) {
			# A CONTROLER SI ANCOVA ancova == TRUE
			# Relation linéaire avec covariable
			# Homogénéité des pentes	-  Vérifier les interactions dans l’ANCOVA
				} else if (id==TRUE) {

				}
			}













		} else {
# Non normalité
			.vbse(paste0(") Control of normality of residuals - Shapiro-Wilk test (<=100), Jarque-Bera (<=1000), or none (>1000). Analysis of values by sample (shapiro.test() & jb.norm.test()) - Non-normal residuals. p-value: ", pvals),
			paste0(") Contrôle de la normalité des résidus - Shapiro-Wilk test (<=100), Jarque-Bera (<=1000), ou aucun (>1000). Analyse des résidus (shapiro.test() & jb.norm.test()) - Résidus non normaux. p-value : ", pvals),
			k = k, verbose = verbose)
			robuste <- TRUE
			# Prévoir un message de mise en garde si un updata_formula a eu lieu.

		} # Fin du contrôle de la normalité



	}
	if (robuste==TRUE) {
		# Signaler d'éventuels outliers avec rstatix

		# ANOVA par permutation aovp. ou si apparié avec une seule variable descriptive friedman ou sinon modèle mixte...

		# Que faire si effet aléatoire en mesures répétées ?

		# Que faire si ANCOVA ?
	}
	# Afficher message + bilan si p-value du modèle correcte.
	# Signaler présence d'éventuels facteurs intéressants si p-value du modèle incorrecte.
#sink(tempfile())
#résultat <- aovp(réponse ~ facteur, data = data)
#sink()  # Restaurer la sortie standard
# summary(model)[[1]]

		# Préparer le post-hoc SAUF SI ANCOVA (prévenir d'un message)
		#print(table(g_cat))


		######################
		#	Il faut adapter  check_normality & check_variance_equal si déséquilibre
		######################
		#Il faut afficher un message personnalisé en fonction de check_normality et check_variance...
		#Qui justifiera l'orientation du test post-hoc.
# Les morceaux de code seront affichés avec message.

		return(check <- list(x,g_cat,check_normality,check_variance_equal,k))
}
