#' Automatic average/median/variance comparison function.
#'
#' @param data numerical vector
#' @param cat category vector
#' @param alpha p-value threshold value for all the tests.
#' @param verbose to display the full reasoning of the analysis.
#' @param return allows to return the results of pairwise analysis (p-values and groups).
#' @param paired (under development) to allow the analysis of matched data.
#' @param control name of the category that will eventually be used as a control.
#' @param maxcat maximum number of categories allowed. When this number is high, some tests may return an error message.
#' @param plot to display the distribution of the data.
#' @param silent for displaying or not warnings.
#' @param boot to activate the boostrap on 'mean' and 'median'.
#' @param iter number f iterations (boot==TRUE).
#' @param conf confidence level of bootstrap.
#' @param code allows to display the simplified R source code to be able to do the same R study step by step.
#' @param debug when m.test return error.
#'
#' @return m.test() runs a decision tree to choose the most appropriate test series for sample comparison.
#' @return She chooses the tests, justifies her choices.
#' @return It can output groups of means or a comparison to a control.
#' @return Finally, it will measure the robustness of the results by bootstrap.
#' @importFrom fda.usc fanova.hetero
#' @importFrom agricolae kurtosis
#' @importFrom agricolae skewness
#' @importFrom agricolae SNK.test
#' @importFrom lawstat levene.test
#' @importFrom WRS2 med1way
#' @importFrom WRS2 medpb
#' @importFrom WRS2 t1way
#' @importFrom WRS2 lincon
#' @importFrom FSA dunnTest	
#' @importFrom onewaytests bf.test
#' @importFrom vioplot vioplot
#' @importFrom DescTools DunnettTest
#' @import methods
#' @export
#'
#' @examples
#' data(iris)
#' m.test(iris[,1],iris[,5],verbose=TRUE, return=TRUE)
#' m.test(iris[1:100,1],iris[1:100,5],verbose=TRUE, return=TRUE)
#' m.test(iris[,2],iris[,5],verbose=TRUE, return=TRUE)
#' m.test(iris[,3],iris[,5],verbose=TRUE, return=TRUE)
#' m.test(iris[,4],iris[,5],verbose=TRUE, plot=FALSE, return=FALSE, boot=FALSE)
#' m.test(iris[,1],iris[,5],verbose=TRUE, return=TRUE,control="setosa")
#' m.test(iris[,2],iris[,5],verbose=TRUE, return=TRUE,control="virginica")
#' m.test(iris[,3],iris[,5],verbose=TRUE, return=TRUE,control="setosa")
#' m.test(iris[,4],iris[,5],verbose=TRUE, return=TRUE,control="setosa")
m.test <- function (x = NULL, g = NULL, data = NULL, formula = NULL,
			 paired = FALSE, id = NULL, wt=NULL, within=NULL, 
			   alpha = 0.05, control = NULL, verbose = TRUE, plot = TRUE,
			   return = TRUE, boot = TRUE, iter = 0, conf = 0.95,
			   maxcat=50,silent=TRUE,	
			   code=FALSE,debug=FALSE){
	k <- 0 # Compteur de messages					
	if (code==TRUE) {verbose <- FALSE}
	if (debug==TRUE) {verbose <- FALSE ; code=FALSE}
	########################
	# 	iter
	########################
	if (iter==0) {iter <- 1/alpha*5}
	
	########################
	# 	Si formula n'est pas fournie, mais que x semble être une formula
	#   contrôle au passage de l'aspect multivarié.
	########################
	check_manova <- FALSE	
	check_anova <- FALSE	
	if (is.null(formula)) {
		if (inherits(x, "formula")) {
			.dbg("x appears to be a formula. Transferring to formula.","`x` semble être une formule. Transfert vers `formula`.", debug=debug)
			formula <- x
			x <- NULL  # On supprime la valeur de `x` pour éviter des conflits
		} 
	}
	########################
	# 	 Contrôle au passage de l'aspect multivarié de x, si x fourni
	########################
	########################		
	# Vérifier que x est multivarié - plusieurs variables dépendantes
	# A vérifier avant et après dans le code, but étant de passer vers anova <- TRUE (où un traitement manova est prévu dans .multi_factor_analysis.
	########################	
	if (!is.null(x)) {
		if (is.data.frame(x) || is.matrix(x)) {
			num_cols <- sapply(x, is.numeric)
			if (!all(num_cols)) {
				.exit("Error: 'x' contains non-numeric columns.",
					"Erreur : 'x' présente des colonnes non numériques.",verbose = verbose, return = return)
			}
			if ((is.data.frame(g))&&(nrow(g)!=nrow(x))) {
				.exit("Error: 'x' and 'g' length differ.",
					"Erreur : 'x' et 'g' n'ont pas les mêmes dimensions.",verbose = verbose, return = return)				
			}
			if (ncol(x)==1) {x <- x[,1] ; x <- as.vector(x)
				} else {check_manova <- TRUE} # x multivarié
		} else if (is.vector(x)&is.null(data)) {
			if (!is.numeric(x)) {
				.exit("Error: 'x' non-numeric.",
					"Erreur : 'x' non numérique.",verbose = verbose, return = return)			
			} else if (is.vector(g)&&(length(g)!=length(x))) { # si g vecteur
				.exit("Error: 'x' and 'g' length differ.",
					"Erreur : 'x' et 'g' n'ont pas la même taille.",verbose = verbose, return = return)			
				# comparer length de g
				# RAS
			} else if ((is.data.frame(g))&&(nrow(g)!=length(x))) { # si g data.frame 
				.exit("Error: 'x' and 'g' length differ.",
					"Erreur : 'x' et 'g' n'ont pas les mêmes dimensions.",verbose = verbose, return = return)					
			}		
		} else if (!is.null(data)) {
		  # Cas 4a : x est numérique (on l'interprète comme une liste d'indices de colonnes dans data)
		  if (is.numeric(x)) {
			if (!all(x %in% seq_len(ncol(data)))) {
			  .exit("Error: x contains invalid indices for data.",
				"Erreur : x contient des indices invalides pour data.",verbose = verbose, return = return)
			}
			x <- data[, x, drop = FALSE]
			#message("x a été extrait de data à partir des indices fournis.")
		  } else if (is.character(x)) { # Cas 4b : x est de type caractère (on l'interprète comme une liste de noms de colonnes dans data)
			if (!all(x %in% colnames(data))) {
			  .exit("Error: x contains column names that do not exist in data.",
				"Erreur : x contient des noms de colonnes qui n'existent pas dans data.",verbose = verbose, return = return)
			}
			x <- data[, x, drop = FALSE]
			#message("x a été extrait de data à partir des noms de colonnes fournis.")
		  }  else {
			.exit("Error: Unrecognized format of x. x must be a numeric vector, a data.frame, a matrix, or a list of indices/column names (if data is provided).","Erreur : format de x non reconnu. x doit être un vecteur numérique, une data.frame, une matrice ou une liste d'indices/noms de colonnes (si data est fourni).",
				verbose = verbose, return = return)
		  } 
		  if (ncol(x)==1) {x <- x[,1] ; x <- as.vector(x)
		  } else {check_manova <- TRUE} # x multivarié
	  } else {
		 .exit("Error: Unrecognized format of x. x must be a numeric vector, a data.frame, a matrix, or a list of indices/column names (if data is provided).","Erreur : format de x non reconnu. x doit être un vecteur numérique, une data.frame, une matrice ou une liste d'indices/noms de colonnes (si data est fourni).",
				verbose = verbose, return = return)
	  } 	
	}
	########################
	# 	Si data n'est pas fourni, mais que g semble être une data.frame
	########################
#	print("data") ; print(data)#
#	print("g");print(g);return(g)
	
	if (is.null(data)) {
	  if (is.data.frame(g)) {
		# Vérifier si `g` contient au moins deux colonnes
		if (ncol(g) >= 2) {
		  # Vérifier si une colonne de `g` est identique à `x`
		  if (any(sapply(g, function(col) all(col == x)))) {
			.dbg("g contains a column identical to x. g is assigned to data without being combined with x.",
				"`g` contient une colonne identique à `x`. `g` est attribué à `data` sans combinaison avec `x`.",
				debug=debug)
			data <- g
		  } else {
			.dbg("g does not contain a column identical to x. g is combined with x and assigned to data.",
				"`g` ne contient pas de colonne identique à `x`. `g` est combiné à `x` et attribué à `data`.",
				debug=debug)
			# Combiner `x` et `g` dans un nouveau data.frame
			data <- cbind(x = x, g)
		  }
		  g <- NULL  # `g` est attribué à `data`, donc on le met à NULL
		} else {
		  .dbg("`g` is a data.frame with fewer than 2 columns. It is kept as a vector or a single column.",
			"`g` est un data.frame avec moins de 2 colonnes. Conservé en tant que vecteur ou unique colonne.",
			debug=debug)
		  # Si `g` est un data.frame avec une seule colonne, on le traite comme un vecteur
		  g <- as.vector(g[[1]]) ; g <- as.factor(g)
		}
	  } else if (is.atomic(g) && !is.null(g)) {
		.dbg("`g` is a vector. It is kept as is.","`g` est un vecteur. Conservé tel quel.", debug=debug)
		# Rien à faire, `g` reste inchangé
	  } else if (is.null(formula)) {
		# `g` n'est ni un vecteur ni un data.frame approprié
		.exit("g must be a vector or a data.frame if data is NULL.", "`g` doit être un vecteur ou un data.frame si `data` est NULL.",
			verbose=verbose,return=return)
	  }
	}
	########################		
	# Si formula est fournie, vérifier et garantir son format
	########################
	# balises à suppr une fois la fonction validée.

print(formula)
	if (!is.null(formula)) {
		formula <- .formulator(formula, verbose=verbose, debug=debug, return=return)
	}	
print(formula)	
	########################		
	# Sauvegarde du nom réel de `id` dans `data` (ou extraction si nécessaire)
	########################
	pair_vector <- c()
	.dbg("Checking for the presence of a pairing/repeated measures variable.","Contrôle de la présence d'une variable d'appariement/répétitions.", debug=debug)
	if (!is.null(data) && !is.null(id)) {
		.dbg(NULL,"Tentative d'extraction de id de data si data fourni.", debug=debug)
	  if (is.character(id) && id %in% colnames(data)) {
		.dbg(NULL,"id est bien le nom d'une colonne de data.", debug=debug)
		# `id` est déjà le nom de la colonne
		#pair_name <- id
	  } else if (is.numeric(id) && id <= ncol(data) && length(id) == 1) {
		.dbg(NULL,"id est à considérer comme l'index d'une colonne de data.",debug=debug)
		# `id` est un index numérique, convertir en nom de colonne
		id <- colnames(data)[id]
	  } else if (length(id) == nrow(data.frame(data))) {
		if (debug==TRUE) {cat(.msg("\n","\tid est un vecteur externe à data dont il faut extraire nom et contenu.\n"))}
		# `id` est un vecteur externe, sauvegarder son contenu et son nom
		pair_vector <- id
		pair_expr <- substitute(id)  # Capturer l'expression originale
		id <- tryCatch(
		  deparse(pair_expr),  # Récupérer le nom ou une expression
		  error = function(e) "id"  # Utiliser un nom générique en cas d'erreur
		)
		if (is.null(id) || id == "") {
		  id <- "id"  # Défaut si aucun nom exploitable
		}
	  } else {
		if (verbose==TRUE) {
			warning(.msg("Warning: id is not corrected, and ignored.\n","Warning : 'id' doit être un nom ou un index valide d'une colonne de 'data'.\nid est ignoré.\n"))
		} else {return(1)}		
	  }
	} else if (!is.null(id)) {
		  .dbg("Attempt to extract id while data is not provided.","Tentative d'extraction de id alors que data non fourni.", debug=debug)
		  # `id` est un vecteur mais `data` est absent
		  pair_vector <- id
		  pair_expr <- substitute(id)
		  id <- tryCatch(
			deparse(pair_expr),
			error = function(e) "id"
		  )
		  if (is.null(id) || id == "") {
			id <- "id"
		  }
		  #print("id");print(id)
	}
	########################		
	# Sauvegarde du nom réel de `wt` dans `data` (ou extraction si nécessaire)
	# Attention, si `within` est fourni, l'attribuer à `wt`
	# `wt` et `within` ne peuvent être fournis les 2, il s'agit de la même variable.
	########################
	########################		
	# Advanced Handling of Within-Subject Variable (`wt`)
	########################
	wt_vector <- NULL
	wt_names <- NULL

	.dbg("Advanced within-subject variable processing", "Traitement avancé de la variable intra-sujet", debug=debug)

	# Handle 'within' parameter if provided
	if (!is.null(within)) {
	  wt <- within
	  .dbg("'within' parameter used for wt", "'within' utilisé pour wt", debug=debug)
	}

	if (!is.null(wt)) {
	  # Multiple handling strategies
	  if (!is.null(data)) {
		# Case 1: Multiple column names in data
		if (is.character(wt) && all(wt %in% colnames(data))) {
		  wt_names <- wt
		  .dbg("wt as multiple column names in data", "wt comme noms de colonnes multiples dans data", debug=debug)
		} 
		# Case 2: Multiple column indexes
		else if (is.numeric(wt) && all(wt <= ncol(data))) {
		  wt_names <- colnames(data)[wt]
		  .dbg("wt as multiple column indexes", "wt comme index de colonnes multiples", debug=debug)
		} 
		# Case 3: External vector matching data rows
		else if (length(wt) == nrow(data)) {
		  wt_vector <- wt
		  wt_expr <- substitute(wt)
		  wt_names <- tryCatch(
			deparse(wt_expr),
			error = function(e) "wt"
		  )
		  
		  # Ajouter le vecteur à data
		  if (is.null(wt_names) || wt_names == "") wt_names <- "wt"
		  data[[wt_names]] <- wt_vector
		  
		  .dbg("wt as external vector", "wt comme vecteur externe", debug=debug)
		} 
		# Case 4: External dataframe or matrix
		else if (is.data.frame(wt) || is.matrix(wt)) {
		  .dbg("Complex wt: external dataframe/matrix", "wt complexe : dataframe/matrice externe", debug=debug)
		  
		  # Validate cross-referencing with id
		  if (!is.null(id)) {
			id_values <- if (!is.null(data) && !is.null(id)) {
			  data[[id]]
			} else {
			  id
			}
			
			# Check completeness of data for each unique id
			unique_ids <- unique(id_values)
			complete_check <- sapply(unique_ids, function(unique_id) {
			  nrow(wt[wt[id] == unique_id, ]) > 0
			})
			
			if (!all(complete_check)) {
			  warning(.msg(
				"Warning: Some ids lack complete within-subject data.\n",
				"Attention : Certains identifiants manquent de données intra-sujet complètes.\n"
			  ))
			  return(1)
			}
		  }
		  
		  # Extract column names 
		  wt_names <- if (is.data.frame(wt)) colnames(wt) else colnames(wt)
		  
		  # Ajouter les données à data si nécessaire
		  if (is.data.frame(wt)) {
			for (col in wt_names) {
			  data[[col]] <- wt[[col]]
			}
		  }
		} 
		else {
		  warning(.msg(
			"Warning: 'wt' specification is invalid.\n",
			"Warning : La spécification de 'wt' est invalide.\n"
		  ))
		  return(1)
		}
	  } 
	  # If data is null, handle external wt
	  else {
		wt_vector <- wt
		wt_expr <- substitute(wt)
		wt_names <- tryCatch(
		  deparse(wt_expr),
		  error = function(e) "wt"
		)
		
		# Créer data avec le vecteur
		data <- data.frame(wt_vector)
		names(data) <- if (is.null(wt_names) || wt_names == "") "wt" else wt_names
	  }
	}


	########################
	#	Si formula est précisé ainsi que data, il faut nettoyer data que pour conserver 
	# les variables dépendantes (x simple ou multivarié) & les variables explicatives (g)
	# Exemple : si la formule est Y ~ I(log(X1))*X2, data = dt
	# et que dt fait en réalité 10 colonnes 
	#	Il faut à la fin que le data soit nettoyé des colonnes inutiles (tout sauf X1, X2 et Y)
	# => Et que g corresponde à X1 et X2
	########################
	print("g")
	print(g[1:10])
	print("x")
	print(x[1:10])
	print("check_manova")
	print(check_manova)


	if (!is.null(formula)) {
		check_multivariate_response <- function(formula, data) {
			response_expr <- formula[[2]]
			# Fonction simplifiée pour nettoyer les transformations
			clean_formula <- function(expr) {
				if (is.call(expr)) {
				  func_name <- as.character(expr[[1]])
				  if (func_name %in% c("I", "log", "sqrt", "exp", "scale")) {
					return(clean_formula(expr[[2]]))
				  }
				  return(expr)
				}
				return(expr)
			}
			# Détecter si multifactorielle
			is_multivariate <- if (is.call(response_expr)) {
				as.character(response_expr[[1]]) == "cbind" ||
				length(all.vars(clean_formula(response_expr))) > 1
			} else {
				FALSE
			}
			return(is_multivariate)
		}

		# Usage
		check_manova <- check_multivariate_response(formula, data)
	}

	print("check_manova")
	print(check_manova)

	
	
	
	
	############################################
	# Mode formula ou mode classique
	############################################
	.dbg("Data extraction based on the presence of a formula.",
		"Extraction des données en fonction de la présence d'une formule.", debug=debug)
		
		########################
		# Si la formule est fournie
		#########################
	if (!check_manova && !is.null(formula) && inherits(formula, "formula")) {
		# Gestion des formules avec `|`
print("nouveau code - cherche effet aléatoire")
		if (grepl("\\|", deparse(formula))) {
			print("|")
			split_formula <- strsplit(deparse(formula), "\\|")[[1]]
			if (length(split_formula) == 2) {
				print(split_formula)
				left_side <- strtrim(split_formula[1])
				right_side <- strtrim(split_formula[2])
				# Reconstruire une formule compatible
				formula <- as.formula(paste(left_side, "+ Error(", right_side, ")"))
				dbg("",paste0("\nFormule ajustée avec 'Error()' : ", deparse(formula)),debug=debug)
			} else {
				.exit("Error: The formula contains a malformed '|'.",
					"Erreur : La formule contient un '|' mal formé.",return=return,verbose=verbose)
			}
		}
		# Évaluer la formule avec l'environnement mis à jour
		mf <- tryCatch(
			model.frame(formula, data = data, na.action = na.omit, drop.unused.levels = TRUE),
			error = function(e) {
				.exit("Error evaluating the formula. Check your data and formula.",
					"Erreur lors de l'évaluation de la formule. Vérifiez vos données et votre formule.",
					return=return,verbose=verbose)
			}
		)
		########################
		# Si data est fournie
		#########################
		# Créer un environnement combinant le data.frame et l'environnement global
		if (!is.null(data) && is.data.frame(data)) {
		  env <- new.env(parent = parent.frame())
		  list2env(data, env)  # Ajouter les colonnes du data.frame à l'environnement
		  vars <- all.vars(formula) 
		  # Ajouter les variables globales référencées dans la formule
			# Ne pas utiliser 'var' comme nom de variable
			for (variable in vars) {
			  if (!exists(variable, envir = env, inherits = FALSE)) {
				assign(variable, get(variable, envir = parent.frame(), inherits = TRUE), envir = env)
			  }
			}
		  # Associer l'environnement fusionné à la formule
		  environment(formula) <- env
		########################
		# Si data est fournie et n'est pas au bon format
		#########################
		} else if(!is.null(data)&&!is.data.frame(data)) {
			.exit("","Le paramètre 'data' doit être un data.frame valide ou NULL si la formule inclut les données.")
		}
		########################
		# Si id est fournie
		#########################
		# Modification de la formule pour inclure les variables d'identification et contextuelles
		formula_temp <- formula

		# Gestion de la variable d'identification (id)
		if (!is.null(id)) {
		  paired <- TRUE  # Forcer `paired = TRUE` si `id` est spécifié
		  
		  # Vérification de l'existence de la colonne id
		  if (!id %in% colnames(data) && length(pair_vector) == 0) {
			stop("Erreur : la colonne `id` spécifiée n'existe pas dans `data`.")
		  }
		  
		  # Ajouter `id` à la formule si absent
		  if (!id %in% all.vars(formula_temp)) {
			formula_temp <- update(formula_temp, paste0(". ~ . + ", id))
		  }
		}

		# Gestion des variables contextuelles (wt)
		if (!is.null(wt_names)) {
		  wt <- wt_names
		  # Vérifier et ajouter chaque variable wt absente
		  for (wt_var in wt_names) {
			if (!wt_var %in% all.vars(formula_temp)) {
			  formula_temp <- update(formula_temp, paste0(". ~ . + ", wt_var))
			}
		  }
		}
		########################		
		# Sauvegarde du nom réel de `wt` dans `data` (ou extraction si nécessaire)
		# Attention, si `within` est fourni, l'attribuer à `wt`
		# `wt` et `within` ne peuvent être fournis les 2, il s'agit de la même variable.
		########################		
		if (!is.null(within)) {
			wt <- within
		}
		if (!is.null(wt)) {
			# wt peut être comme id 
		}		
		###################################
		# Extraire les données nécessaires à l'application de la formule	
		###################################
		# Tenter d'évaluer la formule avec l'environnement mis à jour
		mf <- tryCatch(
		  model.frame(formula_temp, data = data, na.action = na.omit, drop.unused.levels = TRUE),
		  error = function(e) {
				.exit("Error while evaluating the formula. Please check your data and formula.",
					"Erreur lors de l'évaluation de la formule. Vérifiez vos données et votre formule.",
				verbose=verbose, return=return)
			}
		)
		###################
		#
		# Trier les données en fonction des variables explicatives et de l'appariement (par catégories croisées)
		#
		####################
		.dbg("\nSorting data based on explanatory variables and pairing if provided.\n", 
			 "\nTri des données en fonction des variables explicatives et de l'appariement si fourni.\n", 
			 debug = debug)
		# Récupérer les noms des colonnes explicatives, en excluant la colonne quantitative
		explicatives <- colnames(mf)[-1]  # Supposons que la première colonne est quantitative
		# Vérification de la présence de la variable d'appariement
		if (!is.null(id) && id %in% explicatives) {
		  # Déplacer la colonne d'appariement à la fin de la liste pour tri final
		  explicatives <- c(setdiff(explicatives, id), id)
		}
		# Tri des données par toutes les colonnes explicatives
		mf <- mf[do.call(order, mf[explicatives]), ]
		if (debug == TRUE) {
		  cat(.msg("\n", "Données triées :\n"))
		  print(head(mf))
		}

		# Mettre à jour les données triées dans `data` et `cat`
		#x <- mf_sorted[, 1]  # Colonne quantitative
		#cat <- mf_sorted[, -1]  # Autres colonnes explicatives
		# Gestion des formules avec plusieurs variables explicatives
		##########################
		#	n variables explicatives
		##########################
		if (ncol(mf) > 2) {
		  # On a data et formula, pas besoin de x et g
		  .dbg("Multiple explanatory variables detected.","Plusieurs variables explicatives détectées.", debug=debug)
		  data <- mf
		  formula <- as.formula(formula)
		  #data <- cbind(data,cat)
		  if ((ncol(mf)==3)&(paired==TRUE)) {
			.dbg("One-way ANOVA mode on paired data.","Mode ANOVA à 1 facteur sur données appariées.",debug=debug)
			
			# Remplacer la partie problématique par :
			if (is.call(formula[[2]])) {
			  x <- mf[[1]]  # La transformation est déjà appliquée dans mf
			} else {
			  x <- mf[[1]]
			}
			# Un raisonnement sur x et g suffit
			# En théorie, on pourrait effacer data et formula ou définir une formula simple ici.
			x <- mf[[1]]  # Variable dépendante (quantitative) 
			g <- data[,2] 
		  
		  } else {
			.dbg("Two-way or higher ANOVA mode activated.","Mode ANOVA à 2 facteurs ou plus activé.",debug=debug)
			check_anova <- TRUE # plus de 2 colonnes, plus d'une variable explicative ! ==> ANOVA à 2 facteurs ou +
		  }
		  
		  
		##########################
		#	1 variable explicative
		##########################
		} else {
			# Remplacer la partie problématique par :
			if (is.call(formula[[2]])) {
			  x <- mf[[1]]  # La transformation est déjà appliquée dans mf
			} else {
			  x <- mf[[1]]
			}
			# Un raisonnement sur x et g suffit
			# En théorie, on pourrait effacer data et formula ou définir une formula simple ici.
			x <- mf[[1]]  # Variable dépendante (quantitative) 
			g <- mf[-1]    # Variable explicative (qualitatives)
			g <- as.vector(unlist(g))
		}	
	} else if (!check_manova) {
		########################
		#	Pas de formule fournie
		########################
		.dbg("Data analysis without a specified formula.","Analyse des données sans formule spécifiée.", debug=debug)
		
		# Si pas de formule, utiliser les arguments explicites 'data' et 'cat' sous la forme de simples  vecteurs
		if (is.null(x) || is.null(g)) {
			.exit("If no 'formula' is provided, the arguments 'x' and 'g' must be specified.","Si aucun 'formula' n'est fourni, les arguments 'x' et 'g' doivent être spécifiés.",verbose=verbose, return=return)
		}
		if (!is.numeric(x)) {
			.exit("'x' must be a numeric vector representing the quantitative variable.","'x' doit être un vecteur numérique représentant la variable quantitative.",verbose=verbose, return=return)
		}
		if (!is.factor(g)) {
		  g <- as.factor(g)  # Conversion en facteur si nécessaire
		}
		if (nrow(data.frame(x)) != nrow(data.frame(g))) {
			.exit("x and g do not have the same dimensions.","x et g ne présentent pas les mêmes dimensions.",verbose=verbose, return=return)
		}
		#
		if (paired == TRUE) {
			if (is.null(id)) {
			#	paired est TRUE, il faut obligatoirement que id soit fourni 
			#			(sauf si cat ne contient que 2 catégories) - sinon message d'erreur.
				# Aucun `id` n'est spécifié
				if (length(unique(g)) == 2) {
					# Deux catégories : autoriser un test apparié direct
					if (verbose == TRUE) {cat("Mode apparié activé pour deux catégories.\n")}
					# Trier selon les catégories et maintenir la correspondance
					combined_data <- data.frame(x, g)
					combined_data <- combined_data[order(combined_data$g), ]
					x <- combined_data$x
					g <- combined_data$g
					data <- combined_data
					formula <- formula(x~g)
				} else {
					# Plus de deux catégories, `id` obligatoire
					.exit("Error: paired=TRUE requires an identification variable id if g contains more than two categories.\nOtherwise, use a formula to specify the consideration of identifiers via Error().",
						"Erreur : `paired=TRUE` nécessite une variable d'identification des individidus`id`si `g` contient plus de deux catégories.\nSinon utiliser formula pour indiquer la prise en compte de identifiants via Error().",
						verbose=verbose, return=return)
				}
			} else {
				# `id` est spécifié, il doit être ajouté à un tableau global si plus de 2 catégories.
				# ou sinon servir à trier data et g si 2 catégories
				if (!is.null(data) && is.data.frame(data)) {
					# Vérifier si `id` est valide
					if (is.character(id) && id %in% colnames(data)) {
						# Nom de colonne
						id <- data[[id]]
					} else if (is.numeric(id) && id <= ncol(data) && length(id) == 1) {
						# Position de colonne
						id <- data[[id]]
					} else if (length(id) == nrow(data.frame(data))) {
						# Vecteur externe valide
						id <- id
					} else {
						.exit("","Erreur : `id` doit être un nom, une position de colonne, ou un vecteur valide.")
					}
				} else {
					# `data` non spécifié, `id` doit être un vecteur externe
					if (length(id) != length(g)) {
						.exit("","Erreur : `id` doit avoir la même longueur que `g`.")
					}
				}

				# Trier les données selon `id`
				
				########
				# A rectifier en indiquant si on a un jeu global (>2 catégories) ou si comme ici on reste à date et cat...
				########

				combined_data <- data.frame(x, g, id)
				combined_data <- combined_data[order(combined_data$id, combined_data$g), ]
				x <- combined_data$x
				g <- combined_data$g
				id <- combined_data$id
				data <- combined_data
				formula <- formula(x~g + Error(id/g))
			}
		} else {
			# Pas d'appariements des données, la formule de base est
			formula <- formula(x~g)
		}
	}


    if (paired==TRUE) {if (debug) cat("Analyse appariée activée.\n")}
    ###########################################
    #	Fonctions internes
    ###########################################
    if (debug==TRUE) {cat(.msg("\n","Compilation des fonctions de base.\n"))}
	###################
	# paired doit être développé dans cette fonction : mis en argument mais tout à faire.	
	
  boots <- function(x,g,ctrl=FALSE,type="mean",var.equal=FALSE,conf=0.95,iter=500,alpha=alpha,paired=paired) {
	pvals <- c()
	for (i in 1:iter) {
	  if (type=="mean") {
		temp <- t.test(sample(x[g==unique(g)[1]],replace=TRUE),sample(x[g==unique(g)[2]],replace=TRUE),var.equal=var.equal,paired=paired)$p.value
	  } else if (type=="median") {
		#temp <- wilcox.test(sample(data[cat==unique(cat)[1]],replace=TRUE),sample(data[cat==unique(cat)[2]],replace=TRUE))$p.value
		temp <- wilcox.test(sample(x[g==unique(g)[1]],replace=TRUE),sample(x[g==unique(g)[2]],replace=TRUE),exact=FALSE,paired=paired)$p.value
	  } else if (type=="ks") {
		ech1 <- sample(x[g==unique(g)[1]],replace=TRUE)
		ech2 <- sample(x[g==unique(g)[2]],replace=TRUE)
		ech1 <- (ech1 - median(ech1))/sd(ech1)
		ech2 <- (ech2 - median(ech2))/sd(ech2)
		temp <- ks.test(ech1,ech2)$p.value
	  }
	  pvals <- c(pvals,temp)
	}
	pvals <- quantile(pvals,probs=conf,na.rm=T)
	if (ctrl == TRUE) {
	  if (pvals <= alpha) {
		synth <- list()
		starss <- c("","")
		starss[-ind_control] <- ifelse(pvals <=0.001,"***",ifelse(pvals <=0.01,"**",
																  ifelse(pvals <=0.05,"*","")))
		synth$groups <- data.frame(categories=unique(g),group=starss)
		synth$p.value <- pvals
	  } else {
		synth <- list()
		synth$groups <- data.frame(categories=unique(g),group=c("",""))
		synth$p.value <- pvals
	  }
	} else if (ctrl==FALSE) {
	  synth <- list()
	  if (pvals <= alpha) {
		synth$groups <- data.frame(categories=unique(g),groups=c("a","b"))
		synth$p.value <- pvals
	  } else {
		synth$groups <- data.frame(categories=unique(g),groups=c("a","a"))
		synth$p.value <- pvals
	  }
	}
	return(synth)
  }
	#
  skew <- function(vector) {return(abs(skewness(vector)))}
  skew2 <- function(vector) {return(skewness.norm.test(vector)$p.value)}
  kurto <- function(vector) {if (is.na(abs(kurtosis(vector)))){return(10)} ; return(abs(kurtosis(vector)))}
  kurto2 <- function(vector) {return(kurtosis.norm.test(vector)$p.value)}
  if (any((is.na(x)))|(any((is.na(g))))){
	if (verbose==TRUE) {cat("Warning! Missing values.\n")}
	temp <- data.frame(x,g)
	temp <- na.omit(temp)
	x <- temp[,1]
	g <- temp[,-1]
  }
  
  
  .dbg("Analysis of the presence of infinite values.\n", 
     "Analyse de la présence de valeurs infinies.\n", 
     debug = debug)
  if(any(!is.finite(x))) {
	.exit("Error! Infinite values in data. Analysis impossible.","Erreur ! Valeurs infinies dans les données. Analyse impossible.")
  }	  

	.dbg("Control of repetitions, number of values per category.", 
		 "Contrôle des répétitions, du nombre de valeurs par catégories.", 
		 debug = debug)
#	  print("x") ; print(x[1:5])#
#	  print("g") ; print(g[1:5])
#	  print("data") ; print(head(data))
#	  print("formula") ; print(formula)
  
  ###################
  # Si les variables explicatives ne sont pas numériques et qu'il y a qu'une seule valeur par variables explicatives croisées,
  # alors, l'on va autoriser paired=TRUE et dans ce cas :
	# id reçoit le nom de la dernière colonne de data
	# message d'alerte pour prévenir que les catégories croisées donnent toute 1 valeur
	# et que la variable x est désignée automatiquement comme variable d'appariement.
	# invitation de l'utilisateur à utiliser les arguments paired et id pour paramétrer selon son goût
	# si il ne reste qu'une variable explicative en plus de id (soit 3 colonnes en tout dans data), ANOVA<-FALSE
	# message if(debug==TRUE)&ANOVA==FALSE {cat(.msg("","Retour vers un scénario d'ANOVA à 1 facteur sur données appariées."))}
	# message if(debug==TRUE)&ANOVA==FALSE {cat(.msg("","Retour vers un scénario d'ANOVA à 2 facteurs sur données appariées."))}
  ###################
	.dbg("Analyzing explanatory variables to determine if paired=TRUE can be automatically enabled.",
		"Analyse des variables explicatives pour déterminer si paired=TRUE peut être activé automatiquement.",
			debug=debug)
		
print(head(data))	
print("x");print(x[1:10])
print("g");print(g[1:10])
print("formula");print(formula)
	
	
# Vérifier si les variables explicatives sont non numériques
if (!all(sapply(data[, -1], is.numeric))) { 
	# Calcul des combinaisons croisées des variables explicatives
	combinaisons <- table(g) 

	if (all(combinaisons == 1)) { # Vérifier si toutes les combinaisons donnent une seule valeur
		# Activer `paired=TRUE`
		paired <- TRUE
		
		# Attribuer la dernière colonne comme variable d'appariement
		id <- colnames(data)[ncol(data)]
		
		# Messages d'alerte
		cat(.msg("","Attention : Les catégories croisées des variables explicatives donnent toutes une seule valeur.\n"))
		cat(.msg("",paste("La variable", id, "est désignée automatiquement comme variable d'appariement.\n")))
		cat(.msg("","Veuillez utiliser les arguments `paired` et `id` pour ajuster les paramètres selon votre goût.\n"))
		
		# Vérifier le nombre de colonnes restantes dans `data`
		if (ncol(data) == 3) { 
			# Une seule variable explicative restante
			check_anova <- FALSE
			x <- data[,1]
			g <- data[,2]
			if (!check_anova) {
				.dbg(NULL, "Retour vers un scénario d'ANOVA à 1 facteur sur données appariées.", debug=debug)
			}
		} else if (ncol(data) > 3) { 
			# Plus d'une variable explicative restante
			#check_anova <- TRUE

			if (check_anova) {
				dbg(NULL,"Retour vers un scénario d'ANOVA à 2 facteurs sur données appariées.", debug=debug)
			}
		}
	}
}
 
  
  if(check_anova==FALSE) {
	  if(max(by(x,g,length),na.rm=T)<3) {
			if(return==FALSE) {
				if (verbose==TRUE) {cat("Error! No enough values in the samples.\n")}
				return(1)
			} else {if (verbose==TRUE) {warning("Warning! No enough values in the samples.\n")}}
	  }
	  if (any(is.na(by(x,g,length)))) {
		warning("Warning! Some levels do not have corresponding data.")
		g <- factor(g)
		if (length(unique(g))<2) {stop("Not enough levels presenting g.")}
	  }
	  if (debug==TRUE) {cat(.msg("Ignore categories with insufficient values.\n","Ignorer les catégories ne présentant pas assez de valeurs.\n"))}
	  
	  
	  
	  if(min(by(x,g,length),na.rm=T)<3) {
	  
  
	  
		if (verbose==TRUE) {warning("Warning! No enough values for some samples. The categories concerned are ignored.")}
		which(by(x,g,length)<3)-> ind_temp
		'%notin%' <- Negate('%in%')
		x <- x[g%notin%names(ind_temp)]
		g <- g[g%notin%names(ind_temp)]
		g <- as.factor(g)
		droplevels(g)->g
	  }
	  
	  .dbg("Stop the program if variability is null.","Stopper le programme si variabilité nulle.", debug=debug)

	  if(max(by(x,g,var,na.rm=T),na.rm=T)==0) {
		.exit("Error! No variability in samples.","Erreur : Absence de variabilité dans les échantillons.",verbose=verbose, return=return)
	  }
	  .dbg("Check for the presence of the control category in the categorical variable.","Contrôler la présence de la catégorie de contrôle dans la variable catégorielle.", debug=debug)
	  if ((length(control)>0)&&(!control %in% g)) {
		.exit("Error: 'control' is not a category present in 'g'.","Erreur : 'control' n'est pas une catégorie présente dans 'g'.",verbose=verbose, return=return)
	  }
	  .dbg("Ignore categories that do not vary.","Ignorer les catégories qui ne varient pas.", debug=debug)
	  if(min(by(x,g,var,na.rm=T),na.rm=T)==0) {
		if (verbose==TRUE) {warning("Warning! Some samples do not vary. Non-variable categories are ignored.")}
		which(by(x,g,var,na.rm=T)==0)-> ind_temp
		'%notin%' <- Negate('%in%')
		x <- x[g%notin%names(ind_temp)]
		g <- g[g%notin%names(ind_temp)]
		g <- as.factor(g)
		droplevels(g)->g
	  }
	  .dbg("Check the number of categories.","Contrôler le nombre de catégories.", debug=debug)
	  if (length(unique(g))<=1) {
		exit("","Error! Only one category.")
	  }
	  if (length(unique(g))>maxcat) {
		exit("","Error! Too much categories.")
	  }
  } else if (check_anova==TRUE) {
	# Construire la table des combinaisons des catégories
	# Extraire les données de la formule
	data_model <- model.frame(formula)

	# Identifier les variables explicatives (sans la réponse)
	variables_explicatives <- attr(terms(formula), "term.labels")
	
	# Vérifier si toutes les variables explicatives sont numériques
	non_numeriques <- variables_explicatives[!sapply(variables_explicatives, function(var) is.numeric(data_model[[var]]))]

	if (length(non_numeriques) > 0) {
	  # Ne traiter que les variables non numériques comme catégoriques
	  variables_categoriques <- non_numeriques
	  
	  # Construire la table des combinaisons pour les variables catégoriques uniquement
	  combinaisons <- table(data_model[variables_categoriques])
	  
	  # Vérification des combinaisons croisées
	  if (min(combinaisons) == 0) {
		.dbg("Some crossed categories of the categorical variables are not specified. Check your data.",
			"Certaines catégories croisées des variables catégoriques ne sont pas renseignées. Vérifiez vos données.", debug=debug)
	  } else {
		.dbg("The crossed categories of the categorical variables are correctly specified.","Les catégories croisées des variables catégoriques sont bien renseignées.", debug=debug)
	  }
	} else {
	  .dbg("All explanatory variables are numeric. No interaction check is required.",
			"Toutes les variables explicatives sont numériques. Aucun contrôle de croisements n'est nécessaire.", debug=debug)
	}	
	# paired est par défaut en 'auto'
	# si paired == TRUE, un contrôle est effectué pour vérifier qu'il y a autant de valeurs pour chaque catégories de cat.
	# Analyser tous types de formules Conditions ~ Conditions | Individus ou Conditions + Error (Individus/Conditions) ... etc.
	# Analyser dès qu'il y a des croisements des facteurs avec table() toutes à 1 (tout croisement renseigné) dans un Individus que appariés (signaler message). Dans ce cas on passe à paired = TRUE
	# ==> un message averti qu'on passe en apparié, et le nom du vecteur d'individus (ex : "Individus") est attribué à id.
	# Enfin pour chaque catégorie de cat, data est trié dans le même ordre des individus (afin de pouvoir comparar id par id en post-hoc).
	# 2 catégories ! Autoriser le paired en Wilcoxon et Student
	# >2 catégories : => Passer au test de friedman ou une aov sinon de ce type aov(Conditions + Error (Individus/Conditions))
	# envisager selon le test une mise en forme appropriée de la formule donnée en entrée, ou de l'intégration de la variable en id.
	# Remarque : que faire quand variances non égales ? aov(), friadman, autres ?
	# Prévoir aussi le contrôle des assomptions 1)  Normalité des résidus, 2) Homogénéité des variances et des co-variances (puisque les observations ne sont plus indépendantes puisqu'on mesure plusieurs fois les individus).
	# Nemiyi en post-hoc à prévoir si friedman à ajouter à la fonction posthoc
  
  }


  #############################################################
  #
  #
  #			ANOVA à n facteurs
  #
  #
  #############################################################
  if (check_anova==TRUE) {
		# Ajuster pour une exportation des g d'interaction compatibles post-hoc
		# Et d'une liste précisant le paramétrage de la fonction post-hoc
		bilan <- .multi_factor_analysis(x=x,g=g,formula=formula,data=data,
		alpha=alpha,	
		paired=paired,id=id,k=k,code=code,debug=debug,verbose=verbose)	
  } else {
  ################################################################  
  #		1 facteur
  ################################################################    
		bilan <- .one_factor_analysis(x=x,g=g,formula=formula,data=data,
		alpha=alpha,
		paired=paired,id=id,k=k,code=code,debug=debug,verbose=verbose)

	}
	################################################################  
	#		bilan
	################################################################  
	x <- bilan[[1]]
	g <- bilan[[2]]
	check_normality <- bilan[[3]]
	check_variance_equal <- bilan[[4]]
	k <- bilan[[5]]
	#################
	# post-hoc and bootstrap
	#################


	#print("norm") ; print(check_normality)
	#print("var") ; print(check_variance_equal)
	  if ((plot==TRUE)&(length(unique(g))<maxcat)) {
		.dbg(NULL,"Représentations graphiques.",debug=debug)
		boxplot(x~g,col="cyan")
		vioplot(x~g,col="#00AA0077",add=TRUE)
		stripchart(x~g,col="#FF000088",pch=16,vertical=TRUE,add=T,method="jitter",jitter=1/(length(unique(g))+2))
	  }
	.dbg(NULL,"Tests posts-hocs.",debug=debug)
	if (return==TRUE) {
		synth <- .posthoc(x,g,alpha=alpha,normal=check_normality,
		var.equal=check_variance_equal,
		control=control, code=code,debug=debug,verbose=verbose, paired=paired, boot=boot,iter=iter, conf=conf, k=k)
		return(synth)
	} else {return(pvals)}
}
