#' Perform One-Factor Analysis
#'
#' This function performs statistical analysis for one grouping factor.
#' It handles both normal and non-normal data, adjusting the statistical tests accordingly.
#'
#' @param x Numeric vector. Dependent variable to be analyzed.
#' @param g Factor. Grouping variable for the analysis.
#' @param formula Optional. A formula specifying the model (e.g., x ~ g).
#' @param data Optional. A data frame containing variables specified in the formula.
#' @param paired Logical. Indicates whether data are paired (default is FALSE).
#' @param id Optional. Identifier for paired data.
#' @param alpha Numeric. Significance level for hypothesis testing (default is 0.05).
#' @param k Optional. Counter for verbose messages.
#' @param debug Logical. If TRUE, detailed debugging messages are displayed (default is FALSE).
#' @param verbose Logical. If TRUE, provides detailed output during the analysis (default is FALSE).
#'
#' @details
#' The function performs the following:
#' - Adjusts the significance level using Sidak's correction.
#' - Tests normality of data using Shapiro-Wilk or Jarque-Bera tests, based on sample size.
#' - Applies appropriate statistical tests: t-test, Mann-Whitney, ANOVA, Kruskal-Wallis.
#' - Handles cases with equal or unequal variances and non-normal data.
#'
#' @importFrom fda.usc fanova.hetero
#' @importFrom agricolae kurtosis skewness
#' @importFrom lawstat levene.test
#' @importFrom WRS2 med1way t1way
#' @importFrom onewaytests bf.test
#'
#' @examples
#' # Example with normal data
#' set.seed(123)
#' x <- c(rnorm(50, mean = 5), rnorm(50, mean = 6))
#' g <- factor(rep(1:2, each = 50))
#' .one_factor_analysis(x, g, verbose = TRUE)
#'
#' # Example with non-normal data
#' x <- c(rpois(50, lambda = 5), rpois(50, lambda = 7))
#' g <- factor(rep(1:2, each = 50))
#' .one_factor_analysis(x, g, verbose = TRUE)
#'
#' @return
#' Returns results of the selected statistical tests, including:
#' - p-values for hypothesis testing.
#' - Results of normality checks and variance assessments.
#'
#' @seealso
#' - [fda.usc::fanova.hetero()]
#' - [agricolae::kurtosis()]
#' - [lawstat::levene.test()]
#' - [WRS2::med1way()]
#' - [onewaytests::bf.test()]
#'
#' @export
.one_factor_analysis <- function(x=NULL,g=NULL,formula=NULL,data=NULL,
	paired = FALSE, id = NULL,alpha = 0.05,return=TRUE,
	k=NULL,code=FALSE,debug=FALSE,verbose=FALSE, boot = TRUE, silent=TRUE) {
	  ##########################
	  #
	  #		On notera que formula est ignoré par cette fonction (à dev si nécessaire)
	  #
	  ##########################
	  pvals <- .normality(x,g)
	  check_discret <- discret.test(x)
	  check_normality <- c()
	  check_number <- c()
	  check_variance_equal <-  c()

	  skew <- function(vector) {return(abs(skewness(vector)))}
	  skew2 <- function(vector) {return(skewness.norm.test(vector)$p.value)}
	  kurto <- function(vector) {if (is.na(abs(kurtosis(vector)))){return (10)} ; return(abs(kurtosis(vector)))}
	  kurto2 <- function(vector) {return(kurtosis.norm.test(vector)$p.value)}
	##########################
	#
	#		Auto-analyse de Kurtosis & Skweness
	#
	##########################
	# |Skewness| < 1 et |Kurtosis| < 1.5 sont les seuils recommandés pour considérer une distribution comme "approximativement normale", selon Kline (2011).
	# Kline, R. B. (2011). Principles and practice of structural equation modeling (4th ed.). New York, NY: Guilford Press.
	# Normalité variables indicates acceptable normality for most measures, based on Kline's (2023) guidelines, where skewness values should ideally be within ±3 and kurtosis values within ±10.
	# Permissivité extrême : skewness > 2 et kurtosis > 7 Blanca et al. (2018)
	# Blanca, M. J., Alarcón, R., Arnau, J., Bono, R., & Bendayan, R. (2017). Non-normal data: Is ANOVA still a valid option? Psicothema, 29(4), 552-557. https://diposit.ub.edu/dspace/bitstream/2445/122126/1/671797.pdf#:~\:text=sought%20to%20answer%20the%20following,In%20addition
	auto_ku_sk <- function(sk, sk2, ku, ku2, tt = NULL, verbose = verbose, k = k) {
		ang <- paste0("Skewness & Kurtosis limits\n\t[skewness() & skewness.norm.test() & kurtosis() & kurtosis.norm.test() & length()]")
		fr <- paste0("Limites de l'asymétrie et de l'aplatissement (Skewness & Kurtosis)\n\t[skewness() & skewness.norm.test() & kurtosis() & kurtosis.norm.test() & length()]")
		k <- .vbse(ang, fr, verbose = verbose, k = k)
		if ((sk2 < pval) | (ku2 < pval) | (tt < 100)) {
			# Non-parametric
			ang <- paste0("==> Bad distribution of data (asymmetry, spread).\n\t==> We remain in a non-parametric situation.")
			fr <- paste0("==> Mauvaise distribution des données (asymétrie, dispersion).\n\t=> Nous restons dans une situation non-paramétrique.")
			k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
		} else {
			# Parametric
			ang <- paste0("==> The distribution of values and group variances are acceptable for a parametric analysis.")
			fr <- paste0("==> La distribution des valeurs et des variances des groupes est acceptable pour une analyse paramétrique.")
			k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
		}
		ang <- paste0("  | Skewness limit (max and absolute):", round(sk, 1))
		fr <- paste0("  | Limite de l'asymétrie (Skewness) (max et absolue) : ", round(sk, 1))
		k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
		if (sk < 0.5) {
			k <- .vbse("  | \t=> Symmetry (within the interval [0;0.5[).",
					   "  | \t=> Symétrie (dans l'intervalle [0;0.5[).", verbose = verbose, k = k, cpt = "off")
		} else if (sk < 1) {
			k <- .vbse("  | \t=> Moderate asymmetry (within the interval [0.5;1[).",
					   "  | \t=> Asymétrie modérée (dans l'intervalle [0.5;1[).", verbose = verbose, k = k, cpt = "off")
		} else {
			k <- .vbse("  | \t=> Asymmetry (within the interval [1;Inf[).",
					   "  | \t=> Asymétrie (dans l'intervalle [1;Inf[).", verbose = verbose, k = k, cpt = "off")
		}
		ang <- paste0("  | Skewness bootstrapped [min(p.value)]:", .format_pval(sk2), "...\n\t  | \t\t... to compare to Sidak's corrected alpha ", .format_pval(pval))
		fr <- paste0("  | Asymétrie (Skewness) bootstrappée [min(p.value)] : ", .format_pval(sk2), "...\n\t  | \t\t... à comparer avec l'alpha corrigé de Sidak ", .format_pval(pval))
		k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
		if (sk2 > pval) {
			k <- .vbse("  | \t=> Symmetry.", "  | \t=> Symétrie.", verbose = verbose, k = k, cpt = "off")
		} else {
			k <- .vbse("  | \t=> Asymmetry.", "  | \t=> Asymétrie.", verbose = verbose, k = k, cpt = "off")
		}
		ang <- paste0("  | Kurtosis limit (max and absolute):", round(ku, 1))
		fr <- paste0("  | Limite de l'aplatissement (Kurtosis) (max et absolue) : ", round(ku, 1))
		k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
		if (ku < 0.5) {
			k <- .vbse("  | \t=> Normal excess kurtosis (within the interval [0;0.5[).",
					   "  | \t=> Excès de kurtosis normal (dans l'intervalle [0;0.5[).", verbose = verbose, k = k, cpt = "off")
		} else if (ku < 1.5) {
			k <- .vbse("  | \t=> Moderate excess kurtosis (within the interval [0.5;1.5[).",
					   "  | \t=> Excès de kurtosis modéré (dans l'intervalle [0.5;1.5[).", verbose = verbose, k = k, cpt = "off")
		} else {
			k <- .vbse("  | \t=> Significant excess kurtosis (within the interval [1.5;Inf[).",
					   "  | \t=> Excès de kurtosis important (dans l'intervalle [1.5;Inf[).", verbose = verbose, k = k, cpt = "off")
		}
		ang <- paste0("  | Kurtosis bootstrapped [min(p.value)]:", .format_pval(ku2), "...\n\t  | \t\t... to compare to Sidak's corrected alpha ", .format_pval(pval))
		fr <- paste0("  | Aplatissement (Kurtosis) bootstrappé [min(p.value)] : ", .format_pval(ku2), "...\n\t  | \t\t... à comparer avec l'alpha corrigé de Sidak ", .format_pval(pval))
		k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
		if (ku2 > pval) {
			k <- .vbse("  | \t=> Flattening consistent with normality.",
					   "  | \t=> Aplatissement conforme à la normalité.", verbose = verbose, k = k, cpt = "off")
		} else {
			k <- .vbse("  | \t=> Flattening not consistent with normality.",
					   "  | \t=> Aplatissement non conforme à la normalité.", verbose = verbose, k = k, cpt = "off")
		}
		k <- .vbse(paste0("  | Group length (minimal): ", tt),
				   paste0("  | Taille du groupe (minimale) : ", tt),
				   verbose = verbose, k = k, cpt = "off")

		if (tt > 45) {
			k <- .vbse("  | \t=> Group size sufficient (greater than or equal to 45).",
					   "  | \t=> Taille des groupes suffisante (supérieure ou égale à 45).", verbose = verbose, k = k, cpt = "off")
		} else {
			k <- .vbse("  | \t=> Group size insufficient (less than 45).",
					   "  | \t=> Taille des groupes insuffisante (inférieure à 45).", verbose = verbose, k = k, cpt = "off")
		}
		return(k)
	}
	  ##########################
	  # Correction de Sidak
	  ##########################
	  .dbg("Sidak's correction rather than Bonferroni (conservative).",
		"Correction de Sidak plutôt que Bonferroni (conservateur).",debug=debug)
	  pval <- 1-(1-alpha)^(1/length(unique(g)))
	  #
	  if (code==TRUE){
		cat(paste0("alpha1 <- 1-(1-",alpha,")^(1/length(unique(g))) # Sidak correction of alpha for test repetitions (like Shapiro, Skewness...)\n"))
		if (min(by(x,g,length))<=100) {
			cat("by(x,g,shapiro.test)#1) Control of the normality of small samples (<100)\n")
		}
		if (any((by(x,g,length)<=1000)&(by(x,g,length)>100))) {
			cat("#1A)\nby(x,g,jb.norm.test)#1B) Control of the normality of big samples (<1000)\n")
		}
		if (max(by(x,g,length))>1000) {
			cat("#1) Central limit theory: enough values for some samples to not have to check normality.\n")
		}
	  }

	  ################################################################
	  #
	  #
	  #		NON-NORMAL
	  #
	  #
	  ################################################################
	  if (min(pvals) <= pval) { # NON-NORMAL
			check_normality <- FALSE
			k <- .vbse(paste0("Control of normality - Shapiro-Wilk test (<=100), Jarque-Bera (<=1000) or nothing (>1000).\n\tAnalyse of values by group [shapiro.test() & jb.norm.test()] -\t\n\tOne or more non-normal groups. min(p-value): ", .format_pval(min(pvals)), "...\n\t\twith Sidak correction of alpha to ", .format_pval(pval)),
			  paste0("Contrôle de la normalité - Test de Shapiro-Wilk (≤100), Jarque-Bera (≤1000) ou aucun test (>1000).\n\tAnalyse des valeurs par groupes [shapiro.test() & jb.norm.test()] -\t\n\tUn ou plusieurs groupes non normaux. min(p-value) : ", .format_pval(min(pvals)), "...\n\t\t...avec correction de Sidak de alpha à ", .format_pval(pval)),
			  verbose = verbose, k = k)
			sd_cr <- by(x,g,sd,na.rm=T) ; median_cr <- by(x,g,median,na.rm=T)
			data_cr <- x
			for (i in names(median_cr)) {
				data_cr[g==i] <- (data_cr[g==i]-median_cr[which(names(median_cr)==i)])/sd_cr[which(names(sd_cr)==i)]
			}
			temp <- pairwise(data_cr,g,type="ks",silent=silent,boot=FALSE)
			ks_result <- min(unlist(temp$p.value),na.rm=T)
			if (code==TRUE){cat("length(unique(g))#2)\n")}
			###################################################
			#			NON-NORMAL		2 categories
			###################################################
			if (length(unique(g))==2) { 							# 2 categories
				  check_number <- 2
				  k <- .vbse("Two categories.",
					"Deux catégories.",
					verbose = verbose, k = k)
				  sk <- max(by(x,g,skew))
				  sk2 <- min(by(x,g,skew2))
				  ku <- max(by(x,g,kurto))
				  ku2 <- min(by(x,g,kurto2))
				  #jb <- min(by(x,g,jarquebare))
				  tt <- min(by(x,g,length))
				  if (code==TRUE){cat("library(agricolae)\nby(x,g,skewness)\nby(x,g,skewness.norm.test)\nby(x,g,kurtosis)\nby(x,g,kurtosis.norm.test)\nby(x,g,length)#3)\n")}
				  ###################################################
				  #			NON-NORMAL		2 categories		Acceptable for t.test()
				  ###################################################
				  if ((sk2>pval)&(ku2>pval)&(tt>45)&(check_discret==FALSE)) { #(jb>alpha)
					check_normality <- TRUE # Retour à une forme de normalité
					check_variance_equal <-  FALSE
					k <- auto_ku_sk(sk,sk2,ku,ku2,tt,verbose=verbose,k=k)
					if (code==TRUE){cat("t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=FALSE)   #4)\n")}
					pvals <- t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=FALSE)$p.value
					if (pvals <= alpha) {
						k <- .vbse("Student Test [t.test()]- Significant differences between groups.",
							"Test de Student [t.test()] - Différences significatives entre les groupes.",
							verbose = verbose, k = k)
					} else {
						k <- .vbse("Student test [t.test()] -\n\t=> Non-significant differences between groups.",
							"Test de Student [t.test()] -\n\t=> Différences non significatives entre les groupes.",
							verbose = verbose, k = k)
					}
					###################################################
					#			NON-NORMAL		2 categories		Non acceptable for t.test()
					###################################################
				  } else {
					###################################################
					#			NON-NORMAL		2 categories		Non acceptable for t.test()		Discret
					###################################################
					check_variance_equal <-  FALSE
					if (verbose==TRUE) {
					  if (check_discret == TRUE) {
						ang <- paste0("The number of unique values [length() & unique()] suggests the presence of discrete data : ",round(length(unique(x))/length(x),3)*100,"% of unique values.")
						fr <- paste0("Le nombre de valeurs uniques [length() & unique()] suggère la présence de données discrètes : ", round(length(unique(x))/length(x),3)*100, "% de valeurs uniques.")
						k <- .vbse(ang,fr,verbose = verbose, k = k, cpt="on")

						pvals <- mood.test(x[g==unique(g)[1]],x[g==unique(g)[2]])$p.value
						if (pvals <= alpha) {
						  ang <- paste0("Brown and Mood test [mood.test()] - The medianes are different and data need to be centered on the mediane for ansari.test(). p-value : ",.format_pval(pvals))
						  fr <- paste0("Test de Brown et Mood [mood.test()] - Les médianes sont différentes et les données doivent être centrées sur la médiane pour ansari.test(). p-value : ", .format_pval(pvals))
						  k <- .vbse(ang,fr,verbose = verbose, k = k)
						  by(x,g,function(x){return(x-median(x))})->cent_med
						  pvals <- ansari.test(unlist(cent_med[1]),unlist(cent_med[2]))$p.value
						} else {
						  ang <- paste0("Brown and Mood test [mood.test()] - The medianes are the same (no need to center them for ansari.test). p-value : ",.format_pval(pvals))
						  fr <- paste0("Test de Brown et Mood [mood.test()] - Les médianes sont identiques (pas besoin de les centrer pour ansari.test). p-value : ", .format_pval(pvals))
						  k <- .vbse(ang,fr,verbose = verbose, k = k)
						  pvals <- ansari.test(x[g==unique(g)[1]],x[g==unique(g)[2]])$p.value
						}
						if (pvals < alpha) {
						  ang <- paste0("Ansari-Bradley test [ansari.test()] - Data do not have the same variance. p-value: ",.format_pval(pvals))
						  fr <- paste0("Test d'Ansari-Bradley [ansari.test()] - Les données n'ont pas la même variance. p-value : ", .format_pval(pvals))
						  k <- .vbse(ang,fr,verbose = verbose, k = k)
						} else {
						  ang <- paste0("Ansari-Bradley test [ansari.test()] - Data have the same variance. p-value: ",.format_pval(pvals))
						  fr <- paste0("Test d'Ansari-Bradley [ansari.test()] - Les données ont la même variance. p-value : ", .format_pval(pvals))
						  k <- .vbse(ang,fr,verbose = verbose, k = k)
						}
						###################################################
						#			NON-NORMAL		2 categories		Non acceptable for t.test()		Wilcox comparison
						###################################################
					  } else {
						if ((sk2<pval)|(ku2<pval)|(tt<45)) { # (jb<alpha)
							k <- auto_ku_sk(sk,sk2,ku,ku2,tt,verbose=verbose,k=k)
						}
						if (ks_result < pval) {
						   ang <- paste0("Kolmogorov-Smirnov test [ks.test()] on median-centered and reduced data -\n\tWarning! the data do not have the same distribution. p-value: ",.format_pval(ks_result),"...\n\t\t...by comparing with Sidak corrected alpha ",.format_pval(pval),"\n\tThe Mann-Whitney-Wilcoxon test will be less reliable.\n\tWarning! For wilcox.test() : Please, check graphically that the groups have the same distribution.")
						   fr <- paste0("Test de Kolmogorov-Smirnov [ks.test()] sur les données centrées sur la médiane et réduites -\n\tAttention ! les données n'ont pas la même distribution. p-value : ", .format_pval(ks_result), "...\n\t\t... en comparant avec l'alpha corrigé de Sidak ", .format_pval(pval), " Le test de Mann-Whitney-Wilcoxon sera moins fiable. Attention ! Pour wilcox.test() : Veuillez vérifier graphiquement que les groupes ont la même distribution.")
						   k <- .vbse(ang,fr,verbose = verbose, k = k)
						} else {
						  ang <- paste0("Kolmogorov-Smirnov test [ks.test()] on median-centered and reduced data -\n\tThe groups have the same distribution. p-value: ",.format_pval(ks_result),"...\n\t\t...by comparing with Sidak corrected alpha ",.format_pval(pval),"\n\tThe Mann-Whitney-Wilcoxon test will be reliable.")
						  fr <- paste0("Test de Kolmogorov-Smirnov [ks.test()] sur les données centrées sur la médiane et réduites -\n\tLes groupes ont la même distribution. p-value : ", .format_pval(ks_result), "...\n\t\t...en comparant avec l'alpha corrigé de Sidak ", .format_pval(pval), "\n\tLe test de Mann-Whitney-Wilcoxon sera fiable.")
						  k <- .vbse(ang,fr,verbose = verbose, k = k)
						}
					  }
					}
					pvals <- suppressWarnings(wilcox.test(x[g==unique(g)[1]],x[g==unique(g)[2]]))$p.value
					if (pvals <= alpha) {
						ang <- paste0("Wilcoxon-Mann-Whitney test [wilcox.test()] -\n\t=> Significant differences between groups. p-value: ", .format_pval(pvals))
						fr <- paste0("Test de Wilcoxon-Mann-Whitney [wilcox.test()] -\n\t=>  Différences significatives entre les groupes. p-value : ", .format_pval(pvals))
						k <- .vbse(ang, fr, verbose = verbose, k = k)
					} else {
						ang <- paste0("Wilcoxon-Mann-Whitney test [wilcox.test()] -\n\t=> Non-significant differences between groups. p-value: ", .format_pval(pvals))
						fr <- paste0("Test de Wilcoxon-Mann-Whitney [wilcox.test()] -\n\t=> Différences non significatives entre les groupes. p-value : ", .format_pval(pvals))
						k <- .vbse(ang, fr, verbose = verbose, k = k)
					}
				}
				  ###################################################
				  #			NON-NORMAL		>2 categories
				  ###################################################
			} else { 											# > 2 categories
				  check_number <- 3
				  k <- .vbse("More than two categories.",
					  "Plus de deux catégories.",
					  verbose = verbose, k = k)
				  sk <- max(by(x,g,skew))
				  sk2 <- min(by(x,g,skew2))
				  ku <- max(by(x,g,kurto))
				  ku2 <- min(by(x,g,kurto2))
				  #jb <- min(by(x,g,jarquebare))
				  tt <- min(by(x,g,length))
				  if (code==TRUE){
					#cat("#3a)\nby(x,g,jb.norm.test)#3b)\nlibrary(agricolae)#3c)\nby(x,g,skewness)#3d)\nby(x,g,skewness.norm.test)#3e)\nby(x,g,kurtosis)#3f)\nby(x,g,kurtosis.norm.test)#3g)\nby(x,g,length)#3h)\n")
					cat("#library(agricolae)#3a)\nby(x,g,skewness)#3b)\nby(x,g,skewness.norm.test)#3c)\nby(x,g,kurtosis)#3d)\nby(x,g,kurtosis.norm.test)#3e)\nby(x,g,length)#3f)\n")
					cat("library(car)#4a)\nleveneTest(x,g)#4b)\n")
					cat("library(onewaytests)#5a)\nbf.test(x~g,data=data.frame(x,'g'=factor(g)))#5b)\n")
				  }
				  pvals2 <- suppressWarnings(bf.test(x~g,data=data.frame(x,"g"=factor(g)),verbose=FALSE))$p.value
				  pvals <- suppressWarnings(leveneTest(x,g))[1,3]
				if (((pvals <= alpha) & (pvals2 <= alpha)) | ((pvals > alpha) & (pvals2 > alpha))) {
					ang <- paste0("Consistency in testing of Levene and Brown-Forsyth results.\n\tLevene p-value: ", .format_pval(pvals), " - Brown-Forsyth p-value: ", .format_pval(pvals2),"\n\t=> We can test the possibility of returning to a non-parametric situation.")
					fr <- paste0("Cohérence dans les résultats des tests de Levene et Brown-Forsyth.\n\tLevene p-value : ", .format_pval(pvals), " - Brown-Forsyth p-value : ", .format_pval(pvals2),"\n\t=> On peut tester la possibilité d'un retour vers une situation non paramétrique.")
					k <- .vbse(ang, fr, verbose = verbose, k = k)
				} else {
					ang <- paste0("Inconsistent testing of Levene and Brown-Forsyth.\n\tLevene p-value: ", .format_pval(pvals), " - Brown-Forsyth p-value: ", .format_pval(pvals2),"\n\t=> We remain in a non-parametric situation.")
					fr <- paste0("Incohérence dans les résultats des tests de Levene et Brown-Forsyth.\n\tLevene p-value : ", .format_pval(pvals), " - Brown-Forsyth p-value : ", .format_pval(pvals2),"\n\t=> On reste sur une situation non paramétrique.")
					k <- .vbse(ang, fr, verbose = verbose, k = k)
				}
					if (code==TRUE){cat("kruskal.test(x,g) #6)\n")}
					# Si verbose : blabla
					#print("pval") ; print(pval)
					if ((sk2<pval)|(ku2<pval)|(tt<45)) {
						# non paramétrique
					} else {
						# retour paramétrique
						if ((pvals > alpha)&(pvals2 > alpha)) {
							check_variance_equal <-  TRUE
							check_normality <-  TRUE
						}
					}
					k <- auto_ku_sk(sk,sk2,ku,ku2,tt,verbose=verbose,k=k)
					if (check_normality == TRUE) {
						###################
						#		Passerelle de retour vers la normalité
						###################
						#retour vers SNK
						.vbse("==> Return to a form of normality.","==> Retour vers une forme de normalité.",
							cpt="off",verbose=verbose)
						formula <- formula(x~g)
						mya <- suppressWarnings(aov(data.frame(x,g), formula=formula))
						if (code==TRUE){cat("mya <- aov(data.frame(x,g), formula=x~g) #7)\n")}
						pvals <- summary(mya)[[1]][["Pr(>F)"]][1]
						if (pvals<=alpha) {										# Significant AOV
							ang <- paste0("One-way analysis of variance [aov()] -\n\t=> Significant differences between groups. p-value:", .format_pval(pvals))
							fr <- paste0("Analyse de la variance à un facteur [aov()] -\n\t=> Différences significatives entre les groupes. p-value :", .format_pval(pvals))
							k <- .vbse(ang, fr, verbose = verbose, k = k)

						} else {											#	 Non-significant AOV
							ang <- paste0("One-way analysis of variance [aov()] -\n\t=> Non-significant differences between groups. p-value:", .format_pval(pvals))
							fr <- paste0("Analyse de la variance à un facteur [aov()] -\n\t=> Différences non significatives entre les groupes. p-value :", .format_pval(pvals))
							k <- .vbse(ang, fr, verbose = verbose, k = k)
						}
					} else {
						##################
						#	Test de Fligner
						##################
						pvals3 <- fligner.test(x,g)$p.value
						if (is.na(pvals)) {
						  .exit("Fligner-Killeen test [fligner.test()] - Error, return NA.",
							"Test de Fligner-Killeen [fligner.test()] - Erreur, retourne NA.",
							verbose=TRUE, return=TRUE)
						  return(pvals)# FALSE
						}
						##################
						#	Test de Kruskal
						##################
						pvals <- kruskal.test(x,g)$p.value
						if (verbose==TRUE) {
						  if (pvals3<=alpha) {
							ang <- paste0("Fligner-Killeen test [fligner.test()] -\n\t=> Significant differences of variance between groups, p-value:", .format_pval(pvals3),"\n\t... go to med1way().")
							fr <- paste0("Test de Fligner-Killeen [fligner.test()] -\n\t=> Différences significatives de variance entre les groupes, p-value : ", .format_pval(pvals3),"\n\t... aller vers med1way().")
							k <- .vbse(ang, fr, verbose = verbose, k = k)
						  } else {
							ang <- paste0("Fligner-Killeen test [fligner.test()] -\n\t=> Non-significant differences of variance between groups, p-value:",.format_pval(pvals3),"\n\t\t...go to t1way().")
							fr <- paste0("Test de Fligner-Killeen [fligner.test()] -\n\t=> Différences non significatives de variance entre les groupes, p-value : ",.format_pval(pvals3),"\n\t\t...aller vers t1way().")
							k <- .vbse(ang, fr, verbose = verbose, k = k)
						  }
						  temp <- pairwise(x,g,type="ks",silent=silent,boot=FALSE)$p.value
						  ks_result <- min(unlist(temp),na.rm=TRUE)
						  if (ks_result <= pval) {
							ang <- paste0("Kolmogorov-Smirnov test [ks.test()] on median-centered and reduced data -\n\tWarning! the groups do not have the same distribution. min(p-value): ", .format_pval(ks_result), "\n\t... by comparing with Sidak corrected alpha ", .format_pval(pval), "\n\tThe Kruskal-Wallis test and Mann-Whitney-Wilcoxon test will be less reliable.\n\tPlease, check graphically the groups distributions.")
							fr <- paste0("Test de Kolmogorov-Smirnov [ks.test()] sur les données centrées sur la médiane et réduites -\n\tAttention ! les groupes n'ont pas la même distribution. min(p-value) : ", .format_pval(ks_result), "\n\t... en comparant avec l'alpha corrigé de Sidak ", .format_pval(pval), "\n\tLe test de Kruskal-Wallis et le test de Mann-Whitney-Wilcoxon seront moins fiables.\n\tVeuillez vérifier graphiquement les distributions des groupes.")
							k <- .vbse(ang, fr, verbose = verbose, k = k)
						  } else {
							ang <- paste0("Kolmogorov-Smirnov test [ks.test()] on median-centered and reduced data -\n\tThe groups have the same distribution. min(p-value): ", .format_pval(ks_result), "\n\tby comparing with Sidak corrected alpha ", .format_pval(pval), "\n\tGood accuracy expected on the tests of Kruskal-Wallis and Mann-Whitney-Wilcoxon.")
							fr <- paste0("Test de Kolmogorov-Smirnov [ks.test()] sur les données centrées sur la médiane et réduites -\n\tLes groupes ont la même distribution. min(p-value) : ", .format_pval(ks_result), "\n\ten comparant avec l'alpha corrigé de Sidak ", .format_pval(pval), "\n\tBonne précision attendue pour les tests de Kruskal-Wallis et Mann-Whitney-Wilcoxon.")
							k <- .vbse(ang, fr, verbose = verbose, k = k)
						  }
						  if (pvals <= alpha) {
							ang <- paste0("Kruskal-Wallis test [kruskal.test()] - At least one group appears to show a difference. p-value:", .format_pval(pvals))
							fr <- paste0("Test de Kruskal-Wallis [kruskal.test()] - Au moins un groupe semble montrer une différence. p-value :", .format_pval(pvals))
							k <- .vbse(ang, fr, verbose = verbose, k = k)

						  } else {
							ang <- paste0("Kruskal-Wallis test [kruskal.test()] - No different group a priori. p-value:", .format_pval(pvals))
							fr <- paste0("Test de Kruskal-Wallis [kruskal.test()] - Aucun groupe différent a priori. p-value : ", .format_pval(pvals))
							k <- .vbse(ang, fr, verbose = verbose, k = k)
						  }
						}
						if ((return==TRUE) | (verbose==TRUE)) {
						  ############
						  # 	Allons jusqu'au bout du raisonnement
						  ############
						  if (pvals3<=alpha) {
							#################
							#	var.equal=F ==> median
							#################
							check_variance_equal <-  FALSE
							pvals3 <- med1way(x~g)$p.value
							if (is.na(pvals3)) {
							    ang <- paste0("Oneway ANOVA of medians [med1way()] - Failed, return NA. The Kruskal-Wallis test should be used for interpretation.")
								fr <- paste0("Analyse de la variance à un facteur des médianes [med1way()] - Échec, retourne NA. Le test de Kruskal-Wallis doit être utilisé pour l'interprétation.")
								k <- .vbse(ang, fr, verbose = verbose, k = k)
							} else {
							  if (pvals3 <= alpha) {
								ang <- paste0("Oneway ANOVA of medians [med1way()] - Significant differences between the median of groups. p-value:", .format_pval(pvals3))
								fr <- paste0("Analyse de la variance à un facteur des médianes [med1way()] - Différences significatives entre les médianes des groupes. p-value :", .format_pval(pvals3))
								k <- .vbse(ang, fr, verbose = verbose, k = k)
								if (pvals > alpha) {
									ang <- paste0("Warning! The Kruskal-Wallis test and ANOVA on medians give contradictory results.")
									fr <- paste0("Attention ! Le test de Kruskal-Wallis et l'analyse de la variance des médianes donnent des résultats contradictoires.")
									k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
								}
							  } else if (pvals3 > alpha) {
								ang <- paste0("Oneway ANOVA of medians [med1way()] -\n\t=> Non-significant differences between the median of groups. p-value:", .format_pval(pvals3))
								fr <- paste0("Analyse de la variance à un facteur des médianes [med1way()] -\n\t=> Différences non significatives entre les médianes des groupes. p-value :", .format_pval(pvals3))
								k <- .vbse(ang, fr, verbose = verbose, k = k)
								if (pvals <= alpha) {
									ang <- paste0("Warning! The Kruskal-Wallis test and ANOVA on medians give contradictory results.")
									fr <- paste0("Attention ! Le test de Kruskal-Wallis et l'analyse de la variance des médianes donnent des résultats contradictoires.")
									k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
								}
							  }
							}
						  } else {
							#################
							#	var.equal=T ==> trimm
							#################
							check_variance_equal <-  TRUE
							pvals3 <- t1way(x~g)$p.value
							if (is.na(pvals3)) {
								ang <- paste0("Oneway ANOVA on trimmed means [t1way()] - Failed, return NA. The Kruskal-Wallis test should be used for interpretation.")
								fr <- paste0("Analyse de la variance à un facteur sur les moyennes tronquées [t1way()] - Échec, retourne NA. Le test de Kruskal-Wallis doit être utilisé pour l'interprétation.")
								k <- .vbse(ang, fr, verbose = verbose, k = k)
							} else {
							  if (pvals3 <= alpha) {
								ang <- paste0("Oneway ANOVA on trimmed means [t1way()] - Significant differences between the trimmed groups. p-value:", .format_pval(pvals3))
								fr <- paste0("Analyse de la variance à un facteur sur les moyennes tronquées [t1way()] - Différences significatives entre les groupes tronqués. p-value :", .format_pval(pvals3))
								k <- .vbse(ang, fr, verbose = verbose, k = k)
								if (pvals > alpha) {
									ang <- paste0("Warning! The Kruskal-Wallis test and ANOVA on trimmed means give contradictory results.")
									fr <- paste0("Attention ! Le test de Kruskal-Wallis et l'analyse de la variance sur les moyennes tronquées donnent des résultats contradictoires.")
									k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
								}
							  } else if (pvals3 > alpha) {
								ang <- paste0("One-way ANOVA on trimmed means [t1way()] - Non-significant differences between the trimmed groups. p-value:", .format_pval(pvals3))
								fr <- paste0("Analyse de la variance à un facteur sur les moyennes tronquées [t1way()] - Différences non significatives entre les groupes tronqués. p-value :", .format_pval(pvals3))
								k <- .vbse(ang, fr, verbose = verbose, k = k)
								if (pvals <= alpha) {
									ang <- paste0("Warning! The Kruskal-Wallis test and ANOVA on trimmed means give contradictory results.")
									fr <- paste0("Attention ! Le test de Kruskal-Wallis et l'analyse de la variance sur les moyennes tronquées donnent des résultats contradictoires.")
									k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
								}
							  }
							}
						  } # fin var.equal
						} # test uniquement pour aller au bout du raisonnement

					} # fin d'ajustement à la normalité malgré tout

			} # Ajustement selon le nombre de catégories
	  } else {
		################################################################
		#
		#
		#		NORMAL
		#
		#
		################################################################
		check_normality <- TRUE
		###################################################
		#			NORMAL
		###################################################
		k <- .vbse(paste0("Control of normality - Shapiro-Wilk test (<=100), Jarque-Bera (<=1000) or nothing (>1000).\n\tAnalyse of values by group (shapiro.test() & jb.norm.test()) - \n\tThe groups follow the normal law. min(p-value): ", .format_pval(min(pvals)), "...\n\t\twith Sidak correction of alpha to ", .format_pval(pval,)),
			paste0("Contrôle de la normalité - Test de Shapiro-Wilk (<=100), Jarque-Bera (<=1000) ou aucun test (>1000).\n\tAnalyse des valeurs par groupe (shapiro.test() & jb.norm.test()) - \n\tLes groupes suivent la loi normale. min(p-value) : ", .format_pval(min(pvals)), "...\n\t\t...avec correction de Sidak conduisant à un alpha de ", .format_pval(pval)),
			verbose = verbose, k = k)
		if (length(unique(g))==2) { # 2 categories
		  check_number <- 2
		  if (code==TRUE){cat("length(unique(g)) #2)\n")}
		  ang <- paste0("Two categories.")
			fr <- paste0("Deux catégories.")
			k <- .vbse(ang, fr, verbose = verbose, k = k)
		  formula <- formula(x~g)
		  pvals <- var.test(formula)$p.value
		  if (code==TRUE){cat("var.test(x~g) #3)\n")}
		  if (pvals>alpha) {
			###################################################
			#			NORMAL		2 categories	homogene variance
			###################################################
			check_variance_equal <-  TRUE
			ang <- paste0("Fisher-Snedecor test [var.test()] - Identical group variances. p-value:", .format_pval(pvals))
			fr <- paste0("Test de Fisher-Snedecor [var.test()] - Variances des groupes identiques. p-value :", .format_pval(pvals))
			k <- .vbse(ang, fr, verbose = verbose, k = k)
			pvals <- t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=TRUE)$p.value
			if (verbose==TRUE) {
				if (pvals <= alpha) {
				  ##################################
				  #        NORMAL, Student significant (var.equal=T)
				  ##################################
				  ang <- paste0("Student test [t.test()] - Significant differences between groups. p-value:", .format_pval(pvals))
				  fr <- paste0("Test de Student [t.test()] - Différences significatives entre les groupes. p-value : ", .format_pval(pvals))
				  k <- .vbse(ang, fr, verbose = verbose, k = k)
				} else {
				  ##################################
				  #        NORMAL, Student unsignificant (var.equal=T)
				  ##################################
				  ang <- paste0("Student test [t.test()] - Non-significant differences between groups. p-value:", .format_pval(pvals))
				  fr <- paste0("Test de Student [t.test()] - Différences non significatives entre les groupes. p-value : ", .format_pval(pvals))
				  k <- .vbse(ang, fr, verbose = verbose, k = k)
				}
			}
		  } else {
			###################################################
			#			NORMAL		2 categories	non-homogene variance
			###################################################
			check_variance_equal <-  FALSE
			ang <- paste0("Fisher-Snedecor test [var.test()] - Non-identical group variances. p-value:", .format_pval(pvals))
			fr <- paste0("Test de Fisher-Snedecor [var.test()] - Variances des groupes non identiques. p-value : ", .format_pval(pvals))
			k <- .vbse(ang, fr, verbose = verbose, k = k)
			pvals <- t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],,var.equal=FALSE)$p.value
			if (code==TRUE){cat("t.test(x[g==unique(g)[1]],x[g==unique(g)[2]],var.equal=TRUE) #4)\n")}
			if (pvals <= alpha) {
			  ##################################
			  #        NORMAL, Student significant (var.equal=F)
			  ##################################
				ang <- paste0("Student test [t.test()] - Significant differences between groups. p-value:", .format_pval(pvals))
				fr <- paste0("Test de Student [t.test()] - Différences significatives entre les groupes. p-value : ", .format_pval(pvals))
				k <- .vbse(ang, fr, verbose = verbose, k = k)

			} else {
			  ##################################
			  #        NORMAL, Student unsignificant (var.equal=F)
			  ##################################
				ang <- paste0("Student test (t.test()) - Non-significant differences between groups. p-value:", .format_pval(pvals))
				fr <- paste0("Test de Student (t.test()) - Différences non significatives entre les groupes. p-value :", .format_pval(pvals))
				k <- .vbse(ang, fr, verbose = verbose, k = k)
			}
		  }
		} else { 													# > 2 categories
		  check_number <- 3
		  ###################################################
		  #			NORMAL		>2 categories
		  ###################################################
		  if (code==TRUE){cat("length(unique(g))#2)\n")}
	      k <- .vbse("More than two categories.",
		   "Plus de deux catégories.",
		   verbose = verbose, k = k)
		  pvals <- bartlett.test(x,g)$p.value
		  if (code==TRUE){cat("bartlett.test(x,g) #3)\n")}
		  if (pvals > alpha) {											# Identical variances
			  ##################################
			  #        NORMAL, >2 categories var.equal=T => AOV
			  ##################################
			check_variance_equal <-  TRUE
			k <- .vbse(paste0("Bartlett test [bartlett.test()] - Identical group variances. p-value: ", .format_pval(pvals)),
			  paste0("Test de Bartlett [bartlett.test()] - Variances des groupes identiques. p-value : ", .format_pval(pvals)),
			  verbose = verbose, k = k)
			formula <- formula(x~g)
			mya <- suppressWarnings(aov(data.frame(x,g), formula=formula))
			if (code==TRUE){cat("mya <- aov(data.frame(x,g), formula=x~g) #4)\n")}
			pvals <- summary(mya)[[1]][["Pr(>F)"]][1]
				if (pvals<=alpha) {										# Significant AOV
				  k <- .vbse(paste0("One-way analysis of variance [aov()] - Significant differences between groups. p-value: ", .format_pval(pvals)),
					  paste0("Analyse de variance à un facteur [aov()] - Différences significatives entre les groupes. p-value : ", .format_pval(pvals)),
					  verbose = verbose, k = k)
				} else {											#	 Non-significant AOV
				  k <- .vbse(paste0("One-way analysis of variance [aov()] - Non-significant differences between groups. p-value: ", .format_pval(pvals)),
					paste0("Analyse de variance à un facteur [aov()] - Différences non significatives entre les groupes. p-value : ", .format_pval(pvals)),
					verbose = verbose, k = k)
				}
		  } else {												# Non-identical variances
			  ##################################
			  #        NORMAL, >2 categories var.equal=F => FANOVA.HETERO
			  ##################################
			check_variance_equal <-  FALSE
			ang <- paste0("Bartlett test [bartlett.test()] - Non-identical group variances. p-value:", .format_pval(pvals))
			fr <- paste0("Test de Bartlett [bartlett.test()] - Variances des groupes non identiques. p-value :", .format_pval(pvals))
			k <- .vbse(ang, fr, verbose = verbose, k = k)
			pvals <- oneway.test(x~g,var.equal=FALSE)$p.value
			if (code==TRUE){cat("oneway.test(x~g,var.equal=FALSE) #4)\n")}
			myf <- try(fanova.hetero(data.frame(x,g = as.factor(g)),x~g),silent=silent)
			if (is(myf)=="try-error") {
			  #if (verbose==TRUE) {cat("Error on fanova.hetero()\n")}
			  pvals2 <- alpha
			} else {pvals2 <- myf$ans[4]}
			if (verbose==TRUE) {
				if (pvals<=alpha) {
					ang <- paste0("Welch’s heteroscedastic F test [oneway.test(var.equal=FALSE)] - Significant differences between groups. p-value:", .format_pval(pvals))
					fr <- paste0("Test F hétéroscédastique de Welch [oneway.test(var.equal=FALSE)] - Différences significatives entre les groupes. p-value :", .format_pval(pvals))
					k <- .vbse(ang, fr, verbose = verbose, k = k)
					if (pvals2 > alpha) {
						ang <- paste0("Warning! fanova.hetero() does not give the same result as oneway.test. p-value:", .format_pval(pvals2))
						fr <- paste0("Attention ! fanova.hetero() ne donne pas le même résultat que oneway.test. p-value :", .format_pval(pvals2))
						k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
					}
				} else {
					ang <- paste0("Welch’s heteroscedastic F test [oneway.test(var.equal=FALSE)] - Non-significant differences between groups. p-value:", .format_pval(pvals))
					fr <- paste0("Test F hétéroscédastique de Welch [oneway.test(var.equal=FALSE)] - Différences non significatives entre les groupes. p-value :", .format_pval(pvals))
					k <- .vbse(ang, fr, verbose = verbose, k = k)
					if (pvals2 <= alpha) {
						ang <- paste0("Warning! fanova.hetero() does not give the same result as oneway.test. p-value:", .format_pval(pvals))
						fr <- paste0("Attention ! fanova.hetero() ne donne pas le même résultat que oneway.test. p-value :", .format_pval(pvals))
						k <- .vbse(ang, fr, verbose = verbose, k = k, cpt = "off")
					}
				}
			}


		  }
		}
	  }
	  return(check <- list(x,g,check_normality,check_variance_equal,k))
 }
